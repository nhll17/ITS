# Issue Tracker Frontend — React JavaScript (Create React App)

This frontend is built with **React + JavaScript + React-Bootstrap + React Router** using the standard Create React App setup.

## 1. Create the project with npx

If you want to create a fresh project yourself:

```bash
npx create-react-app issue-tracker-frontend
cd issue-tracker-frontend
npm install react-bootstrap bootstrap bootstrap-icons react-router-dom
```

Then copy the provided `src` folder and `public/index.html` into the project.

## 2. Run the provided project

After extracting this project:

```bash
cd issue-tracker-frontend-cra
npm install
npm start
```

The application runs at:

`http://localhost:3000`

The CRA development proxy sends API requests to:

`http://localhost:8085`

## 3. Backend

Start your Spring Boot API Gateway on port `8085`.

The frontend calls endpoints using paths such as:

- `/api/users`
- `/api/projects`
- `/api/issues`

## 4. Important

- All frontend source files are `.js`; there are no `.ts` or `.tsx` files.
- JSX is written directly inside `.js` files, which Create React App supports.
- No TypeScript configuration is required.
- `src/types/models.js` is intentionally empty because the original TypeScript interfaces were compile-time only.
- Role IDs are currently assumed to be `1 = Project Owner` and `2 = Assignee`. Change `src/types/constants.js` if your backend uses different IDs.


## HTTP Client

The frontend uses Axios for REST API communication. Install dependencies with `npm install`; Axios is included in `package.json`.
