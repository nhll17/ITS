import axios from "axios";

const api = axios.create({
    baseURL: process.env.REACT_APP_API_BASE_URL || "",
    headers: {
        "Content-Type": "application/json"
    }
});

// Convert Axios errors into a simple Error so pages can keep using error.message.
api.interceptors.response.use(
    (response) => response,
    (error) => {
        const data = error.response?.data;
        const message = data?.message || data?.error || error.message || "Request failed";
        return Promise.reject(new Error(message));
    }
);

export const userApi = {
    signup: (payload) => api.post("/api/users", payload).then((response) => response.data),
    login: (email, password) =>
        api.post("/api/users/login", null, {
            params: { email, password }
        }).then((response) => response.data),
    getById: (id) => api.get(`/api/users/${id}`).then((response) => response.data),
    getAll: () => api.get("/api/users").then((response) => response.data),
    getIssuesByUser: (id) => api.get(`/api/users/${id}/issues`).then((response) => response.data),
    getIssuesByUsername: (name) =>
        api.get(`/api/users/username/${encodeURIComponent(name)}/issues`).then((response) => response.data)
};

export const projectApi = {
    getAll: () => api.get("/api/projects").then((response) => response.data),
    getById: (id) => api.get(`/api/projects/${id}`).then((response) => response.data),
    getByOwner: (ownerId) => api.get(`/api/projects/owner/${ownerId}`).then((response) => response.data),
    create: (payload) => api.post("/api/projects", payload).then((response) => response.data),
    update: (id, payload) => api.put(`/api/projects/${id}`, payload).then((response) => response.data),
    delete: (id) => api.delete(`/api/projects/${id}`).then((response) => response.data),
    getIssues: (id) => api.get(`/api/projects/${id}/issues`).then((response) => response.data)
};

export const issueApi = {
    getAll: () => api.get("/api/issues").then((response) => response.data),
    getById: (id) => api.get(`/api/issues/${id}`).then((response) => response.data),
    create: (payload) => api.post("/api/issues", payload).then((response) => response.data),
    update: (id, payload) => api.put(`/api/issues/${id}`, payload).then((response) => response.data),
    getByProject: (projectId) => api.get(`/api/issues/project/${projectId}`).then((response) => response.data),
    getByAssignee: (assigneeId) => api.get(`/api/issues/assignee/${assigneeId}`).then((response) => response.data)
};

export default api;
