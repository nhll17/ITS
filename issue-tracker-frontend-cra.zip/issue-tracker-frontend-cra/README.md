# Issue Tracker Frontend — Create React App

This frontend is built with **Create React App**, React, TypeScript, React-Bootstrap and React Router.

## 1. Create the project with npx

If creating the project from scratch, use:

```bash
npx create-react-app issue-tracker-frontend --template typescript
```

Then replace the generated `src` folder with the `src` folder in this project.

## 2. Install dependencies

```bash
npm install
```

## 3. Start the backend

Make sure the backend/API Gateway is running on:

```text
http://localhost:8085
```

The `package.json` contains a CRA proxy:

```json
"proxy": "http://localhost:8085"
```

Therefore the frontend calls `/api/...` and CRA forwards those requests to the gateway.

## 4. Start the frontend

```bash
npm start
```

The application opens at:

```text
http://localhost:3000
```

## 5. Optional API URL

If you do not want to use the CRA proxy, create `.env`:

```text
REACT_APP_API_BASE_URL=http://localhost:8085
```

Then restart `npm start`.

## Important

The frontend maps the case-study labels to the backend enum values:

- To-Do → `OPEN`
- Development → `IN_PROGRESS`
- Testing → `RESOLVED`
- Completed → `CLOSED`
- Bug → `BUG`
- Task → `TASK`
- Story → `FEATURE`

Role IDs are centralized in `src/types/constants.ts`.
