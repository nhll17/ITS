import type {
  ApiError,
  Issue,
  IssueFormValues,
  Project,
  ProjectFormValues,
  User
} from "../types/models";

const API_BASE = process.env.REACT_APP_API_BASE_URL ?? "";

const api = async <T>(path: string, options: RequestInit = {}): Promise<T> => {
  const response = await fetch(`${API_BASE}${path}`, {
    headers: {
      "Content-Type": "application/json",
      ...(options.headers ?? {})
    },
    ...options
  });

  const text = await response.text();
  const data: unknown = text ? JSON.parse(text) : null;

  if (!response.ok) {
    const error = (data ?? {}) as ApiError;
    throw new Error(error.message || error.error || `Request failed with status ${response.status}`);
  }

  return data as T;
};

export const userApi = {
  signup: (payload: Omit<User, "userId">) =>
    api<User>("/api/users", { method: "POST", body: JSON.stringify(payload) }),

  login: (email: string, password: string) =>
    api<User>(`/api/users/login?email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`, {
      method: "POST"
    }),

  getById: (id: number) => api<User>(`/api/users/${id}`),

  getAll: () => api<User[]>("/api/users"),

  getIssuesByUser: (id: number) => api<Issue[]>(`/api/users/${id}/issues`),

  getIssuesByUsername: (name: string) =>
    api<Issue[]>(`/api/users/username/${encodeURIComponent(name)}/issues`)
};

export const projectApi = {
  getAll: () => api<Project[]>("/api/projects"),

  getById: (id: number) => api<Project>(`/api/projects/${id}`),

  getByOwner: (ownerId: number) => api<Project[]>(`/api/projects/owner/${ownerId}`),

  create: (payload: ProjectFormValues) =>
    api<Project>("/api/projects", { method: "POST", body: JSON.stringify(payload) }),

  update: (id: number, payload: ProjectFormValues) =>
    api<Project>(`/api/projects/${id}`, { method: "PUT", body: JSON.stringify(payload) }),

  delete: (id: number) =>
    api<string>(`/api/projects/${id}`, { method: "DELETE" }),

  getIssues: (id: number) => api<Issue[]>(`/api/projects/${id}/issues`)
};

export const issueApi = {
  getAll: () => api<Issue[]>("/api/issues"),

  getById: (id: number) => api<Issue>(`/api/issues/${id}`),

  create: (payload: IssueFormValues) =>
    api<Issue>("/api/issues", { method: "POST", body: JSON.stringify(payload) }),

  update: (id: number, payload: IssueFormValues) =>
    api<Issue>(`/api/issues/${id}`, { method: "PUT", body: JSON.stringify(payload) }),

  getByProject: (projectId: number) =>
    api<Issue[]>(`/api/issues/project/${projectId}`),

  getByAssignee: (assigneeId: number) =>
    api<Issue[]>(`/api/issues/assignee/${assigneeId}`)
};
