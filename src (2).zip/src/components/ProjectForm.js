import { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { createProject } from "../services/projectService";
import { AuthContext } from "../context/AuthContext";
import AlertMessage from "./AlertMessage";

export default function ProjectForm() {
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();
  const [form, setForm] = useState({
    projectName: "", projectOwner: user?.userId || "", startDate: "", endDate: ""
  });
  const [errors, setErrors] = useState({});
  const [error, setError] = useState("");

  const validate = () => {
    const e = {};
    if (!form.projectName.trim()) e.projectName = "Project name is required.";
    else if (form.projectName.length > 150) e.projectName = "Maximum 150 characters.";
    if (!form.projectOwner || Number(form.projectOwner) <= 0) e.projectOwner = "Project owner is required.";
    if (form.startDate && form.endDate && form.endDate < form.startDate) e.endDate = "End date cannot be before start date.";
    return e;
  };

  const change = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: "" });
  };

  const submit = async e => {
    e.preventDefault();
    setError("");
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length) return;

    try {
      await createProject({
        projectName: form.projectName.trim(),
        projectOwner: Number(form.projectOwner),
        startDate: form.startDate || null,
        endDate: form.endDate || null
      });
      navigate("/owner");
    } catch (err) {
      setError(err.userMessage || "Unable to create project.");
    }
  };

  return (
    <div className="page-container">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-lg-7">
            <div className="card dashboard-card">
              <div className="card-header bg-primary text-white"><h4 className="mb-0">Create Project</h4></div>
              <div className="card-body p-4">
                <AlertMessage message={error} />
                <form onSubmit={submit} noValidate>
                  <div className="mb-3">
                    <label className="form-label">Project Name *</label>
                    <input name="projectName" value={form.projectName} onChange={change}
                      className={`form-control ${errors.projectName ? "is-invalid" : ""}`} maxLength="150" />
                    {errors.projectName && <div className="invalid-feedback">{errors.projectName}</div>}
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Project Owner *</label>
                    <input type="number" name="projectOwner" value={form.projectOwner} readOnly
                      className={`form-control ${errors.projectOwner ? "is-invalid" : ""}`} />
                    {errors.projectOwner && <div className="invalid-feedback">{errors.projectOwner}</div>}
                  </div>

                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Start Date</label>
                      <input type="date" name="startDate" value={form.startDate} onChange={change} className="form-control" />
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label">End Date</label>
                      <input type="date" name="endDate" value={form.endDate} onChange={change}
                        className={`form-control ${errors.endDate ? "is-invalid" : ""}`} />
                      {errors.endDate && <div className="invalid-feedback">{errors.endDate}</div>}
                    </div>
                  </div>

                  <div className="d-flex gap-2 mt-3">
                    <button type="submit" className="btn btn-primary">Create Project</button>
                    <button type="button" className="btn btn-outline-secondary"
                      onClick={() => setForm({ projectName: "", projectOwner: user?.userId || "", startDate: "", endDate: "" })}>
                      Reset
                    </button>
                    <button type="button" className="btn btn-light ms-auto" onClick={() => navigate("/owner")}>Cancel</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
