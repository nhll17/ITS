import { useEffect, useMemo, useState, useContext } from "react";
import { Link } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { getIssuesByAssignee } from "../services/issueService";
import IssueCard from "./IssueCard";
import ProfilePanel from "./ProfilePanel";
import AlertMessage from "./AlertMessage";

export default function AssigneeDashboard() {
  const { user } = useContext(AuthContext);
  const [issues, setIssues] = useState([]);
  const [search, setSearch] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try {
      setLoading(true);
      setIssues(await getIssuesByAssignee(user.userId));
    } catch (err) {
      setError(err.userMessage || "Unable to load assigned issues.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { if (user?.userId) load(); }, [user?.userId]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return issues.filter(i => !q || `${i.summary} ${i.description || ""}`.toLowerCase().includes(q));
  }, [issues, search]);

  return (
    <div className="page-container">
      <div className="container">
        <div className="row g-4">
          <div className="col-lg-3">
            <ProfilePanel user={user} />
            <div className="list-group mt-3">
              <Link className="list-group-item list-group-item-action sidebar-link active" to="/assignee">Issue Dashboard</Link>
            </div>
          </div>
          <div className="col-lg-9">
            <div className="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
              <div>
                <h2 className="mb-1">Assignee Dashboard</h2>
                <p className="text-muted mb-0">Issues assigned to you.</p>
              </div>
              <div style={{ minWidth: 260 }}>
                <input className="form-control" placeholder="Search issues..."
                  value={search} onChange={e => setSearch(e.target.value)} />
              </div>
            </div>
            <AlertMessage message={error} onClose={() => setError("")} />
            {loading ? <div className="text-center py-5">Loading issues...</div> : (
              filtered.length === 0 ? (
                <div className="card dashboard-card"><div className="card-body text-center py-5">
                  <h5>No issues assigned</h5><p className="text-muted mb-0">There are no matching issues for your account.</p>
                </div></div>
              ) : (
                <div className="row g-3">
                  {filtered.map(issue => (
                    <div className="col-md-6" key={issue.issueId}>
                      <IssueCard issue={issue} assigneeView />
                    </div>
                  ))}
                </div>
              )
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
