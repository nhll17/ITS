import { useRef, useState } from "react";
import { addProduct } from "../services/productService";
export default function AddProductForm() {

    const productNameRef = useRef();
    const productDescriptionRef = useRef();
    const priceRef = useRef();
    const categoryRef = useRef();
    const brandRef = useRef();
    const imageURLRef = useRef();

    const [errors,setErrors] = useState({});

    const handleBlur = (e) => {
        const { name } = e.target;
        let error = "";
        switch (name) {
            case "productName":
                if (!productNameRef.current.value.trim()) {
                    error = "Product Name is required";
                }
                break;
            case "productDescription":
                if (!productDescriptionRef.current.value.trim()) {
                    error = "Product Description is required";
                }
                break;
            case "price":
                if (!priceRef.current.value.trim()) {
                    error = "Price is required";
                }
                break;
            case "category":
                if (!categoryRef.current.value.trim()) {
                    error = "Category is required";
                }
                break;
            case "brand":
                if (!brandRef.current.value.trim()) {
                    error = "Brand is required";
                }
                break;
            case "imageURL":
                if (!imageURLRef.current.value.trim()) {
                    error = "Image URL is required";
                }
                break;
            default:
                break;
        }
        setErrors((prevErrors) => ({
            ...prevErrors,
            [name]: error
        }));
    }
const getimageURLError = (imageURL) => {
    if (!imageURL.trim()) {
        return 'Product image URL is required';
    }
 
    try {
        const url = new URL(imageURL);
        if (url.protocol !== 'http:' && url.protocol !== 'https:') {
            return 'Image URL must use http or https';
        }
    } catch {
        return 'Enter a valid image URL';
    }
 
    return '';
};

    const validate = () => {
        const newErrors = {};
        if (!productNameRef.current.value.trim()) {
            newErrors.productName = 'Product name is required';
        }
        if (!productDescriptionRef.current.value.trim()) {
            newErrors.productDescription = 'Description is required';
        }
        if (!priceRef.current.value || isNaN(priceRef.current.value) || Number(priceRef.current.value) <= 0) {
            newErrors.price = 'Valid price is required';
        }
        if (!categoryRef.current.value.trim()) {
            newErrors.category = 'Category is required';
        }
        if (!brandRef.current.value.trim()) {
            newErrors.brand = 'Brand is required';
        }
        // Previous file-upload validation:
        // const fileInput = imageUrlRef.current;
        // if (!fileInput.files || fileInput.files.length === 0) {
        //     newErrors.imageUrl = 'Product image is required';
        // } else {
        //     const fileName = fileInput.files[0].name;
        //     if (!/\.(jpg|jpeg|png|gif)$/i.test(fileName)) {
        //         newErrors.imageUrl = 'Image must be jpg, jpeg, png, or gif';
        //     }
        // }
        const imageURLError = getimageURLError(imageURLRef.current.value);
        if (imageURLError) {
            newErrors.imageURL = imageURLError;
        }
        return newErrors;
    };
    const handleSubmit = async (e) => {
        e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
        setErrors(validationErrors);
        return;
    }
    setErrors({});
    const product = {
        productName: productNameRef.current.value,
        productDescription: productDescriptionRef.current.value,
        price: parseFloat(priceRef.current.value),
        category: categoryRef.current.value,
        brand: brandRef.current.value,
        // Previous file-based value:
        // imageUrl: `images/${imageUrlRef.current.files[0].name}`,
        imageURL: imageURLRef.current.value.trim(),
    };
    // Always call addProduct
    const productAdded = await addProduct(product);
    console.log(productAdded);
    e.target.reset();



    }

    return (
        <>
           <div className="container-fluid min-vh-100 d-flex justify-content-center align-items-center bg-light">
            <div className="col-md-7 col-lg-6">
                <div className="card shadow-lg border-0">
                    <div className="card-header bg-success text-white text-center py-3 rounded-top">
                        <h2 className="mb-0">Add Product</h2>
                    </div>
                    <div className="card-body p-4">
                        <form onSubmit={handleSubmit} noValidate>
                            <div className="mb-3">
                                <label htmlFor="productName" className="form-label">Product Name:</label>
                                <input type="text" id="productName" name="productName" className={`form-control ${errors.productName ? 'is-invalid' : ''}`} ref={productNameRef} onBlur={handleBlur} />
                                {errors.productName && <div className="invalid-feedback">{errors.productName}</div>}
                            </div>
                            <div className="mb-3">
                                <label htmlFor="productDescription" className="form-label">Description:</label>
                                <textarea id="productDescription" name="productDescription" className={`form-control ${errors.productDescription ? 'is-invalid' : ''}`} ref={productDescriptionRef} onBlur={handleBlur} />
                                {errors.productDescription && <div className="invalid-feedback">{errors.productDescription}</div>}
                            </div>
                            <div className="mb-3">
                                <label htmlFor="price" className="form-label">Price:</label>
                                <input type="number" id="price" name="price" step="0.01" className={`form-control ${errors.price ? 'is-invalid' : ''}`} ref={priceRef} onBlur={handleBlur} />
                                {errors.price && <div className="invalid-feedback">{errors.price}</div>}
                            </div>
                            <div className="mb-3">
                                <label htmlFor="category" className="form-label">Category:</label>
                                <input type="text" id="category" name="category" className={`form-control ${errors.category ? 'is-invalid' : ''}`} ref={categoryRef} onBlur={handleBlur} />
                                {errors.category && <div className="invalid-feedback">{errors.category}</div>}
                            </div>
                            <div className="mb-3">
                                <label htmlFor="brand" className="form-label">Brand:</label>
                                <input type="text" id="brand" name="brand" className={`form-control ${errors.brand ? 'is-invalid' : ''}`} ref={brandRef} onBlur={handleBlur} />
                                {errors.brand && <div className="invalid-feedback">{errors.brand}</div>}
                            </div>
                            <div className="mb-3">
                                {/* Previous file input:
                                <label className="form-label">Image:</label>
                                <input type="file" name="imageUrl" className={`form-control ${errors.imageUrl ? 'is-invalid' : ''}`} ref={imageUrlRef} onBlur={handleBlur} /> */}
                                <label htmlFor="imageURL" className="form-label">Image URL:</label>
                                <input type="url" id="imageURL" name="imageURL" placeholder="https://example.com/product-image.jpg" className={`form-control ${errors.imageURL ? 'is-invalid' : ''}`} ref={imageURLRef} onBlur={handleBlur} />
                                {errors.imageURL && <div className="invalid-feedback">{errors.imageURL}</div>}
                            </div>
                            <button type="submit" className="btn btn-success w-100 mt-3">Add Product</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        </>
    )
}
