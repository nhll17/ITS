import { useEffect, useState, useContext } from "react";
import { deleteProduct, getAllProducts } from "../services/productService";
import { AuthContext } from "../context/AuthContext";
import { deleteInventoryItem, getStockByProductId } from "../services/inventoryService";
import { Link } from "react-router-dom";

function ViewAllProducts() {
    const [products, setProducts] = useState([]);
    const [stockMap, setStockMap] = useState({});
    const { user } = useContext(AuthContext);
    const isAdmin = user && user.userRole === 'admin';

const fetchProductsAndStock = async () => {
            try {
                const productsData = await getAllProducts();
                setProducts(productsData);

                const stockArr = await Promise.all(productsData.map(async (product) => {
                    const quantity = await getStockByProductId(product.productId);
                    return { productId: product.productId, quantity };
                }));

                const stockObj = {};
                stockArr.forEach((item) => {
                    stockObj[item.productId] = item.quantity;
                });

                setStockMap(stockObj);
            }
            catch (error) {
                console.log("Error fetching products and stock:", error);
            }
        }
    useEffect(() => {
        
        fetchProductsAndStock();
    }, []);

    const handleDelete = async (productId) => {
    const confirmed = window.confirm('Are you sure you want to delete this product?');
    if (confirmed) {
      try {
        await deleteProduct(productId);
        await fetchProductsAndStock(); // Refresh the product list after deletion
        const result = await deleteInventoryItem(productId);
       
        if (result && result.success) {
          alert('Product and its inventory deleted successfully.');
        }
        //setProducts(products.filter(product => product.productId !== productId));
        // refresh the product list
        const allProducts = await getAllProducts();
        setProducts(allProducts);
      } catch (error) {
        console.error('Error deleting product:', error);
      }
    }
  };
    return (
         <div className="container mt-5">
      <h2 className="mb-4">All Products</h2>
      {isAdmin ? (
        <table className="table table-bordered table-hover align-middle text-center">
          <thead className="table-primary">
            <tr>
              <th style={{ width: '120px' }}>Image</th>
              <th style={{ width: '180px' }}>Name</th>
              <th style={{ width: '120px' }}>Price</th>
              <th>Description</th>
              <th style={{ width: '120px' }}>Stock</th>
              <th style={{ width: '180px' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map(product => (
              <tr key={product.productId} style={{ height: '140px' }}>
                <td style={{ verticalAlign: 'middle' }}>
                  <img
                    src={product.imageURL}
                    alt={product.productName}
                    style={{ width: '100px', height: '100px', objectFit: 'cover', borderRadius: '8px' }}
                  />
                </td>
                <td style={{ verticalAlign: 'middle', fontWeight: 'bold' }}>{product.productName}</td>
                <td style={{ verticalAlign: 'middle', fontWeight: 'bold' }}>${product.price}</td>
                <td style={{ verticalAlign: 'middle' }}>{product.productDescription}</td>
                <td style={{ verticalAlign: 'middle', fontWeight: 'bold' }}>{stockMap[product.productId] ?? 0}</td>
                <td style={{ verticalAlign: 'middle' }}>
                  <Link to={`/update-product/${product.productId}`} className="btn btn-warning btn-sm me-2">Update</Link>
                  <button className="btn btn-danger btn-sm" onClick={() => handleDelete(product.productId)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <div className="row">
          {products.map(product => (
            <div className="col-md-4 mb-4 d-flex" key={product.productId}>
              <div className="card h-100 w-100 d-flex flex-column">
                <img
                  src={product.imageURL}
                  className="card-img-top"
                  alt={product.productName}
                  style={{ height: '200px', objectFit: 'cover' }}
                />
                <div className="card-body d-flex flex-column justify-content-between">
                  <h5 className="card-title">{product.productName}</h5>
                  <p className="card-text">{product.productDescription}</p>
                  <p className="card-text fw-bold">${product.price}</p>
                  <p className="card-text">Stock: <span className="fw-bold">{stockMap[product.productId] ?? 0}</span></p>
                  <Link className="btn btn-primary mt-2" to={`/place-order/${product.productId}`}>Place Order</Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
    );
}

export default ViewAllProducts;