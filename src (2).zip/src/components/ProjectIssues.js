import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { getProjectById, getProjectIssues } from "../services/projectService";
import IssueCard from "./IssueCard";
import AlertMessage from "./AlertMessage";

export default function ProjectIssues() {
  const { projectId } = useParams();
  const [project, setProject] = useState(null);
  const [issues, setIssues] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([getProjectById(projectId), getProjectIssues(projectId)])
      .then(([p, i]) => { setProject(p); setIssues(i); })
      .catch(err => setError(err.userMessage || "Unable to load project issues."));
  }, [projectId]);

  return (
    <div className="page-container">
      <div className="container">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <div><h2 className="mb-1">{project?.projectName || "Project"}</h2><p className="text-muted mb-0">Project issues</p></div>
          <Link to="/owner" className="btn btn-outline-secondary">Back</Link>
        </div>
        <AlertMessage message={error} />
        {issues.length === 0 ? <div className="card dashboard-card"><div className="card-body text-center py-5">No issues for this project.</div></div> :
          <div className="row g-3">{issues.map(i => <div className="col-md-6 col-lg-4" key={i.issueId}><IssueCard issue={i} /></div>)}</div>}
      </div>
    </div>
  );
}
