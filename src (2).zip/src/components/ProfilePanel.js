import { useEffect, useState } from "react";
import { getAllProjects } from "../services/projectService";
import { getAllIssues } from "../services/issueService";

export default function ProfilePanel({ user }) {
  const [counts, setCounts] = useState({ projects: 0, issues: 0 });

  useEffect(() => {
    async function load() {
      try {
        const [projects, issues] = await Promise.all([getAllProjects(), getAllIssues()]);
        setCounts({
          projects: projects.filter(p => Number(p.projectOwner) === Number(user.userId)).length,
          issues: issues.filter(i => Number(i.createdBy) === Number(user.userId)).length
        });
      } catch (_) {}
    }
    if (user?.userId) load();
  }, [user]);

  return (
    <div className="profile-panel p-3">
      <div className="d-flex align-items-center gap-3">
        {user?.profile ? (
          <img className="profile-avatar" src={user.profile} alt={user.name} />
        ) : (
          <div className="profile-avatar d-flex align-items-center justify-content-center fw-bold fs-4">
            {user?.name?.charAt(0)?.toUpperCase()}
          </div>
        )}
        <div>
          <h5 className="mb-1">{user?.name}</h5>
          <div className="text-muted small">{user?.email}</div>
        </div>
      </div>
      <hr />
      <div className="row text-center">
        <div className="col-6">
          <div className="fs-4 fw-bold">{counts.projects}</div>
          <div className="small text-muted">Projects Created</div>
        </div>
        <div className="col-6">
          <div className="fs-4 fw-bold">{counts.issues}</div>
          <div className="small text-muted">Issues Created</div>
        </div>
      </div>
    </div>
  );
}
