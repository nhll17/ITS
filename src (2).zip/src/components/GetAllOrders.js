import { useState, useEffect, useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { getOrders, cancelOrder, deliverOrder } from "../services/orderService";

export default function GetAllOrders() {

       const [orders, setOrders] = useState([]);
    const { user } = useContext(AuthContext);
    const [cancel, setCancel] = useState(false);
    const [deliver, setDeliver] = useState(false);
 
    useEffect(() => {
        const fetchOrders = async () => {
            const result = await getOrders();
            setOrders(result);
        };
        fetchOrders();
    }, [cancel, deliver]);
 
    // Filter orders for customer role
    const filteredOrders = user && user.userRole === 'customer'
        ? orders.filter(order => String(order.customerId) === String(user.userId))
        : orders;
 
    const handleCancelOrder = async (orderId) => {
        // Implement cancel order logic
        if(await cancelOrder(orderId)){
            setCancel(true);
            alert("Order cancelled successfully");
        }
    };
    const handleDeliverOrder = async (orderId) => {
        // Implement deliver order logic
        if(await deliverOrder(orderId)){
            setDeliver(true);
            alert("Order delivered successfully");
        }  
    }
    return(
         <div className="container mt-4">
            <h2 className="mb-4">All Orders</h2>
            <table className="table table-striped table-bordered">
                <thead className="thead-dark">
                    <tr>
                        <th>Order ID</th>
                        <th>Customer ID</th>
                        <th>Product ID</th>
                        <th>Quantity</th>
                        <th>Order Amount</th>
                        <th>Order Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredOrders.map(order => (
                        <tr key={order.orderId}>
                            <td>{order.orderId}</td>
                            <td>{order.customerId}</td>
                            <td>{order.productId}</td>
                            <td>{order.quantity}</td>
                            <td>{order.orderAmount}</td>
                            <td>{order.orderDate}</td>
                            <td>{order.status}</td>
                            {user && user.userRole === 'customer' && (
                                <td>
                                    <button className="btn btn-danger btn-sm" disabled={order.status === 'Delivered' || order.status==='Cancelled'} onClick={() => handleCancelOrder(order.orderId)}>Cancel</button>
                                </td>
                            )}
                            {user && user.userRole === 'admin' && (
                                    <td>
                                        <button className="btn btn-info btn-sm" disabled={order.status === 'Delivered' || order.status==='Cancelled'} onClick={() => handleDeliverOrder(order.orderId)}>Delivered</button>
                                    </td>
                            )}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    )
}
       