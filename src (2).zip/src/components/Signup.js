import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { registerUser } from "../services/userService";
import AlertMessage from "./AlertMessage";

export default function Signup() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: "", email: "", password: "", role: "", profile: ""
  });
  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState("");
const validate = () => {
  const e = {};

  if (!form.name.trim()) {
    e.name = "Name is required.";
  } else if (form.name.trim().length < 2) {
    e.name = "Name must be at least 2 characters.";
  }

  if (!form.email.trim()) {
    e.email = "Email is required.";
  } else if (!/^\S+@\S+\.\S+$/.test(form.email)) {
    e.email = "Enter a valid email.";
  }

  if (!form.password) {
    e.password = "Password is required.";
  } else if (form.password.length < 8) {
    e.password = "Password must be at least 8 characters.";
  }

  if (!form.role) {
    e.role = "Role is required.";
  }

  if (form.profile && !/^https?:\/\/.+/i.test(form.profile)) {
    e.profile = "Enter a valid image URL.";
  }

  return e;
};

const formIsValid = Object.keys(validate()).length === 0;



  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: "" });
  };

const submit = async (e) => {
    e.preventDefault();
    setMessage("");
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length) return;

    try {
      const saved = await registerUser({
        name: form.name.trim(),
        email: form.email.trim(),
        password: form.password,
        role: Number(form.role),
        profile: form.profile.trim() || null
      });
      setMessage(`Registration successful. Your User ID is ${saved.userId}. Redirecting to login...`);
      setTimeout(() => navigate("/login"), 1400);
    } catch (err) {
      setMessage(err.userMessage || "Unable to register.");
    }
  };

  return (
    <div className="auth-page">
      <div className="card auth-card shadow">
        <div className="card-header bg-primary text-white text-center py-3">
          <h2 className="mb-0">Sign Up</h2>
        </div>
        <div className="card-body p-4">
          <AlertMessage type={message.startsWith("Registration") ? "success" : "danger"} message={message} />
          <form onSubmit={submit} noValidate>
            <div className="mb-3">
              <label className="form-label">Name</label>
              <input name="name" value={form.name} onChange={handleChange}
                className={`form-control ${errors.name ? "is-invalid" : ""}`} />
              {errors.name && <div className="invalid-feedback">{errors.name}</div>}
            </div>

            <div className="mb-3">
              <label className="form-label">Email</label>
              <input type="email" name="email" value={form.email} onChange={handleChange}
                className={`form-control ${errors.email ? "is-invalid" : ""}`} />
              {errors.email && <div className="invalid-feedback">{errors.email}</div>}
            </div>

            <div className="mb-3">
              <label className="form-label">Password</label>
              <input type="password" name="password" value={form.password} onChange={handleChange}
                className={`form-control ${errors.password ? "is-invalid" : ""}`} />
              {errors.password && <div className="invalid-feedback">{errors.password}</div>}
            </div>

            <div className="mb-3">
              <label className="form-label">Role</label>
              <select name="role" value={form.role} onChange={handleChange}
                className={`form-select ${errors.role ? "is-invalid" : ""}`}>
                <option value="">Select role</option>
                <option value="1">Owner</option>
                <option value="2">Assignee</option>
              </select>
              {errors.role && <div className="invalid-feedback">{errors.role}</div>}
            </div>

            <div className="mb-4">
              <label className="form-label">Profile Image URL <span className="text-muted">(optional)</span></label>
              <input type="url" name="profile" value={form.profile} onChange={handleChange}
                className={`form-control ${errors.profile ? "is-invalid" : ""}`}
                placeholder="https://..." />
              {errors.profile && <div className="invalid-feedback">{errors.profile}</div>}
            </div>

            <button type="submit" className="btn btn-primary w-100" disabled={!formIsValid}>Create Account</button>
          </form>
          <div className="text-center mt-3">Already registered? <Link to="/login">Login</Link></div>
        </div>
      </div>
    </div>
  );
}
