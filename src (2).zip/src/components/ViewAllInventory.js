import React, { useState, useEffect } from "react";
import { getAllInventoryItems, updateInventoryItemStock } from "../services/inventoryService";

export default function ViewAllInventory() {
    const [inventoryItems, setInventoryItems] = useState([]);
    const [stock, setStock] = useState({});
    useEffect(() => {
        const fetchInventoryItems = async () => {
            const items = await getAllInventoryItems();
            setInventoryItems(items);
        };
        fetchInventoryItems();
    }, []);

     const handleUpdateStock = async (productId) => {
        const newStock = Number(stock[productId]);
        console.log(newStock);
        if (!isNaN(newStock)) {
            try {
                const result = await updateInventoryItemStock(productId, newStock);
                alert(result);
                const items = await getAllInventoryItems();
                setInventoryItems(items);
            } catch (error) {
                console.error('Error updating inventory item stock:', error);
            }
        } else {
            alert('Please enter a valid number for stock.');
        }
    };
    return (
        <>
  <div className="container mt-5">
            <h2 className="mb-4">All Inventory Items</h2>
            <table className="table table-bordered table-hover align-middle text-center">
                <thead className="table-primary">
                    <tr>
                        <th>Inventory ID</th>
                        <th>Product Id</th>
                        <th>Stock</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {inventoryItems.map(item => (
                        <tr key={item.inventoryId}>
                            <td>{item.inventoryId}</td>
                            <td>{item.productId}</td>
                            <td><input type="number" value={stock[item.productId] ?? item.stock}
                                onChange={e =>
                                    setStock(prev => ({
                                        ...prev,
                                        [item.productId]: e.target.value
                                    }))
                                } id={`stock-input-${item.productId}`} /></td>
                            <td>
                                <button className="btn btn-warning btn-sm me-2" onClick={() => handleUpdateStock(item.productId)}>Update Stock</button>
                                {/* <button className="btn btn-danger btn-sm" onClick={() => handleDelete(item.inventoryId)}>Delete</button> */}
                            </td>
                           
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
 
        </>
    )
}
