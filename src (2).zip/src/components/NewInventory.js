import { useState, useEffect } from "react";
import { getProductsNotInStock, createInventoryItem } from "../services/inventoryService";

export default function NewInventory() {


    const [products, setProducts] = useState([]);
    const [inventory, setInventory] = useState({ inventoryId: '', productId: '', stock: 0 });
 
    useEffect(() => {
        const fetchProducts = async () => {
            const result = await getProductsNotInStock();
            setProducts(result);
             console.log(products);
        };
        fetchProducts();
    }, []);
 
    const handleSubmit = async (e) => {
        e.preventDefault();
        // Handle form submission
        console.log('New Inventory Item:', inventory);
        await createInventoryItem(inventory);
        alert('New Inventory Item Created');
        //setInventory(await getAllInventoryItems());
        setProducts(prev =>
            //prev.filter(product => product.productId !== inventory.productId)
            prev.filter(product => String(product.productId) !== String(inventory.productId))
        );
       
       
        setInventory({ inventoryId: '', productId: '', stock: '' });
    }
    return(
       <div className="container mt-5 d-flex justify-content-center align-items-center" style={{ minHeight: '80vh' }}>
            <div className="col-md-6 col-lg-5">
                <h2 className="mb-4 text-center">Add New Inventory Item</h2>
                <form onSubmit={handleSubmit} className="card p-4 shadow-lg border-0">
                    <div className="mb-3">
                        <label className="form-label">Product ID:</label>
                        <select className="form-select" value={inventory.productId} onChange={(e) => setInventory({ ...inventory, productId: e.target.value })}>
                            <option value="">Select Product</option>
                            {products.map(product => (
                                <option key={product.productId} value={product.productId}>
                                    {product.productName}
                                </option>
                            ))}
                        </select>
                    </div>
                    <div className="mb-3">
                        <label className="form-label">Stock:</label>
                        <input type="number" className="form-control" value={inventory.stock ?? ''} onChange={(e) => setInventory({ ...inventory, stock: e.target.value })} />
                    </div>
                    <button type="submit" className="btn btn-success w-100 mt-3">Add Item</button>
                </form>
            </div>
        </div>
    )
}
       