import { useState, useEffect, useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { getProductById, getStockByProductId } from "../services/productService";
import { createOrder } from "../services/orderService";

export default function PlaceOrderForm() {

        const [quantity, setQuantity] = useState(1);
    const [product, setProduct] = useState(null);
    const { productId } = useParams();
    const [error, setError] = useState(false); // Initialize error state
    const [loading, setLoading] = useState(true);
    const [stockQuantity, setStockQuantity] = useState(0); // State to hold stock quantity
    const [invalidQuantity, setInvalidQuantity] = useState(false); // State to hold invalid quantity
    // const [order, setOrder] = useState(null);
    const { user } = useContext(AuthContext);
    const navigate = useNavigate();
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    // Debug user and customerId
    console.log('user:', user);
    const customerId = user ? user.userId : undefined;
    console.log('customerId:', customerId);
    const order = {
        customerId: customerId,
        productId: productId,
        quantity: quantity,
        imageURL: product.imageURL,
        orderDate: new Date()
    };
    console.log('order:', order);
    if (await createOrder(order)) {
        alert('Order placed successfully!');
        navigate('/');
    }
  };
 
    useEffect(() => {
        const fetchProduct = async () => {
            try {
                const data = await getProductById(productId);
                setStockQuantity(await getStockByProductId(productId));
               
                setProduct({
                    productId: data.productId,
                    productName: data.productName,
                    productDescription: data.productDescription,
                    price: data.price,
                    // stockQuantity: stockQuantity,
                    imageURL: data.imageURL
                });
                setQuantity(1); // Reset quantity when product loads
            } catch (error) {
                // Optionally handle error state
            } finally {
                setLoading(false);
            }
        };
        fetchProduct();
    }, [productId]);
   
    const handleQuantityChange = (e) => {
        const value = Number(e.target.value);
        setQuantity(value);
        if (product) {
            console.log('Current quantity:', value);
            console.log('Available stock:', stockQuantity);
            if (value > stockQuantity ) {
                setError(true);
                console.log('Error: Quantity out of bounds', value, stockQuantity);
            }
            else if(value < 1) {
                //setError(true);
                setInvalidQuantity(true);
                console.log('Error: Quantity must be at least 1', value);
            }
            else {
                setError(false);
                setInvalidQuantity(false);
                console.log('Quantity is within bounds');
            }
        }
    };
   
    if (loading || !product) {
        return (
            <div className="container d-flex justify-content-center align-items-center" style={{ minHeight: '80vh' }}>
                <div className="text-center">Loading...</div>
            </div>
        );
    }
    return(
        <div className="container d-flex justify-content-center align-items-center" style={{ minHeight: '80vh' }}>
            <div className="card shadow p-4" style={{ maxWidth: '400px', width: '100%' }}>
                <form onSubmit={handleSubmit}>
                    <div className="text-center mb-3">
                        <img
                            src={product.imageURL || null}
                            alt={product.productName}
                            className="img-fluid rounded"
                            style={{ width: '150px', height: '150px', objectFit: 'cover' }}
                        />
                    </div>
                    <h4 className="card-title text-center mb-2">{product.productName}</h4>
                    <p className="card-text text-center mb-2">{product.productDescription}</p>
                    <div className="mb-2 text-center">
                        <span className="badge bg-primary">Price: ${product.price}</span>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="quantity" className="form-label">Quantity</label>
                        <input
                            id="quantity"
                            type="number"
                            className="form-control"
                            min="1"
                            value={quantity}
                            onChange={handleQuantityChange}
                            required
                        />
                    </div>
                    {error && (
                        <div className="alert alert-danger" role="alert">
                            Only {stockQuantity} items available in stock!
                        </div>
                    )}
                    {invalidQuantity && (
                        <div className="alert alert-danger" role="alert">
                            Quantity must be at least 1!
                        </div>
                    )}
                    <div className="d-grid">
                        <button type="submit" className="btn btn-primary" disabled={quantity > stockQuantity}>Checkout</button>
                    </div>
                </form>
            </div>
        </div>
    )
}
       