import { Link, useNavigate } from "react-router-dom";
import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";

export default function NavBar() {
  const { isLoggedIn, user, isOwner, isAssignee, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
      <div className="container">
        <Link className="navbar-brand" to="/">
          Issue Tracking System
        </Link>

        <button className="navbar-toggler" type="button" data-bs-toggle="collapse"
          data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false">
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="mainNav">
          <ul className="navbar-nav me-auto">
            {isLoggedIn && isOwner && (
              <>
                <li className="nav-item"><Link className="nav-link" to="/owner">Dashboard</Link></li>
                <li className="nav-item"><Link className="nav-link" to="/projects/create">Create Project</Link></li>
                <li className="nav-item"><Link className="nav-link" to="/issues/create">Create Issue</Link></li>
              </>
            )}
            {isLoggedIn && isAssignee && (
              <li className="nav-item"><Link className="nav-link" to="/assignee">Dashboard</Link></li>
            )}
          </ul>

          <ul className="navbar-nav align-items-lg-center">
            {isLoggedIn ? (
              <>
                <li className="nav-item">
                  <span className="nav-link">Welcome, {user?.name}</span>
                </li>
                <li className="nav-item">
                  <button className="btn btn-sm btn-light text-primary ms-lg-2" onClick={handleLogout}>
                    Logout
                  </button>
                </li>
              </>
            ) : (
              <>
                <li className="nav-item"><Link className="nav-link" to="/login">Login</Link></li>
                <li className="nav-item"><Link className="nav-link" to="/signup">Sign Up</Link></li>
              </>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
}
