import { Link } from "react-router-dom";

const badgeClass = (value) => {
  const v = String(value || "").toUpperCase();
  if (v === "CRITICAL" || v === "HIGH") return "danger";
  if (v === "MEDIUM" || v === "IN_PROGRESS") return "warning";
  if (v === "RESOLVED" || v === "CLOSED") return "success";
  return "secondary";
};

export default function IssueCard({ issue, assigneeView = false }) {
  return (
    <div className="card issue-card h-100">
      <div className="card-body d-flex flex-column">
        <div className="d-flex justify-content-between gap-2 mb-2">
          <span className="badge bg-light text-dark border">#{issue.issueId}</span>
          <span className={`badge text-bg-${badgeClass(issue.priority)}`}>{issue.priority}</span>
        </div>

        <h5 className="card-title">{issue.summary}</h5>
        <p className="card-text text-muted small flex-grow-1">
          {issue.description || "No description provided."}
        </p>

        <div className="mb-3">
          <span className={`badge text-bg-${badgeClass(issue.status)} me-2`}>
            {issue.status}
          </span>
          <span className="badge text-bg-info">{issue.type}</span>
        </div>

        <Link
          className="btn btn-outline-primary btn-sm"
          to={assigneeView ? `/assignee/issues/${issue.issueId}` : `/issues/${issue.issueId}`}
        >
          View Details
        </Link>
      </div>
    </div>
  );
}
