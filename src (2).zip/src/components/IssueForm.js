import { useEffect, useMemo, useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { createIssue } from "../services/issueService";
import { getAllProjects } from "../services/projectService";
import { getAllUsers } from "../services/userService";
import { AuthContext } from "../context/AuthContext";
import AlertMessage from "./AlertMessage";

const PRIORITIES = ["LOW", "MEDIUM", "HIGH", "CRITICAL"];
const STATUSES = ["OPEN", "IN_PROGRESS", "RESOLVED", "CLOSED"];
const TYPES = ["BUG", "FEATURE", "TASK"];
const STATUS_LABELS = {
  OPEN: "To-Do",
  IN_PROGRESS: "Development",
  RESOLVED: "Testing",
  CLOSED: "Completed"
};

function isPrime(n) {
  n = Number(n);
  if (!Number.isInteger(n) || n < 2) return false;
  for (let i = 2; i <= Math.sqrt(n); i++) if (n % i === 0) return false;
  return true;
}

export default function IssueForm() {
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();
  const [projects, setProjects] = useState([]);
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({
    projectId: "", assignee: "", description: "", summary: "",
    priority: "", status: "OPEN", createdBy: user?.userId || "",
    sprint: "", storyPoint: "", tags: "", type: ""
  });
  const [errors, setErrors] = useState({});
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([getAllProjects(), getAllUsers()])
      .then(([p, u]) => { setProjects(p); setUsers(u.filter(x => Number(x.role) === 2)); })
      .catch(err => setError(err.userMessage || "Unable to load project/user data."));
  }, []);

  const ownerProjects = useMemo(
    () => projects.filter(p => Number(p.projectOwner) === Number(user?.userId)),
    [projects, user]
  );

  const validate = () => {
    const e = {};
    if (!form.summary.trim()) e.summary = "Summary is required.";
    else if (form.summary.length > 150) e.summary = "Maximum 150 characters.";
    //else if (!/^[A-Za-z0-9\\s\\-\\/\\|\\.]+$/.test(form.summary)) e.summary = "Special characters are not allowed except -, /, | and .";
    if (!form.projectId) e.projectId = "Project is required.";
    if (!form.priority) e.priority = "Priority is required.";
    if (!form.status) e.status = "Status is required.";
    if (!form.type) e.type = "Type is required.";
    if (!form.assignee) e.assignee = "Assignee is required.";
    if (form.description.length > 2000) e.description = "Maximum 2000 characters.";
    //if (form.sprint && !/^\\d+$/.test(form.sprint)) e.sprint = "Sprint must be a number (1, 2, 3, ...).";
    if (form.sprint.trim() !== "") {
  const sprintNumber = Number(form.sprint);

  if (!Number.isInteger(sprintNumber) || sprintNumber < 1) {
    e.sprint = "Sprint must be a positive whole number.";
  }
}
    if (form.tags.length > 100) e.tags = "Maximum 100 characters.";
    if (form.storyPoint && !isPrime(form.storyPoint)) e.storyPoint = "Story point must be a prime number.";
    return e;
  };

  const change = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: "" });
  };

  const reset = () => setForm({
    projectId: "", assignee: "", description: "", summary: "",
    priority: "", status: "OPEN", createdBy: user?.userId || "",
    sprint: "", storyPoint: "", tags: "", type: ""
  });

  const submit = async e => {
    e.preventDefault();
    setError("");
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length) return;

    try {
      await createIssue({
        projectId: Number(form.projectId),
        assignee: Number(form.assignee),
        description: form.description.trim() || null,
        summary: form.summary.trim(),
        priority: form.priority,
        status: form.status,
        createdBy: Number(user.userId),
        sprint: form.sprint.trim() || null,
        storyPoint: form.storyPoint ? Number(form.storyPoint) : null,
        tags: form.tags.trim() || null,
        type: form.type
      });
      navigate("/owner");
    } catch (err) {
      setError(err.userMessage || "Unable to create issue.");
    }
  };

  return (
    <div className="page-container">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-xl-9">
            <div className="card dashboard-card">
              <div className="card-header bg-primary text-white"><h4 className="mb-0">Create Issue</h4></div>
              <div className="card-body p-4">
                <AlertMessage message={error} />
                <form onSubmit={submit} noValidate>
                  <div className="row">
                    <div className="col-md-8 mb-3">
                      <label className="form-label">Summary *</label>
                      <input name="summary" value={form.summary} onChange={change} maxLength="200"
                        className={`form-control ${errors.summary ? "is-invalid" : ""}`} />
                      {errors.summary && <div className="invalid-feedback">{errors.summary}</div>}
                    </div>
                    <div className="col-md-4 mb-3">
                      <label className="form-label">Type *</label>
                      <select name="type" value={form.type} onChange={change}
                        className={`form-select ${errors.type ? "is-invalid" : ""}`}>
                        <option value="">Select</option>
                        {TYPES.map(x => <option key={x}>{x}</option>)}
                      </select>
                      {errors.type && <div className="invalid-feedback">{errors.type}</div>}
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Project *</label>
                      <select name="projectId" value={form.projectId} onChange={change}
                        className={`form-select ${errors.projectId ? "is-invalid" : ""}`}>
                        <option value="">Select project</option>
                        {ownerProjects.map(p => <option key={p.projectId} value={p.projectId}>{p.projectName}</option>)}
                      </select>
                      {errors.projectId && <div className="invalid-feedback">{errors.projectId}</div>}
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Assignee *</label>
                      <select name="assignee" value={form.assignee} onChange={change}
                        className={`form-select ${errors.assignee ? "is-invalid" : ""}`}>
                        <option value="">Select assignee</option>
                        {users.map(u => <option key={u.userId} value={u.userId}>{u.name} (#{u.userId})</option>)}
                      </select>
                      {errors.assignee && <div className="invalid-feedback">{errors.assignee}</div>}
                    </div>
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Description</label>
                    <textarea name="description" value={form.description} onChange={change} rows="4" maxLength="2000"
                      className={`form-control ${errors.description ? "is-invalid" : ""}`} />
                    {errors.description && <div className="invalid-feedback">{errors.description}</div>}
                  </div>

                  <div className="row">
                    <div className="col-md-4 mb-3">
                      <label className="form-label">Priority *</label>
                      <select name="priority" value={form.priority} onChange={change}
                        className={`form-select ${errors.priority ? "is-invalid" : ""}`}>
                        <option value="">Select</option>{PRIORITIES.map(x => <option key={x}>{x}</option>)}
                      </select>
                      {errors.priority && <div className="invalid-feedback">{errors.priority}</div>}
                    </div>
                    <div className="col-md-4 mb-3">
                      <label className="form-label">Status *</label>
                      <select name="status" value={form.status} onChange={change}
                        className={`form-select ${errors.status ? "is-invalid" : ""}`}>
                        {STATUSES.map(x => <option key={x} value={x}>{STATUS_LABELS[x]}</option>)}
                      </select>
                      {errors.status && <div className="invalid-feedback">{errors.status}</div>}
                    </div>
                    <div className="col-md-4 mb-3">
                      <label className="form-label">Story Point</label>
                      <input type="number" min="2" name="storyPoint" value={form.storyPoint} onChange={change}
                        className={`form-control ${errors.storyPoint ? "is-invalid" : ""}`} />
                      {errors.storyPoint && <div className="invalid-feedback">{errors.storyPoint}</div>}
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Tags</label>
                      <input name="tags" value={form.tags} onChange={change} maxLength="100"
                        className={`form-control ${errors.tags ? "is-invalid" : ""}`} placeholder="frontend, urgent" />
                      {errors.tags && <div className="invalid-feedback">{errors.tags}</div>}
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label">Sprint</label>
                      <input name="sprint" value={form.sprint} onChange={change} maxLength="100"
                        className={`form-control ${errors.sprint ? "is-invalid" : ""}`}  />
                      {errors.sprint && <div className="invalid-feedback">{errors.sprint}</div>}
                    </div>
                  </div>

                  <div className="d-flex gap-2 mt-2">
                    <button className="btn btn-primary" type="submit" disabled={Object.keys(validate()).length > 0}>Create Issue</button>
                    <button className="btn btn-outline-secondary" type="button" onClick={reset}>Reset</button>
                    <button className="btn btn-light ms-auto" type="button" onClick={() => navigate("/owner")}>Cancel</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
//disabled={Object.keys(validate()).length > 0}