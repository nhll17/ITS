import { useEffect, useMemo, useState, useContext } from "react";
import { Link } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { getProjectsByOwner } from "../services/projectService";
import { getAllIssues } from "../services/issueService";
import { getAllUsers } from "../services/userService";
import IssueCard from "./IssueCard";
import ProfilePanel from "./ProfilePanel";
import AlertMessage from "./AlertMessage";

export default function OwnerDashboard() {
  const { user } = useContext(AuthContext);
  const [projects, setProjects] = useState([]);
  const [issues, setIssues] = useState([]);
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try {
      setLoading(true);
      const [p, i, u] = await Promise.all([
        getProjectsByOwner(user.userId),
        getAllIssues(),
        getAllUsers()
      ]);
      setProjects(p);
      setIssues(i);
      setUsers(u);
    } catch (err) {
      setError(err.userMessage || "Unable to load dashboard.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { if (user?.userId) load(); }, [user?.userId]);

  const ownerIssues = useMemo(() => {
    const q = search.trim().toLowerCase();
    return issues
      .filter(i => Number(i.createdBy) === Number(user.userId) || projects.some(p => Number(p.projectId) === Number(i.projectId)))
      .filter(i => !q || `${i.summary} ${i.description || ""}`.toLowerCase().includes(q));
  }, [issues, projects, search, user]);

  const assignees = users.filter(u => Number(u.role) === 2);

  return (
    <div className="page-container">
      <div className="container">
        <div className="row g-4">
          <div className="col-lg-3">
            <ProfilePanel user={user} />
            <div className="list-group mt-3">
              <Link className="list-group-item list-group-item-action sidebar-link active" to="/owner">Project Dashboard</Link>
              <Link className="list-group-item list-group-item-action sidebar-link" to="/projects/create">Create Project</Link>
              <Link className="list-group-item list-group-item-action sidebar-link" to="/issues/create">Create Issue</Link>
            </div>
          </div>

          <div className="col-lg-9">
            <div className="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-3">
              <div>
                <h2 className="mb-1">Project Owner Dashboard</h2>
                <p className="text-muted mb-0">Manage projects and track issues in real time.</p>
              </div>
              <div style={{ minWidth: 260 }}>
                <input className="form-control" placeholder="Search issues by summary or description..."
                  value={search} onChange={e => setSearch(e.target.value)} />
              </div>
            </div>

            <AlertMessage message={error} onClose={() => setError("")} />

            {loading ? <div className="text-center py-5">Loading dashboard...</div> : (
              <>
                <div className="row g-3 mb-4">
                  <div className="col-md-4">
                    <div className="card stat-card shadow-sm"><div className="card-body">
                      <div className="text-muted">My Projects</div><div className="display-6 fw-bold">{projects.length}</div>
                    </div></div>
                  </div>
                  <div className="col-md-4">
                    <div className="card stat-card shadow-sm"><div className="card-body">
                      <div className="text-muted">Issues in My Projects</div><div className="display-6 fw-bold">{ownerIssues.length}</div>
                    </div></div>
                  </div>
                  <div className="col-md-4">
                    <div className="card stat-card shadow-sm"><div className="card-body">
                      <div className="text-muted">Available Assignees</div><div className="display-6 fw-bold">{assignees.length}</div>
                    </div></div>
                  </div>
                </div>

                <div className="card dashboard-card mb-4">
                  <div className="card-header bg-white d-flex justify-content-between align-items-center">
                    <span>My Projects</span>
                    <Link to="/projects/create" className="btn btn-primary btn-sm">+ Create Project</Link>
                  </div>
                  <div className="card-body">
                    {projects.length === 0 ? (
                      <div className="text-center py-4">
                        <p className="text-muted">No projects Available</p>
                        <Link to="/projects/create" className="btn btn-outline-primary">Create Project</Link>
                      </div>
                    ) : (
                      <div className="row g-3">
                        {projects.map(p => (
                          <div className="col-md-6" key={p.projectId}>
                            <div className="border rounded p-3 h-100">
                              <h5>{p.projectName}</h5>
                              <div className="small text-muted">Project ID: {p.projectId}</div>
                              <div className="small mt-2">Start: {p.startDate || "—"}</div>
                              <div className="small">End: {p.endDate || "—"}</div>
                              <Link className="btn btn-sm btn-outline-primary mt-3" to={`/projects/${p.projectId}/issues`}>
                                View Issues
                              </Link>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div className="card dashboard-card">
                  <div className="card-header bg-white">Issue Results</div>
                  <div className="card-body">
                    {ownerIssues.length === 0 ? (
                      <p className="text-muted mb-0">No matching issues found.</p>
                    ) : (
                      <div className="row g-3">
                        {ownerIssues.map(issue => (
                          <div className="col-md-6" key={issue.issueId}>
                            <IssueCard issue={issue} />
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
