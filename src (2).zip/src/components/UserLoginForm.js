import { useEffect, useState } from "react";
import { login } from "../services/userService";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { useContext } from "react";

function UserLoginForm() {
    
    const [form, setForm] = useState({});
    const [user, setUser] = useState({});
    const [error, setError] = useState(false);
    const [success, setSuccess] = useState(false);
    const [fieldErrors, setFieldErrors] = useState({});

    const navigate=useNavigate();
    const { ctxLogin, user:loggedInUser } = useContext(AuthContext); //consuming the context.

    const isLoggedOut= loggedInUser === null;

    useEffect(
        () => {
            setForm({});
            setFieldErrors({});
            setError(false);
            setSuccess(false);
            setUser(null);
        },[isLoggedOut]
    );
    const handleSubmit = async (e) => {
        e.preventDefault();
       const hasErrors = Object.values(form).some(value => !value);
       if(!hasErrors){
        const result=await login(form.userEmail, form.userPassword);
        if(result.success && result.user && result.user.userId){
            ctxLogin(result.user); 

            setUser(result.user);
            setSuccess(true);
            setError(false);

                navigate('/'); // Redirect to the home page after successful login

        }
        else{
            console.log("user login failed");
            setUser(null);
            setError(true);
            setSuccess(false);
        }
    }}

    const handleChange = (e) => {
        const { name, value } = e.target;
        setForm({ ...form, [name]: value });
        setFieldErrors({ ...fieldErrors, [name]: "" });
    }
    const getFieldError = (name, value) => {
        switch (name) {
            case "userEmail":
                if (!value) {   
                    return "Email is required";
                } else if (!/\S+@\S+\.\S+/.test(value)) {
                    return "Email is invalid";
                }       
                break;
            case "userPassword":
                if (!value) {
                    return "Password is required";
                } else if (value.length < 6) {
                    return "Password must be at least 6 characters";
                }   
            break;
            default:
                return "";
        }   
        return "";


    }
    const handleBlur = (e) => {
        const { name, value } = e.target;
        const error=getFieldError(name, value);
        setFieldErrors({ ...fieldErrors, [name]: error });

    }
    return (
       <div className="container-fluid min-vh-100 d-flex justify-content-center align-items-center bg-light">
            <div className="col-md-6 col-lg-5">
                <div className="card shadow-lg border-0">
                    <div className="card-header bg-primary text-white text-center py-3 rounded-top">
                        <h2 className="mb-0">Login</h2>
                    </div>
                    <div className="card-body p-4">
                        <form onSubmit={handleSubmit}>
                            {success && user && (
                                <div className="alert alert-success" role="alert">
                                    Logged in successfully: {user.userId}
                                </div>
                            )}
                            {error && (
                                <div className="alert alert-danger" role="alert">
                                    Invalid Credentials.
                                </div>
                            )}
                            <div className="mb-3">
                                <label className="form-label">Email:</label>
                                <input type="email" className={`form-control ${fieldErrors.userEmail ? 'is-invalid' : ''}`}
                                    value={form.userEmail || ''} name="userEmail" onChange={handleChange} onBlur={handleBlur} />
                                {fieldErrors.userEmail && <div className="invalid-feedback">{fieldErrors.userEmail}</div>}
                            </div>
                            <div className="mb-3">
                                <label className="form-label">Password:</label>
                                <input type="password" className={`form-control ${fieldErrors.userPassword ? 'is-invalid' : ''}`}
                                    value={form.userPassword || ''} name="userPassword" onChange={handleChange} onBlur={handleBlur} />
                                {fieldErrors.userPassword && <div className="invalid-feedback">{fieldErrors.userPassword}</div>}
                            </div>
                            <button type="submit" className="btn btn-primary w-100 mt-3">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default UserLoginForm;