export default class User {
  constructor(userId, role, email, name, password, profile) {
    this.userId = userId;
    this.role = role;
    this.email = email;
    this.name = name;
    this.password = password;
    this.profile = profile;
  }
}
