export default class Project {
  constructor(projectId, projectName, projectOwner, startDate, endDate) {
    this.projectId = projectId;
    this.projectName = projectName;
    this.projectOwner = projectOwner;
    this.startDate = startDate;
    this.endDate = endDate;
  }
}
