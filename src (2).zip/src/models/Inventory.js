

function Inventory(inventoryId,productId,stock){
    this.inventoryId = inventoryId;
    this.productId = productId;
    this.stock = stock;
}
export default Inventory;