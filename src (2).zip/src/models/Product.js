function Product(productId, productName, productDescription, price, category, imageURL, brand) {
    return {
        productId,
        productName,
        productDescription,
        price,
        category,
        imageURL,
        brand
    }
}
export default Product;