export class Order{
    constructor(orderId,customerId,productId,quantity,orderAmount,orderDate,status){
        this.orderId = orderId;
        this.customerId = customerId;
        this.productId = productId;
        this.quantity = quantity;
        this.orderAmount = orderAmount;
        this.orderDate = orderDate;
        this.status = status;
    }
}