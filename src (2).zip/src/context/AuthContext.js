import { createContext, useEffect, useState } from "react";

export const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem("its_user");
    return stored ? JSON.parse(stored) : null;
  });

  useEffect(() => {
    if (user) localStorage.setItem("its_user", JSON.stringify(user));
    else localStorage.removeItem("its_user");
  }, [user]);

  const login = (userData) => setUser(userData);
  const logout = () => setUser(null);

  const isLoggedIn = !!user;
  const isOwner = user?.role === 1;
  const isAssignee = user?.role === 2;

  return (
    <AuthContext.Provider value={{
      user,
      isLoggedIn,
      isOwner,
      isAssignee,
      login,
      logout
    }}>
      {children}
    </AuthContext.Provider>
  );
}
