import "./App.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useContext } from "react";
import { AuthContext } from "./context/AuthContext";
import NavBar from "./components/NavBar";
import ProtectedRoute from "./components/ProtectedRoute";
import Login from "./components/Login";
import Signup from "./components/Signup";
import OwnerDashboard from "./components/OwnerDashboard";
import AssigneeDashboard from "./components/AssigneeDashboard";
import ProjectForm from "./components/ProjectForm";
import IssueForm from "./components/IssueForm";
import IssueDetails from "./components/IssueDetails";
import ProjectIssues from "./components/ProjectIssues";

function HomeRedirect() {
  const { isLoggedIn, isOwner, isAssignee } = useContext(AuthContext);
  if (!isLoggedIn) return <Navigate to="/login" replace />;
  if (isOwner) return <Navigate to="/owner" replace />;
  if (isAssignee) return <Navigate to="/assignee" replace />;
  return <Navigate to="/login" replace />;
}

export default function App() {
  return (
    <BrowserRouter>
      <NavBar />
      <Routes>
        <Route path="/" element={<HomeRedirect />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />

        <Route path="/owner" element={
          <ProtectedRoute role={1}><OwnerDashboard /></ProtectedRoute>
        } />
        <Route path="/assignee" element={
          <ProtectedRoute role={2}><AssigneeDashboard /></ProtectedRoute>
        } />

        <Route path="/projects/create" element={
          <ProtectedRoute role={1}><ProjectForm /></ProtectedRoute>
        } />
        <Route path="/projects/:projectId/issues" element={
          <ProtectedRoute role={1}><ProjectIssues /></ProtectedRoute>
        } />

        <Route path="/issues/create" element={
          <ProtectedRoute role={1}><IssueForm /></ProtectedRoute>
        } />
        <Route path="/issues/:issueId" element={
          <ProtectedRoute role={1}><IssueDetails /></ProtectedRoute>
        } />
        <Route path="/assignee/issues/:issueId" element={
          <ProtectedRoute role={2}><IssueDetails assigneeMode /></ProtectedRoute>
        } />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
