import axios from 'axios';
 
export const PRODUCT_API_URL = "http://localhost:8081/products";
 
export const getAllProducts = async () => {
    try {
        const response = await axios.get(PRODUCT_API_URL);
        return response.data;
    } catch (error) {
        console.error('Error fetching products:', error);
        throw error;
    }
};
 
export const addProduct = async (product) => {
    try {
        const response = await axios.post(`${PRODUCT_API_URL}/add`, product);
        return response.data;
    } catch (error) {
        console.error('Error adding product:', error);
        throw error;
    }
};
 
export const deleteProduct = async (productId) => {
    try {
        const response = await axios.delete(`${PRODUCT_API_URL}/delete/${productId}`);
        return response.data;
    } catch (error) {
        console.error('Error deleting product:', error);
        throw error;
    }
};
 
export const updateProduct = async (updatedProduct) => {
    console.log(JSON.stringify(updatedProduct));
 
    try {
        const response = await axios.put(`${PRODUCT_API_URL}/update`, updatedProduct);
        return response.data;
    } catch (error) {
        console.error('Error updating product:', error);
        throw error;
    }
};
 
export const getProductById = async (productId) => {
    try {
        const response = await axios.get(`${PRODUCT_API_URL}/${productId}`);
        return response.data;
    } catch (error) {
        console.error('Error fetching product:', error);
        throw error;
    }
};
 
export const getStockByProductId = async (productId) => {
    try {
        const response = await axios.get(`${PRODUCT_API_URL}/stock/${productId}`);
        return response.data;
    } catch (error) {
        console.error('Error fetching product stock:', error);
        throw error;
    }
};