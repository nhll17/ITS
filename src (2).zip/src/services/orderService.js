import axios from 'axios';
 
export const ORDER_API_URL = "http://localhost:8084/orders";
 
export async function createOrder(order) {
    const response = await axios.post(`${ORDER_API_URL}/place`, order);
    return response.data;
}
 
export async function getOrders() {
    const response = await axios.get(ORDER_API_URL);
    return response.data;
}
 
export async function getOrderByCustomerId(customerId) {
    const response = await axios.get(`${ORDER_API_URL}/customers/${customerId}`);
    return response.data;
}
 
export async function cancelOrder(orderId) {
    const response = await axios.post(`${ORDER_API_URL}/cancel/${orderId}`);
    return response.data;
}
 
export async function deliverOrder(orderId) {
    const response = await axios.put(`${ORDER_API_URL}/status/delivered/${orderId}`);
    return response.data;
}