import axios from 'axios';
import { PRODUCT_API_URL } from "./productService";
 
export const INVENTORY_API_URL =  "http://localhost:8082/inventory";
 
export const getAllInventoryItems = async () => {
    const response = await axios.get(`${INVENTORY_API_URL}`);
    return response.data;
};
 
export const getInventoryItemById = async (id) => {
    const response = await axios.get(`${INVENTORY_API_URL}/items/${id}`);
    return response.data;
};
 
export const createInventoryItem = async (inventory) => {
    try {
        const payload = {
            productId: Number(inventory.productId),
            stock: Number(inventory.stock)
        };
 
        console.log("Inventory payload:", payload);
 
        const response = await axios.post(
            `${INVENTORY_API_URL}/add`,
            payload
        );
        return response.data;
    } catch (error) {
        console.error("Error creating inventory item:", error);
        throw error;
    }
};
 
 
export const updateInventoryItemStock = async (productId, stock) => {
    const response = await axios.put(`${INVENTORY_API_URL}/update`, { productId, stock });
    return response.data;
};
 
export const deleteInventoryItem = async (id) => {
    const response = await axios.delete(`${INVENTORY_API_URL}/delete/${id}`);
    return response.data;
};
 
export const getProductsNotInStock = async () => {
    const [productResponse, inventoryResponse] = await Promise.all([
        axios.get(PRODUCT_API_URL),
        axios.get(`${INVENTORY_API_URL}`),
    ]);
 
    const products = productResponse.data;
    const inventory = inventoryResponse.data;
 
    console.log("Products:", products);
    console.log("Inventory:", inventory);
 
    return products.filter(product =>
        !inventory.some(item => item.productId === product.productId)
    );
};
 
export const getStockByProductId = async (productId) => {
    try {
        const response = await axios.get(`${INVENTORY_API_URL}/${productId}`);
        return response.data ?? 0;
    } catch (e) {
        // Invalid JSON, treat as zero stock
        return 0;
    }
};
 
