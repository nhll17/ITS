import { useEffect, useState, useContext } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getIssueById, updateIssue } from "../services/issueService";
import { getAllProjects } from "../services/projectService";
import { getAllUsers } from "../services/userService";
import { AuthContext } from "../context/AuthContext";
import AlertMessage from "./AlertMessage";

const PRIORITIES = ["LOW", "MEDIUM", "HIGH", "CRITICAL"];
const STATUSES = ["OPEN", "IN_PROGRESS", "RESOLVED", "CLOSED"];
const TYPES = ["BUG", "FEATURE", "TASK"];\nconst STATUS_LABELS = { OPEN: "To-Do", IN_PROGRESS: "Development", RESOLVED: "Testing", CLOSED: "Completed" };

export default function IssueDetails({ assigneeMode = false }) {
  const { issueId } = useParams();
  const navigate = useNavigate();
  const { user } = useContext(AuthContext);
  const [issue, setIssue] = useState(null);
  const [form, setForm] = useState(null);
  const [projects, setProjects] = useState([]);
  const [users, setUsers] = useState([]);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [changed, setChanged] = useState(false);

  useEffect(() => {
    Promise.all([getIssueById(issueId), getAllProjects(), getAllUsers()])
      .then(([i, p, u]) => {
        setIssue(i);
        setForm({
          projectId: i.projectId ?? "",
          assignee: i.assignee ?? "",
          description: i.description ?? "",
          summary: i.summary ?? "",
          priority: i.priority ?? "",
          status: i.status ?? "",
          createdBy: i.createdBy ?? "",
          sprint: i.sprint ?? "",
          storyPoint: i.storyPoint ?? "",
          tags: i.tags ?? "",
          type: i.type ?? ""
        });
        setProjects(p);
        setUsers(u.filter(x => Number(x.role) === 2));
      })
      .catch(err => setError(err.userMessage || "Unable to load issue."));
  }, [issueId]);

  const change = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setChanged(true);
  };

  const save = async e => {
    e.preventDefault();
    setError("");
    setSaving(true);
    try {
      const payload = {
        projectId: Number(form.projectId),
        assignee: form.assignee ? Number(form.assignee) : null,
        description: form.description || null,
        summary: form.summary,
        priority: form.priority,
        status: form.status,
        createdBy: Number(form.createdBy),
        sprint: form.sprint || null,
        storyPoint: form.storyPoint ? Number(form.storyPoint) : null,
        tags: form.tags || null,
        type: form.type
      };
      const updated = await updateIssue(issueId, payload);
      setIssue(updated);
      setForm({
        projectId: updated.projectId ?? "",
        assignee: updated.assignee ?? "",
        description: updated.description ?? "",
        summary: updated.summary ?? "",
        priority: updated.priority ?? "",
        status: updated.status ?? "",
        createdBy: updated.createdBy ?? "",
        sprint: updated.sprint ?? "",
        storyPoint: updated.storyPoint ?? "",
        tags: updated.tags ?? "",
        type: updated.type ?? ""
      });
      setChanged(false);
    } catch (err) {
      setError(err.userMessage || "Unable to save changes.");
    } finally {
      setSaving(false);
    }
  };

  if (!form) return <div className="page-container"><div className="container text-center">Loading...</div></div>;

  const project = projects.find(p => Number(p.projectId) === Number(form.projectId));
  const assignee = users.find(u => Number(u.userId) === Number(form.assignee));

  return (
    <div className="page-container">
      <div className="container">
        <div className="card dashboard-card">
          <div className="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h4 className="mb-0">{assigneeMode ? "Assignee Issue Details" : "Edit Issue Details"}</h4>
            <span className="badge bg-light text-primary">Issue #{issue?.issueId}</span>
          </div>
          <div className="card-body p-4">
            <AlertMessage message={error} />
            <form onSubmit={save}>
              <div className="row">
                <div className="col-md-8 mb-3">
                  <label className="form-label">Summary</label>
                  <input name="summary" value={form.summary} onChange={change} className="form-control" disabled={assigneeMode} />
                </div>
                <div className="col-md-4 mb-3">
                  <label className="form-label">Type</label>
                  <select name="type" value={form.type} onChange={change} className="form-select" disabled={assigneeMode}>
                    {TYPES.map(x => <option key={x}>{x}</option>)}
                  </select>
                </div>
              </div>

              <div className="row">
                <div className="col-md-6 mb-3">
                  <label className="form-label">Project</label>
                  <select name="projectId" value={form.projectId} onChange={change} className="form-select" disabled={assigneeMode}>
                    {projects.map(p => <option key={p.projectId} value={p.projectId}>{p.projectName}</option>)}
                  </select>
                </div>
                <div className="col-md-6 mb-3">
                  <label className="form-label">Assignee</label>
                  <select name="assignee" value={form.assignee} onChange={change} className="form-select" disabled={assigneeMode}>
                    <option value="">Unassigned</option>
                    {users.map(u => <option key={u.userId} value={u.userId}>{u.name} (#{u.userId})</option>)}
                  </select>
                  {assignee && <small className="text-muted">Assigned to {assignee.name}</small>}
                </div>
              </div>

              <div className="mb-3">
                <label className="form-label">Description</label>
                <textarea name="description" value={form.description} onChange={change} rows="4" className="form-control" disabled={assigneeMode} />
              </div>

              <div className="row">
                <div className="col-md-3 mb-3">
                  <label className="form-label">Priority</label>
                  <select name="priority" value={form.priority} onChange={change} className="form-select" disabled={assigneeMode}>
                    {PRIORITIES.map(x => <option key={x}>{x}</option>)}
                  </select>
                </div>
                <div className="col-md-3 mb-3">
                  <label className="form-label">Status</label>
                  <select name="status" value={form.status} onChange={change} className="form-select">
                    {STATUSES.map(x => <option key={x} value={x}>{STATUS_LABELS[x]}</option>)}
                  </select>
                </div>
                <div className="col-md-3 mb-3">
                  <label className="form-label">Story Point</label>
                  <input type="number" name="storyPoint" value={form.storyPoint} onChange={change} className="form-control" disabled={assigneeMode} />
                </div>
                <div className="col-md-3 mb-3">
                  <label className="form-label">Sprint</label>
                  <input name="sprint" value={form.sprint} onChange={change} className="form-control" disabled={assigneeMode} />
                </div>
              </div>

              <div className="mb-3">
                <label className="form-label">Tags</label>
                <input name="tags" value={form.tags} onChange={change} className="form-control" disabled={assigneeMode} />
              </div>

              <div className="small text-muted mb-3">
                Project: {project?.projectName || form.projectId} · Created: {issue?.createdOn || "—"} · Last Updated: {issue?.lastUpdated || "—"}
              </div>

              <div className="d-flex gap-2">
                <button type="submit" className="btn btn-primary" disabled={!changed || saving}>
                  {saving ? "Saving..." : assigneeMode ? "Save Updates" : "Save Changes"}
                </button>
                <button type="button" className="btn btn-outline-secondary"
                  onClick={() => navigate(assigneeMode ? "/assignee" : "/owner")}>
                  Back
                </button>
              </div>
              {assigneeMode && !changed && <small className="text-muted d-block mt-2">Change the status to enable Save Updates.</small>}
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
