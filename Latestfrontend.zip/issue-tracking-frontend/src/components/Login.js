import { useState, useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { loginUser } from "../services/userService";
import { AuthContext } from "../context/AuthContext";
import AlertMessage from "./AlertMessage";

export default function Login() {
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "", role: "" });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState("");

  const validate = () => {
    const e = {};
    if (!form.email.trim()) e.email = "Email is required.";
    else if (!/^\\S+@\\S+\\.\\S+$/.test(form.email)) e.email = "Enter a valid email.";
    if (!form.password) e.password = "Password is required.";
    if (!form.role) e.role = "Role is required.";
    return e;
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: "" });
  };

  const formIsValid = Object.keys(validate()).length === 0;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setServerError("");
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length) return;

    try {
      const user = await loginUser(form.email, form.password);
      if (Number(user.role) !== Number(form.role)) {
        setServerError("Selected role does not match this account.");
        return;
      }
      login(user);
      navigate(Number(user.role) === 1 ? "/owner" : "/assignee");
    } catch (err) {
      setServerError(err.userMessage || "Invalid credentials.");
    }
  };

  return (
    <div className="auth-page">
      <div className="card auth-card shadow">
        <div className="card-header bg-primary text-white text-center py-3">
          <h2 className="mb-0">Login</h2>
        </div>
        <div className="card-body p-4">
          <AlertMessage message={serverError} />
          <form onSubmit={handleSubmit} noValidate>
            <div className="mb-3">
              <label className="form-label">Email</label>
              <input
                type="email" name="email" value={form.email}
                onChange={handleChange} onBlur={() => setErrors({...errors, email: validate().email})}
                className={`form-control ${errors.email ? "is-invalid" : ""}`}
              />
              {errors.email && <div className="invalid-feedback">{errors.email}</div>}
            </div>

            <div className="mb-3">
              <label className="form-label">Password</label>
              <input
                type="password" name="password" value={form.password}
                onChange={handleChange}
                className={`form-control ${errors.password ? "is-invalid" : ""}`}
              />
              {errors.password && <div className="invalid-feedback">{errors.password}</div>}
            </div>

            <div className="mb-4">
              <label className="form-label">Role</label>
              <select name="role" value={form.role} onChange={handleChange}
                className={`form-select ${errors.role ? "is-invalid" : ""}`}>
                <option value="">Select role</option>
                <option value="1">Owner</option>
                <option value="2">Assignee</option>
              </select>
              {errors.role && <div className="invalid-feedback">{errors.role}</div>}
            </div>

            <button type="submit" className="btn btn-primary w-100" disabled={!formIsValid}>Login</button>
          </form>

          <div className="text-center mt-3">
            New user? <Link to="/signup">Sign up</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
