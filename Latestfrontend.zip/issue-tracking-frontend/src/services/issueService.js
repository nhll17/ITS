import api from "./api";

export async function getAllIssues() {
  const response = await api.get("/issues");
  return response.data;
}

export async function getIssueById(issueId) {
  const response = await api.get(`/issues/${issueId}`);
  return response.data;
}

export async function createIssue(issue) {
  const response = await api.post("/issues", issue);
  return response.data;
}

export async function updateIssue(issueId, issue) {
  const response = await api.put(`/issues/${issueId}`, issue);
  return response.data;
}

export async function getIssuesByProject(projectId) {
  const response = await api.get(`/issues/project/${projectId}`);
  return response.data;
}

export async function getIssuesByAssignee(assigneeId) {
  const response = await api.get(`/issues/assignee/${assigneeId}`);
  return response.data;
}
