import api from "./api";

export async function getAllProjects() {
  const response = await api.get("/projects");
  return response.data;
}

export async function getProjectById(projectId) {
  const response = await api.get(`/projects/${projectId}`);
  return response.data;
}

export async function createProject(project) {
  const response = await api.post("/projects", project);
  return response.data;
}

export async function updateProject(projectId, project) {
  const response = await api.put(`/projects/${projectId}`, project);
  return response.data;
}

export async function deleteProject(projectId) {
  const response = await api.delete(`/projects/${projectId}`);
  return response.data;
}

export async function getProjectsByOwner(ownerId) {
  const response = await api.get(`/projects/owner/${ownerId}`);
  return response.data;
}

export async function getProjectIssues(projectId) {
  const response = await api.get(`/projects/${projectId}/issues`);
  return response.data;
}
