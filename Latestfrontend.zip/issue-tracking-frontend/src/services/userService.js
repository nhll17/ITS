import api from "./api";

export async function registerUser(user) {
  const response = await api.post("/users", user);
  return response.data;
}

export async function loginUser(email, password) {
  const response = await api.post("/users/login", null, {
    params: { email, password }
  });
  return response.data;
}

export async function getAllUsers() {
  const response = await api.get("/users");
  return response.data;
}

export async function getUserById(userId) {
  const response = await api.get(`/users/${userId}`);
  return response.data;
}

export async function getUserIssues(userId) {
  const response = await api.get(`/users/${userId}/issues`);
  return response.data;
}
