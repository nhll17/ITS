# Issue Tracking System - React Frontend

This frontend was created as a Create React App style project (the `npx create-react-app` structure), using:

- React + JavaScript (`.js`, no TSX)
- Bootstrap 5
- Axios
- React Router
- React Context for login state
- Axios services separated from components

## Backend used

The frontend is configured to call the API Gateway at:

`http://localhost:8085`

The CRA `proxy` setting means the browser calls `/api/...` and the development server forwards it to port 8085.

Backend routes detected from the supplied project:

- `/api/users`
- `/api/projects`
- `/api/issues`

## Important role mapping

The backend stores `role` as an Integer. This frontend follows the case-study role labels:

- `1` = Owner
- `2` = Assignee

## Start the frontend

```bash
npx create-react-app issue-tracking-frontend
```

For this supplied project, the source is already prepared, so after extracting the ZIP:

```bash
cd issue-tracking-frontend
npm install
npm start
```

The application opens at:

`http://localhost:3000`

## Start order

1. Start Eureka Server if required by your backend.
2. Start User-Service.
3. Start Project-Service.
4. Start Issue-Service.
5. Start API-Gateway on port 8085.
6. Start this React application on port 3000.

## Backend/case-study compatibility note

The supplied backend's `Issue` enum is:

- `BUG`
- `FEATURE`
- `TASK`

and its status enum is:

- `OPEN`
- `IN_PROGRESS`
- `RESOLVED`
- `CLOSED`

The frontend therefore sends these exact backend enum values. This is intentional: sending labels that are only present in the case-study screenshots but not in the Java enum would cause backend deserialization failures.

The case study specifies Login/Signup validation, Owner and Assignee roles, an Owner dashboard with issue search, project creation, issue creation, issue details, and an Assignee dashboard. The implementation follows those flows and uses the actual backend contract where the case-study labels differ from the supplied Java enums.

The case-study requires profile image URL validation on signup, disabled submit buttons for invalid forms, issue-summary restrictions, prime-number story points, numeric sprints, and max 100-character tags. These validations are implemented in the React forms.

Because the case-study status labels are `To-Do`, `Development`, `Testing`, and `Completed` while the supplied backend accepts `OPEN`, `IN_PROGRESS`, `RESOLVED`, and `CLOSED`, the UI displays the case-study labels and sends the backend enum values.

The case-study type mapping includes `BUG`, `TASK`, and `STORY`, but the supplied backend enum is `BUG`, `FEATURE`, and `TASK`. The frontend uses the supplied backend enum values so API requests deserialize successfully.
