class User {
    constructor(userId, userName, userEmail, userPassword, userRole, userProfile) {
        this.userId = userId;
        this.userName = userName;
        this.userEmail = userEmail;
        this.userPassword = userPassword;
        this.userRole = userRole;
        this.userProfile = userProfile;
    }
}

export default User;
