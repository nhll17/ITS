import { BrowserRouter as Router, Routes, Route, Outlet, Link } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";

import UserLoginForm from "./components/UserLoginForm";
import UserSignupForm from "./components/UserSignupForm";
import ProjectOwnerDashboard from "./components/ProjectOwnerDashboard";
import AssigneeDashboard from "./components/AssigneeDashboard";
import CreateProject from "./components/CreateProject";
import CreateIssue from "./components/CreateIssue";
import IssueDetail from "./components/IssueDetail";
import EditIssue from "./components/EditIssue";
import AssigneeIssueDetails from "./components/AssigneeIssueDetails";
// ---- shared navbar (your existing one) ----
function Navbar() {
  return (
    <nav
      className="navbar navbar-expand-lg navbar-dark"
      style={{ backgroundColor: "#f0b429" }}
    >
      <div className="container-fluid">
        <Link className="navbar-brand" to="/">Issue Tracking System</Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
      </div>
    </nav>
  );
}

// ---- layout for pages that SHOULD show the common navbar ----
function WithNavbar() {
  return (
    <>
      <Navbar />
      <div className="container mt-4">
        <Outlet />
      </div>
    </>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Group 1: pages WITH the common navbar */}
          <Route element={<WithNavbar />}>
            <Route path="/" element={<UserLoginForm />} />
            <Route path="/signup" element={<UserSignupForm />} />
          </Route>

          {/* Group 2: FULL-SCREEN pages, NO common navbar */}
          <Route path="/project-owner-dashboard" element={<ProjectOwnerDashboard />} />
          <Route path="/assignee-dashboard" element={<AssigneeDashboard />} />
          <Route path="/create-project" element={<CreateProject />} />
          <Route path="/create-issue" element={<CreateIssue />} />
          <Route path="/issue/:id" element={<IssueDetail />} />
          <Route path="/issue/:id/edit" element={<EditIssue />} />
          <Route path="/assignee-issue/:id" element={<AssigneeIssueDetails />} />
          

          {/* add more full-screen pages here later, e.g.:
          <Route path="/create-project" element={<CreateProject />} />
          */}
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
