import logo from './logo.svg';
import './App.css';
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from 'react-router-dom';
import { AuthContext } from './context/AuthContext';
import { useContext } from 'react';
import UserLoginForm from './components/UserLoginForm';
import UserSignupForm from './components/UserSignupForm';
import ViewAllProducts from './components/ViewAllProducts';
import UpdateProductForm from './components/UpdateProductForm';
import AddProductForm from './components/AddProductForm';
import GetAllOrders from './components/GetAllOrders';
import NewInventory from './components/NewInventory';
import ViewAllInventory from './components/ViewAllInventory';
import PlaceOrderForm from './components/PlaceOrderForm';
function NavBar() {

  const { isLoggedIn, user, ctxLogout } = useContext(AuthContext);
  const navigate=useNavigate();

  const handleLogout = () => {
    ctxLogout();
    navigate('/login');
  };

  return (

    <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
      <div className="container-fluid">
        <Link className="navbar-brand" to="/">E-Commerce</Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="nav-item">
              <Link className="nav-link" to="/">Home</Link>
            </li>
            {!isLoggedIn && (
              <>
                <li className="nav-item">
                  <Link className="nav-link" to="/login">Login</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/signup">Signup</Link>
                </li>
              </>
            )}
            {isLoggedIn && user?.userRole === 'admin' && (
              <>
                <li className="nav-item">
                  <Link className="nav-link" to="/orders">All Orders</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/view-inventory">View All Inventory</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/add-product">Add New Product</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/add-inventory">Add New Inventory</Link>
                </li>
              </>
            )}
            {isLoggedIn && user?.userRole === 'customer' && (
              <>
                <li className="nav-item">
                  <Link className="nav-link" to="/orders">My Orders</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/place-order/1">Place Order</Link>
                </li>
              </>
            )}
            {isLoggedIn && (
              <li className="nav-item">
                <button className="nav-link btn btn-link text-white" onClick={handleLogout}>Logout</button>
              </li>
            )}
          </ul>
          {isLoggedIn && user && (
            <span className="navbar-text me-3">Welcome, {user.userName}({user.userRole})</span>
          )}
        </div>
      </div>
    </nav>
  )
}

function App() {
  return (
    <div className="App">
      <Router>
        <NavBar />
        <Routes>
          <Route path='/' element={<ViewAllProducts />} />
 
          <Route path='/signup' element={<UserSignupForm />} />
          <Route path='/login' element={<UserLoginForm />} />
 
          <Route path='/add-product' element={<AddProductForm />} />
          <Route path='/add-inventory' element={<NewInventory />} />
 
           <Route path='/update-product/:prdId' element={<UpdateProductForm/>}/>
 
          <Route path='/place-order/:productId' element={<PlaceOrderForm />} />
 
          <Route path='/orders' element={<GetAllOrders />} />          
          <Route path='/view-inventory' element={<ViewAllInventory />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
