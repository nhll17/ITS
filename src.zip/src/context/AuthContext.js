import { createContext } from "react";
import { useState, useEffect } from "react";
export const AuthContext = createContext();

export function AuthProvider({ children }) {

    const [isLoggedIn, setIsLoggedIn] = useState(() => {
        const stored= localStorage.getItem("isLoggedIn");
        return stored === "true";
    });
    const [user, setUser] = useState(() => {
        const storedUser = localStorage.getItem("user");
        return storedUser ? JSON.parse(storedUser) : null;
    });

    useEffect(
        () => {
            localStorage.setItem("isLoggedIn", isLoggedIn);
            localStorage.setItem("user", JSON.stringify(user));
    }, [isLoggedIn, user]
    );

    const ctxLogin = (userData) => {
        setIsLoggedIn(true);
        setUser(userData);
    }

    const ctxLogout = () => {
        setIsLoggedIn(false);
        setUser(null);
        localStorage.removeItem("isLoggedIn");  //important to remove the isLoggedIn key from localStorage when logging out
        localStorage.removeItem("user");
    }


    return (
        <AuthContext.Provider value={{ isLoggedIn, user, ctxLogin, ctxLogout }}>
            {children}
        </AuthContext.Provider>
    );
}