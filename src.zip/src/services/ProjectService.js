
import axios from "axios";

export const PROJECT_API_URL = "http://localhost:8082/api/projects";

export const addProject = async (project) => {
    try {
        const response = await axios.post(PROJECT_API_URL, project);
        return response.data;
    } catch (error) {
        console.error("Error adding project:", error);
        throw error;
    }
};

export const getProjectsByOwner = async (ownerId) => {
    try {
        const response = await axios.get(`${PROJECT_API_URL}/owner/${ownerId}`);
        return response.data;
    } catch (error) {
        console.error("Error fetching projects by owner:", error);
        throw error;
    }
};

export const getIssuesByProject = async (projectId) => {
    try {
        const response = await axios.get(`${PROJECT_API_URL}/${projectId}/issues`);
        return response.data;
    } catch (error) {
        console.error("Error fetching issues by project:", error);
        throw error;
    }
};
