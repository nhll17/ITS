import axios from 'axios';

export const ISSUE_API_URL = "http://localhost:8081/api/issues";

export const PROJECT_API_URL = "http://localhost:8082/api/projects";
export const USER_API_URL = "http://localhost:8083/api/users";

export const addIssue = async (issue) => {
    try {
        const response = await axios.post(ISSUE_API_URL, issue);
        return response.data;
    } catch (error) {
        console.error("Error adding issue:", error);
        throw error;
    }
};

export const getAllUsers = async () => {
    try {
        const response = await axios.get(USER_API_URL);
        return response.data;
    } catch (error) {
        console.error("Error fetching users:", error);
        throw error;
    }
};
export const getProjectsByOwner = async (ownerId) => {
    try {
        const response = await axios.get(`${PROJECT_API_URL}/owner/${ownerId}`);
        return response.data;
    } catch (error) {
        console.error('Error fetching projects by owner:', error);
        throw error;
    }
};

export const getIssuesByProject = async (projectId) => {
    try {
        const response = await axios.get(`${PROJECT_API_URL}/${projectId}/issues`);
        return response.data;
    } catch (error) {
        console.error('Error fetching issues by project:', error);
        throw error;
    }
};

export const addProject = async (project) => {
    try {
        const response = await axios.post(PROJECT_API_URL, project);
        return response.data;
    } catch (error) {
        console.error('Error adding project:', error);
        throw error;
    }
};
