import axios from "axios";

const USER_API_URL = "http://localhost:8083/api/users";

const mapRoleToNumber = (role) => (role === "Project Owner" ? 1 : 2);

export async function registeruser(form) {
    const payload = {
        name: form.userName,
        email: form.userEmail,
        password: form.userPassword,
        role: mapRoleToNumber(form.userRole),
        profile: form.userProfile,
    };
    try {
        const response = await axios.post(USER_API_URL, payload);
        return response.data;
    } catch (error) {
        console.log("Register error:", error.response?.data);
        throw error;
    }
}

export async function login(email, password) {
    try {
        const response = await axios.post(`${USER_API_URL}/login`, null, {
            params: { email, password },
        });
        return { success: true, user: response.data };
    } catch (error) {
        console.log("Login error:", error.response?.data);
        return { success: false, user: null };
    }
}

// // GET /api/users  -> all users
// export async function getAllUsers() {
//     const response = await axios.get(BASE_URL);
//     return response.data.map(mapUserFromBackend);
// }

// // GET /api/users/{userId}  -> single user
// export async function getUserById(userId) {
//     const response = await axios.get(BASE_URL + "/" + userId);
//     return mapUserFromBackend(response.data);
// }

// // GET /api/users/{userId}/issues  -> issues by user id
// export async function getIssuesByUserId(userId) {
//     const response = await axios.get(BASE_URL + "/" + userId + "/issues");
//     return response.data;
// }

// // GET /api/users/username/{username}/issues  -> issues by username
// export async function getIssuesByUsername(username) {
//     const response = await axios.get(BASE_URL + "/username/" + username + "/issues");
//     return response.data;
// }
