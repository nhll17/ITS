
import axios from "axios";

export const USER_API_URL = "http://localhost:8083/api/users";

const mapRoleToNumber = (role) => (role === "Project Owner" ? 1 : 2);

export const getAllUsers = async () => {
    try {
        const response = await axios.get(USER_API_URL);
        return response.data;
    } catch (error) {
        console.error("Error fetching users:", error);
        throw error;
    }
};

export async function registeruser(form) {
    const payload = {
        name: form.userName,
        email: form.userEmail,
        password: form.userPassword,
        role: mapRoleToNumber(form.userRole),
        profile: form.userProfile,
    };
    try {
        const response = await axios.post(USER_API_URL, payload);
        return response.data;
    } catch (error) {
        console.log("Register error:", error.response?.data);
        throw error;
    }
}

export async function login(email, password, role) {
    try {
        const response = await axios.post(`${USER_API_URL}/login`, null, {
            params: { email, password, role: mapRoleToNumber(role) },
        });
        return { success: true, user: response.data };
    } catch (error) {
        console.log("Login error:", error.response?.data);
        return { success: false, user: null };
    }
}
