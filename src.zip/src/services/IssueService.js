
import axios from "axios";

export const ISSUE_API_URL = "http://localhost:8081/api/issues";

export const getAllIssues = async () => {
    try {
        const response = await axios.get(ISSUE_API_URL);
        return response.data;
    } catch (error) {
        console.error("Error fetching all issues:", error);
        throw error;
    }
};

export const addIssue = async (issue) => {
    try {
        const response = await axios.post(ISSUE_API_URL, issue);
        return response.data;
    } catch (error) {
        console.error("Error adding issue:", error);
        throw error;
    }
};

export const getIssueById = async (id) => {
    try {
        const response = await axios.get(`${ISSUE_API_URL}/${id}`);
        return response.data;
    } catch (error) {
        console.error("Error fetching issue:", error);
        throw error;
    }
};

export const getIssuesByAssignee = async (assignee) => {
    try {
        const response = await axios.get(`${ISSUE_API_URL}/assignee/${assignee}`);
        return response.data;
    } catch (error) {
        console.error("Error fetching issues by assignee:", error);
        throw error;
    }
};

export const updateIssue = async (id, issue) => {
    try {
        const response = await axios.put(`${ISSUE_API_URL}/${id}`, issue);
        return response.data;
    } catch (error) {
        console.error("Error updating issue:", error);
        throw error;
    }
};

