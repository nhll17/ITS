import axios from "axios";
export const USER_API_URL = "http://localhost:8083/users";

export async function registeruser(user) {
    try{
       const response=await axios.post(`${USER_API_URL}/register`,{
        userName:user.userName,
        userEmail:user.userEmail,
        userPassword:user.userPassword,
        userRole:user.userRole
       });
       return response.data;
    }
    catch(error){
        console.log("Error while calling register user api",error);
        throw error;
    }
}

export const login=async (userEmail, userPassword) => {
try{
    const response=await axios.post(`${USER_API_URL}/validate`,{
        userEmail,
        userPassword
    });
    return { success:true, user: response.data };
}
catch(error){
    console.log("Error while calling login api",error);
    return{success:false, error: error.response ? error.response.data : "An error occurred"};
}}