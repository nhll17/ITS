import { useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

function AssigneeDashboard() {
    const { user, ctxLogout } = useContext(AuthContext);
    const navigate = useNavigate();

    const handleLogout = () => {
        ctxLogout();
        navigate("/");
    };

    return (
        <div>
            <h2>Assignee Dashboard</h2>
            <img src={user?.profile} alt={user?.name} height="100" width="100"  />
            <p>Welcome, {user?.name}!</p>
            <p>This is where assignees view the tasks assigned to them.</p>
            <button onClick={handleLogout}>Logout</button>
        </div>
    );
}

export default AssigneeDashboard;