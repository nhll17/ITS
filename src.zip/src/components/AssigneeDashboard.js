import { useCallback, useContext, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { getIssuesByAssignee } from "../services/IssueService.js";
import Sidebar from "./Sidebar"; // adjust path if Sidebar.js is in another folder

const COLUMNS = [
    { key: "OPEN", label: "TO-DO", color: "#e74c3c" },
    { key: "IN_PROGRESS", label: "DEVELOPMENT", color: "#3498db" },
    { key: "RESOLVED", label: "TESTING", color: "#9b59b6" },
    { key: "CLOSED", label: "COMPLETED", color: "#27ae60" },
];

const priorityColor = (p) =>
    p === "HIGH" ? "danger" : p === "MEDIUM" ? "warning" : "success";

const styles = {
    header: { background: "#f0b429" },
    cardAvatar: { width: 22, height: 22, borderRadius: "50%", objectFit: "cover" },
    col: { flex: 1, minWidth: 210, background: "#f7f7f7", borderRadius: 6 },
    colHead: { borderBottom: "3px solid", fontWeight: 700, fontSize: "0.8rem", padding: 8 },
    card: { background: "#fff", border: "1px solid #e6e6e6", borderRadius: 4, padding: 8, margin: 8, fontSize: "0.8rem" },
    countBadge: { background: "#f0b429", color: "#000", borderRadius: 10, padding: "0 8px", fontSize: "0.75rem", marginLeft: 6 },
    searchInput: { flex: 1, maxWidth: 420, borderRadius: 4, border: "1px solid #ccc", padding: "6px 10px" },
};

function AssigneeDashboard() {
    const { user } = useContext(AuthContext);
    const navigate = useNavigate();
    const [issues, setIssues] = useState([]);
    const [search, setSearch] = useState("");
    const [loading, setLoading] = useState(true);

    // Pull issues assigned to the logged-in user (backend: /api/issues/assignee/{id})
    const refresh = useCallback(() => {
        if (!user?.userId) return;
        getIssuesByAssignee(user.userId)
            .then((data) => setIssues(data || []))
            .catch(() => setIssues([]))
            .finally(() => setLoading(false));
    }, [user]);

    // Run on mount, and again whenever the tab regains focus (picks up DB changes)
    useEffect(() => {
        refresh();
        window.addEventListener("focus", refresh);
        return () => window.removeEventListener("focus", refresh);
    }, [refresh]);

    const filteredIssues = useMemo(() => {
        if (!search.trim()) return issues;
        let regex = null;
        try {
            regex = new RegExp(search.trim(), "i");
        } catch {
            regex = null;
        }
        return issues.filter((i) => {
            const text = `${i.summary || ""} ${i.description || ""}`;
            return regex ? regex.test(text) : text.toLowerCase().includes(search.toLowerCase());
        });
    }, [issues, search]);

    return (
        <div className="d-flex">
            <Sidebar role="assignee" issueCount={issues.length} />

            {/* Main */}
            <div className="flex-grow-1">
                {/* Header */}
                <div style={styles.header} className="d-flex align-items-center justify-content-between p-2">
                    <input
                        style={styles.searchInput}
                        placeholder="Search issue by summary or description"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                    <span className="fw-bold me-2">Issue Tracking System</span>
                </div>

                <div className="p-3">
                    {loading ? (
                        <div className="text-center mt-5">Loading...</div>
                    ) : issues.length === 0 ? (
                        <div className="text-center mt-5">No Issues Assigned !</div>
                    ) : (
                        /* Kanban */
                        <div className="d-flex gap-2">
                            {COLUMNS.map((col) => {
                                const colIssues = filteredIssues.filter((i) => i.status === col.key);
                                return (
                                    <div key={col.key} style={styles.col}>
                                        <div style={{ ...styles.colHead, borderBottomColor: col.color }}>
                                            {col.label}
                                            <span style={styles.countBadge}>{colIssues.length}</span>
                                        </div>
                                        {colIssues.map((i) => (
                                            <div key={i.issueId} style={{ ...styles.card, cursor: "pointer" }}
                                                onClick={() => navigate(`/assignee-issue/${i.issueId}`)}>
                                                <div className="d-flex justify-content-between text-muted">
                                                    <span>Id: {i.issueId}</span>
                                                    <span>{i.lastUpdated || i.createdOn}</span>
                                                </div>
                                                <div className="fw-bold my-1">{i.summary}</div>
                                                <div className="text-muted mb-2">{i.description}</div>
                                                <div className="d-flex align-items-center justify-content-between">
                                                    <span className="d-flex align-items-center">
                                                        <img
                                                            src={user?.profile}
                                                            alt={user?.name}
                                                            style={styles.cardAvatar}
                                                            className="me-1"
                                                        />
                                                        {user?.name || "Unassigned"}
                                                    </span>
                                                    {i.priority && (
                                                        <span className={`badge bg-${priorityColor(i.priority)}`}>
                                                            {i.priority.charAt(0) + i.priority.slice(1).toLowerCase()}
                                                        </span>
                                                    )}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                );
                            })}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

export default AssigneeDashboard;
