import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { registeruser } from "../services/UserService";

const EMAIL_RULE = /^(?=[^@]*[A-Za-z])[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$/;
const IMAGE_URL_RULE = /^https?:\/\/.+\.(png|jpe?g|gif|webp|svg)$/i;

function UserSignupForm() {
    const [form, setForm] = useState({
        userName: "",
        userEmail: "",
        userPassword: "",
        userProfile: "",
        userRole: "",
    });
    const [fieldErrors, setFieldErrors] = useState({});
    const [user, setUser] = useState(null);
    const [success, setSuccess] = useState(false);
    const [error, setError] = useState(false);
    const navigate = useNavigate();

    const getFieldError = (name, value) => {
        switch (name) {
            case "userName":
                if (!value.trim()) return "User Name is required.";
                if (value.length < 2) return "Name must be at least 2 characters.";
                if (value.length > 50) return "Name cannot exceed 50 characters.";
                break;
            case "userEmail":
                if (!value.trim()) return "Email is required.";
                if (!EMAIL_RULE.test(value)) return "Email is invalid.";
                break;
            case "userPassword":
                if (!value) return "Password is required.";
                if (value.length < 8) return "Password must be at least 8 characters.";
                break;
            case "userProfile":
                if (!value.trim()) return "Profile image URL is required.";
                if (!IMAGE_URL_RULE.test(value))
                    return "Enter a valid image URL (png, jpg, gif, webp, svg).";
                break;
            case "userRole":
                if (!value) return "Role is required.";
                break;
            default:
                return "";
        }
        return "";
    };

    // valid only when every field is filled and passes its rule
    const isFormValid = Object.entries(form).every(
        ([name, value]) => value && !getFieldError(name, value)
    );

    const handleChange = (e) => {
        const { name, value } = e.target;
        setForm({ ...form, [name]: value });
        setFieldErrors({ ...fieldErrors, [name]: getFieldError(name, value) });
    };

    const handleBlur = (e) => {
        const { name, value } = e.target;
        setFieldErrors({ ...fieldErrors, [name]: getFieldError(name, value) });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const registered = await registeruser(form);
            setUser(registered);
            setSuccess(true);
            setError(false);
            navigate("/");
        } catch {
            setUser(null);
            setSuccess(false);
            setError(true);
        }
    };

    return (
        <div className="d-flex justify-content-center align-items-center min-vh-100 bg-light">
            <div className="card shadow-sm border-0" style={{ width: "25rem" }}>
                <div className="card-body p-4">
                    <h5 className="card-title text-center mb-4">Sign Up</h5>

                    <form onSubmit={handleSubmit}>
                        {user && success && (
                            <div className="alert alert-success py-2" role="alert">
                                User Signed Up Successfully: {user.userId}
                            </div>
                        )}
                        {!user && error && (
                            <div className="alert alert-danger py-2" role="alert">
                                User Registration Failed!!!
                            </div>
                        )}

                        <div className="mb-3">
                            <label className="form-label">User Name</label>
                            <input
                                type="text"
                                name="userName"
                                className={`form-control ${fieldErrors.userName ? "is-invalid" : ""}`}
                                value={form.userName}
                                onChange={handleChange}
                                onBlur={handleBlur}
                            />
                            {fieldErrors.userName && (
                                <div className="invalid-feedback">{fieldErrors.userName}</div>
                            )}
                        </div>

                        <div className="mb-3">
                            <label className="form-label">Email</label>
                            <input
                                type="email"
                                name="userEmail"
                                className={`form-control ${fieldErrors.userEmail ? "is-invalid" : ""}`}
                                value={form.userEmail}
                                onChange={handleChange}
                                onBlur={handleBlur}
                            />
                            {fieldErrors.userEmail && (
                                <div className="invalid-feedback">{fieldErrors.userEmail}</div>
                            )}
                        </div>

                        <div className="mb-3">
                            <label className="form-label">Password</label>
                            <input
                                type="password"
                                name="userPassword"
                                className={`form-control ${fieldErrors.userPassword ? "is-invalid" : ""}`}
                                value={form.userPassword}
                                onChange={handleChange}
                                onBlur={handleBlur}
                            />
                            {fieldErrors.userPassword && (
                                <div className="invalid-feedback">{fieldErrors.userPassword}</div>
                            )}
                        </div>

                        <div className="mb-3">
                            <label className="form-label">Profile Image URL</label>
                            <input
                                type="text"
                                name="userProfile"
                                className={`form-control ${fieldErrors.userProfile ? "is-invalid" : ""}`}
                                value={form.userProfile}
                                onChange={handleChange}
                                onBlur={handleBlur}
                            />
                            {fieldErrors.userProfile && (
                                <div className="invalid-feedback">{fieldErrors.userProfile}</div>
                            )}
                        </div>

                        <div className="mb-3">
                            <label className="form-label">Role</label>
                            <select
                                name="userRole"
                                className={`form-select ${fieldErrors.userRole ? "is-invalid" : ""}`}
                                value={form.userRole}
                                onChange={handleChange}
                                onBlur={handleBlur}
                            >
                                <option value="">-- Select --</option>
                                <option value="Project Owner">Project Owner</option>
                                <option value="Assignee">Assignee</option>
                            </select>
                            {fieldErrors.userRole && (
                                <div className="invalid-feedback">{fieldErrors.userRole}</div>
                            )}
                        </div>

                        <button
                            type="submit"
                            className="btn text-white fw-semibold w-100"
                            style={{ backgroundColor: "#f0b429" }}
                            disabled={!isFormValid}
                        >
                            Sign Up
                        </button>
                    </form>

                    <p className="text-center text-muted mt-3 mb-0 small">
                        Already have an account? <Link to="/">Login</Link>
                    </p>
                </div>
            </div>
        </div>
    );
}

export default UserSignupForm;
