import { useContext, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { addIssue } from "../services/IssueService.js";
import { getProjectsByOwner } from "../services/ProjectService";
import { getAllUsers } from "../services/UserService";
import Sidebar from "./Sidebar";

const TYPES = ["TASK", "BUG", "FEATURE"];
const PRIORITIES = ["LOW", "MEDIUM", "HIGH"];
const STATUSES = [
    { value: "OPEN", label: "TO-DO" },
    { value: "IN_PROGRESS", label: "DEVELOPMENT" },
    { value: "RESOLVED", label: "TESTING" },
    { value: "CLOSED", label: "COMPLETED" },
];
const SUMMARY_RE = /^[A-Za-z0-9\s\-/|.]+$/; // no special chars except - / | .

const gold = { backgroundColor: "#f0b429", color: "#000", border: "none" };
const styles = {
    header: { background: "#f0b429" },
};

const EMPTY = {
    summary: "", type: "", projectId: "", priority: "", description: "",
    assignee: "", tags: "", sprint: "", storyPoint: "", status: "",
};

const isPrime = (n) => {
    if (!Number.isInteger(n) || n < 2) return false;
    for (let i = 2; i * i <= n; i++) if (n % i === 0) return false;
    return true;
};

function CreateIssue() {
    const { user } = useContext(AuthContext);
    const navigate = useNavigate();
    const [form, setForm] = useState(EMPTY);
    const [projects, setProjects] = useState([]);
    const [users, setUsers] = useState([]);
    const [serverError, setServerError] = useState("");
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        if (!user?.userId) return;
        getProjectsByOwner(user.userId).then((d) => setProjects(d || [])).catch(() => setProjects([]));
        getAllUsers().then((d) => setUsers(d || [])).catch(() => setUsers([]));
    }, [user]);
    const assigneeOptions = useMemo(
        () => users.filter((u) => Number(u.role) !== 1), // exclude project owners
        [users]
    );
    const errors = useMemo(() => {
        const e = {};
        const summary = form.summary.trim();
        if (!summary) e.summary = "Summary is required";
        else if (summary.length > 150) e.summary = "Max length is 150 characters";
        else if (!SUMMARY_RE.test(summary)) e.summary = "Only letters, numbers and - / | . are allowed";

        if (!form.type) e.type = "Type is required";
        if (!form.projectId) e.projectId = "Project is required";
        if (!form.priority) e.priority = "Priority is required";
        if (!form.assignee) e.assignee = "Assignee is required";
        if (!form.status) e.status = "Status is required";

        if (form.description && form.description.length > 500) e.description = "Max length is 500 characters";
        if (form.tags && form.tags.length > 100) e.tags = "Max length is 100 characters";

        if (form.sprint && !/^[1-9]\d*$/.test(form.sprint)) e.sprint = "Sprint must be a positive number";

        if (form.storyPoint) {
            if (!/^\d+$/.test(form.storyPoint) || !isPrime(Number(form.storyPoint)))
                e.storyPoint = "Story point must be a prime number";
        }
        return e;
    }, [form]);

    const isValid = Object.keys(errors).length === 0;
    const onChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });
    const onReset = () => { setForm(EMPTY); setServerError(""); };

    const onSubmit = (e) => {
        e.preventDefault();
        if (!isValid) return;
        setSaving(true);
        setServerError("");
        addIssue({
            summary: form.summary.trim(),
            type: form.type,
            projectId: Number(form.projectId),
            priority: form.priority,
            status: form.status,
            description: form.description.trim() || null,
            assignee: Number(form.assignee),
            tags: form.tags.trim() || null,
            sprint: form.sprint || null,
            storyPoint: form.storyPoint ? Number(form.storyPoint) : null,
            createdBy: user?.userId,
        })
            .then(() => navigate("/project-owner-dashboard"))
            .catch((err) => setServerError(err.response?.data?.message || "Failed to create issue"))
            .finally(() => setSaving(false));
    };

    const err = (k) => errors[k] && <div className="text-danger small mt-1">{errors[k]}</div>;

    return (
        <div className="d-flex">
            <Sidebar activeKey="createIssue" dashboardPath="/project-owner-dashboard" />

            {/* Main */}
            <div className="flex-grow-1">
                <div
                    className="d-flex align-items-center justify-content-end px-3 py-2"
                    style={styles.header}   >
                    <span className="fw-bold text-white">Issue Tracking System</span>
                </div>

                <div className="p-4">
                    <h5 className="fw-bold mb-3">Create Issue</h5>
                    {serverError && <div className="alert alert-danger py-2">{serverError}</div>}

                    <form onSubmit={onSubmit} noValidate>
                        <div className="row g-3">
                            <div className="col-md-6">
                                <label className="form-label small">Summary</label>
                                <input name="summary" className="form-control form-control-sm"
                                    placeholder="Enter summary" maxLength={150}
                                    value={form.summary} onChange={onChange} />
                                {err("summary")}
                            </div>
                            <div className="col-md-6">
                                <label className="form-label small">Type</label>
                                <select name="type" className="form-select form-select-sm"
                                    value={form.type} onChange={onChange}>
                                    <option value="">Select type</option>
                                    {TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                                </select>
                                {err("type")}
                            </div>

                            <div className="col-md-6">
                                <label className="form-label small">Project</label>
                                <select name="projectId" className="form-select form-select-sm"
                                    value={form.projectId} onChange={onChange}>
                                    <option value="">Select project</option>
                                    {projects.map((p) => (
                                        <option key={p.projectId} value={p.projectId}>{p.projectName}</option>
                                    ))}
                                </select>
                                {err("projectId")}
                            </div>
                            <div className="col-md-6">
                                <label className="form-label small">Priority</label>
                                <select name="priority" className="form-select form-select-sm"
                                    value={form.priority} onChange={onChange}>
                                    <option value="">Select priority</option>
                                    {PRIORITIES.map((p) => <option key={p} value={p}>{p}</option>)}
                                </select>
                                {err("priority")}
                            </div>

                            <div className="col-12">
                                <label className="form-label small">Description</label>
                                <textarea name="description" className="form-control form-control-sm"
                                    placeholder="Enter description" maxLength={500} rows={2}
                                    value={form.description} onChange={onChange} />
                                {err("description")}
                            </div>

                            <div className="col-md-6">
                                <label className="form-label small">Assignee</label>
                                <select name="assignee" className="form-select form-select-sm"
                                    value={form.assignee} onChange={onChange}>
                                    <option value="">Select assignee</option>
                                    {assigneeOptions.map((u) => (
                                        <option key={u.userId} value={u.userId}>{u.name}</option>
                                    ))}
                                </select>
                                {err("assignee")}
                            </div>
                            <div className="col-md-6">
                                <label className="form-label small">Tags</label>
                                <input name="tags" className="form-control form-control-sm"
                                    placeholder="Enter tags" maxLength={100}
                                    value={form.tags} onChange={onChange} />
                                {err("tags")}
                            </div>

                            <div className="col-md-6">
                                <label className="form-label small">Sprint</label>
                                <input name="sprint" className="form-control form-control-sm"
                                    placeholder="Enter sprint" value={form.sprint} onChange={onChange} />
                                {err("sprint")}
                            </div>
                            <div className="col-md-6">
                                <label className="form-label small">Story Point</label>
                                <input name="storyPoint" className="form-control form-control-sm"
                                    placeholder="Enter story points" value={form.storyPoint} onChange={onChange} />
                                {err("storyPoint")}
                            </div>

                            <div className="col-md-6">
                                <label className="form-label small">Status</label>
                                <select name="status" className="form-select form-select-sm"
                                    value={form.status} onChange={onChange}>
                                    <option value="">Select status</option>
                                    {STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
                                </select>

                                {err("status")}
                            </div>
                        </div>

                        <div className="d-flex justify-content-center gap-2 mt-4">
                            <button type="submit" className="btn btn-sm" style={gold}
                                disabled={!isValid || saving}>
                                {saving ? "SAVING..." : "CREATE"}
                            </button>
                            <button type="button" className="btn btn-sm btn-outline-secondary" onClick={onReset}>
                                RESET
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default CreateIssue;
