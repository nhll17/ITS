import { useEffect, useState, useContext } from "react";
import { login } from "../services/UserService";
import { useNavigate, Link } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";


function UserLoginForm() {
    const [form, setForm] = useState({ userEmail: "", userPassword: "", userRole: "" });
    const [user, setUser] = useState(null);
    const [error, setError] = useState(false);
    const [success, setSuccess] = useState(false);
    const [fieldErrors, setFieldErrors] = useState({});

    const navigate = useNavigate();
    const { ctxLogin, user: loggedInUser } = useContext(AuthContext);
    const isLoggedOut = loggedInUser === null;

    useEffect(() => {
        setForm({ userEmail: "", userPassword: "", userRole: "" });
        setFieldErrors({});
        setError(false);
        setSuccess(false);
        setUser(null);
    }, [isLoggedOut]);

    const getFieldError = (name, value) => {
        switch (name) {
            case "userEmail":
                if (!value) return "Email is required";
                if (!/\S+@\S+\.\S+/.test(value)) return "Email is invalid";
                break;
            case "userPassword":
                if (!value) return "Password is required";
                if (value.length < 8) return "Password must be at least 8 characters";
                break;
            case "userRole":
                if (!value) return "Role is required";
                break;
            default:
                return "";
        }
        return "";
    };

    // valid only when every field is filled and passes its rule
    const isFormValid = Object.entries(form).every(
        ([name, value]) => value && !getFieldError(name, value)
    );

    const handleChange = (e) => {
        const { name, value } = e.target;
        setForm({ ...form, [name]: value });
        setFieldErrors({ ...fieldErrors, [name]: "" });
    };

    const handleBlur = (e) => {
        const { name, value } = e.target;
        setFieldErrors({ ...fieldErrors, [name]: getFieldError(name, value) });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!isFormValid) return;
        // role is collected per the requirement but not sent — backend login takes only email & password
        const result = await login(form.userEmail, form.userPassword);
        if (result.success && result.user && result.user.userId) {
            ctxLogin(result.user);
            setUser(result.user);
            setSuccess(true);
            setError(false);
            if (result.success && result.user && result.user.userId) {
                ctxLogin(result.user);
                setUser(result.user);
                setSuccess(true);
                setError(false);

                // route by the role the BACKEND returned (1 = Project Owner, 2 = Assignee)
                if (result.user.role === 1) {
                    navigate("/project-owner-dashboard");
                } else if (result.user.role === 2) {
                    navigate("/assignee-dashboard");
                } else {
                    navigate("/"); // fallback if role is missing/unexpected
                }
            } else {
                setUser(null);
                setError(true);
                setSuccess(false);
            }
        } else {
            setUser(null);
            setError(true);
            setSuccess(false);
        }
    };

     return (
    <div className="d-flex justify-content-center align-items-center min-vh-100 bg-light">
        <div className="card shadow-sm border-0" style={{ width: "25rem" }}>
            
            <div className="card-body p-4">
                <h5 className="card-title text-center mb-4">Login</h5>
 
                <form onSubmit={handleSubmit}>
                    {success && user && (
                        <div className="alert alert-success py-2" role="alert">
                            <p className="mb-1">Login successful!</p>
                            <p className="mb-0">Welcome, {user.name}!</p>
                        </div>
                    )}
                    {error && (
                        <div className="alert alert-danger py-2" role="alert">
                            Login failed. Please check your credentials.
                        </div>
                    )}
 
                    <div className="mb-3">
                        <label className="form-label">Email address</label>
                        <input
                            type="email"
                            name="userEmail"
                            className={`form-control ${fieldErrors.userEmail ? "is-invalid" : ""}`}
                            placeholder="Enter email"
                            value={form.userEmail}
                            onChange={handleChange}
                            onBlur={handleBlur}
                        />
                        {fieldErrors.userEmail && <div className="invalid-feedback">{fieldErrors.userEmail}</div>}
                    </div>
 
                    <div className="mb-3">
                        <label className="form-label">Password</label>
                        <input
                            type="password"
                            name="userPassword"
                            className={`form-control ${fieldErrors.userPassword ? "is-invalid" : ""}`}
                            placeholder="Password"
                            value={form.userPassword}
                            onChange={handleChange}
                            onBlur={handleBlur}
                        />
                        {fieldErrors.userPassword && (
                            <div className="invalid-feedback">{fieldErrors.userPassword}</div>
                        )}
                    </div>
 
                    <div className="mb-3">
                        <label className="form-label">Role</label>
                        <select
                            name="userRole"
                            className={`form-select ${fieldErrors.userRole ? "is-invalid" : ""}`}
                            value={form.userRole}
                            onChange={handleChange}
                            onBlur={handleBlur}
                        >
                            <option value="">Select your role</option>
                            <option value="Project Owner">Project Owner</option>
                            <option value="Assignee">Assignee</option>
                        </select>
                        {fieldErrors.userRole && <div className="invalid-feedback">{fieldErrors.userRole}</div>}
                    </div>
 
                    <button
                        type="submit"
                        className="btn text-white fw-semibold"
                        style={{ backgroundColor: "#f0b429" }}
                        disabled={!isFormValid}
                    >
                        Login
                    </button>
                </form>
 
                <p className="text-center text-muted mt-3 mb-0 small">
                    Don't have an account? <Link to="/signup">Sign Up</Link>
                </p>
            </div>
        </div>
    </div>
);
}

export default UserLoginForm;
