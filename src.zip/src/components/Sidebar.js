import { useCallback, useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { getProjectsByOwner } from "../services/ProjectService";
import { getIssuesByAssignee } from "../services/IssueService.js";
import { getIssuesByProject } from "../services/ProjectService";

const gold = { backgroundColor: "#f0b429", color: "#000", border: "none" };
const styles = {
    sidebar: {
        width: 220,
        flexShrink: 0,
        height: "100vh",
        position: "sticky",
        top: 0,
        background: "#1e1e1e",
        color: "#fff",
    },
    navLink: { color: "#f0b429", cursor: "pointer", padding: "8px 4px", fontSize: "0.9rem" },
    avatar: { width: 90, height: 90, borderRadius: "50%", objectFit: "cover", border: "3px solid #f0b429" },
};

function Sidebar({ role = "owner", activeKey, issueCount, projectCount, onDashboardClick }) {
    const { user, ctxLogout } = useContext(AuthContext);
    const navigate = useNavigate();
    const isAssignee = role === "assignee";

    // Sidebar fetches its own counts so every page shows correct numbers.
    // If a parent passes counts as props, those win (prop ?? internal).
    const [ownerProjects, setOwnerProjects] = useState(0);
    const [ownerIssues, setOwnerIssues] = useState(0);
    const [assigneeIssues, setAssigneeIssues] = useState(0);

    const loadCounts = useCallback(() => {
        if (!user?.userId) return;

        if (isAssignee) {
            getIssuesByAssignee(user.userId)
                .then((data) => setAssigneeIssues((data || []).length))
                .catch(() => setAssigneeIssues(0));
            return;
        }

        // Owner: projects + total issues across all of them (same logic as the dashboard)
        getProjectsByOwner(user.userId)
            .then((list) => {
                const projectList = list || [];
                setOwnerProjects(projectList.length);
                return Promise.all(
                    projectList.map((p) =>
                        getIssuesByProject(p.projectId)
                            .then((data) => (data || []).length)
                            .catch(() => 0)
                    )
                );
            })
            .then((counts) => setOwnerIssues((counts || []).reduce((a, b) => a + b, 0)))
            .catch(() => {
                setOwnerProjects(0);
                setOwnerIssues(0);
            });
    }, [user, isAssignee]);

    // Load on mount, and refresh when the tab regains focus (picks up DB changes)
    useEffect(() => {
        loadCounts();
        window.addEventListener("focus", loadCounts);
        return () => window.removeEventListener("focus", loadCounts);
    }, [loadCounts]);

    // Props override internal fetch when provided
    const shownIssueCount = issueCount ?? (isAssignee ? assigneeIssues : ownerIssues);
    const shownProjectCount = projectCount ?? ownerProjects;

    const handleLogout = () => {
        ctxLogout();
        navigate("/");
    };

    const ownerLinks = [
        { key: "dashboard", label: "Project Dashboard", action: onDashboardClick || (() => navigate("/project-owner-dashboard")) },
        { key: "create-project", label: "Create Project", action: () => navigate("/create-project") },
        { key: "create-issue", label: "Create Issue", action: () => navigate("/create-issue") },
    ];

    return (
        <div className="d-flex flex-column p-3 text-center" style={styles.sidebar}>
            <img src={user?.profile} alt={user?.name} style={styles.avatar} className="mb-2 mx-auto" />
            <div className="fw-bold">{user?.name}</div>
            <div style={{ color: "#f0b429", fontSize: "0.8rem" }}>{user?.email}</div>

            {isAssignee ? (
                <div className="my-3 flex-grow-1">
                    <div className="fs-4 fw-bold">{shownIssueCount}</div>
                    <div style={{ fontSize: "0.8rem" }}>Issues Assigned</div>
                </div>
            ) : (
                <div className="flex-grow-1">
                    <div className="d-flex justify-content-around text-center my-3">
                        <div>
                            <div className="fs-5 fw-bold">{shownProjectCount}</div>
                            <div className="small">Projects<br />Created</div>
                        </div>
                        <div>
                            <div className="fs-5 fw-bold">{shownIssueCount}</div>
                            <div className="small">Issues<br />Created</div>
                        </div>
                    </div>
                    <nav className="text-start">
                        {ownerLinks.map((l) => (
                            <div key={l.key} style={styles.navLink} onClick={l.action}
                                className={activeKey === l.key ? "fw-bold" : ""}>
                                ◆ {l.label}
                            </div>
                        ))}
                    </nav>
                </div>
            )}

            <button className="btn btn-sm mt-3" style={gold} onClick={handleLogout}>
                ⎋ Logout
            </button>
        </div>
    );
}

export default Sidebar;
