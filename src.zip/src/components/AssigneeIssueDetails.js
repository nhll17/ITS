import { useContext, useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { getIssueById, getIssuesByAssignee, updateIssue } from "../services/IssueService.js";
import Sidebar from "./Sidebar"; // adjust path if Sidebar.js is in another folder

const STATUSES = [
    { value: "OPEN", label: "TO-DO" },
    { value: "IN_PROGRESS", label: "DEVELOPMENT" },
    { value: "RESOLVED", label: "TESTING" },
    { value: "CLOSED", label: "COMPLETED" },
];

const styles = {
    crumb: { color: "#f0b429", cursor: "pointer", textDecoration: "underline" },
    titleBar: { background: "#f5f5f5", padding: "12px 16px", borderRadius: 4, color: "#f0b429", fontWeight: 700, fontSize: "1.4rem" },
    label: { color: "#27ae60", fontWeight: 700 },
    tag: { background: "#27ae60", color: "#fff", borderRadius: 4, padding: "2px 8px", fontSize: "0.75rem" },
    saveBtn: { background: "#f0b429", color: "#000", border: "none", fontWeight: 600 },
};

function AssigneeIssueDetails() {
    const { user } = useContext(AuthContext);
    const navigate = useNavigate();
    const { id } = useParams();

    const [issue, setIssue] = useState(null);
    const [status, setStatus] = useState("");
    const [assignedCount, setAssignedCount] = useState(0);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        getIssueById(id)
            .then((data) => {
                setIssue(data);
                setStatus(data?.status || "");
            })
            .catch(() => setIssue(null))
            .finally(() => setLoading(false));
    }, [id]);

    // Same source as the dashboard, so the sidebar count matches
    useEffect(() => {
        if (!user?.userId) return;
        getIssuesByAssignee(user.userId)
            .then((data) => setAssignedCount((data || []).length))
            .catch(() => setAssignedCount(0));
    }, [user]);

    // Save is enabled only when the status differs from the original
    const dirty = useMemo(
        () => issue && status && status !== issue.status,
        [issue, status]
    );

    const handleSave = () => {
        if (!dirty) return;
        setSaving(true);
        // Send the full issue back with the updated status (backend expects IssueDto)
        updateIssue(id, { ...issue, status })
            .then((updated) => setIssue(updated || { ...issue, status }))
            .catch(() => {})
            .finally(() => setSaving(false));
    };

    return (
        <div className="d-flex">
            <Sidebar role="assignee" issueCount={assignedCount} />

            {/* Main */}
            <div className="flex-grow-1 p-4">
                {loading ? (
                    <div className="text-center mt-5">Loading...</div>
                ) : !issue ? (
                    <div className="text-center mt-5">Issue not found !</div>
                ) : (
                    <>
                        {/* Breadcrumb */}
                        <div className="mb-3">
                            <span style={styles.crumb} onClick={() => navigate("/assignee-dashboard")}>
                                Issue Dashboard
                            </span>
                            <span className="text-muted"> / Issue Details</span>
                        </div>

                        {/* Title */}
                        <div style={styles.titleBar} className="mb-4">{issue.summary}</div>

                        {/* Description + status dropdown */}
                        <div className="d-flex justify-content-between align-items-start mb-4">
                            <div style={{ maxWidth: "60%" }}>
                                <div style={styles.label}>Description :</div>
                                <div className="text-muted">{issue.description}</div>
                            </div>
                            <select
                                className="form-select"
                                style={{ maxWidth: 220 }}
                                value={status}
                                onChange={(e) => setStatus(e.target.value)}
                            >
                               {STATUSES.map((s) => (
                                    <option key={s.value} value={s.value}>{s.label}</option>
                                ))}
                            </select>
                        </div>

                        {/* Details */}
                        <h5 className="fw-bold">Details</h5>
                        <div className="row mb-2">
                            <div className="col-6">Type: {issue.type}</div>
                            <div className="col-6">Sprint: {issue.sprint}</div>
                        </div>
                        <div className="row mb-2 align-items-center">
                            <div className="col-6 d-flex align-items-center">
                                Tags: 
                                {issue.tags && <span style={styles.tag}>{issue.tags}</span>}
                            </div>
                            <div className="col-6">Priority: {issue.priority}</div>
                        </div>
                        <div className="row mb-4">
                            <div className="col-6">Story Points: {issue.storyPoints}</div>
                        </div>

                        <hr />

                        {/* Save */}
                        <div className="text-center">
                            <button
                                style={styles.saveBtn}
                                className="btn px-4"
                                disabled={!dirty || saving}
                                onClick={handleSave}
                            >
                                {saving ? "Saving..." : "Save Updates"}
                            </button>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
}

export default AssigneeIssueDetails;
