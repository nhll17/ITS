import { useContext } from "react";
import { Navigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

function RoleRoute({ allowedRole, children }) {
    const { user } = useContext(AuthContext);
    if (!user) return <Navigate to="/" replace />;        // not logged in
    if (user.role !== allowedRole) return <Navigate to="/" replace />; // wrong role
    return children;
}

export default RoleRoute;