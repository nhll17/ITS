import { useCallback, useContext, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { getProjectsByOwner, getIssuesByProject } from "../services/ProjectService";
import { getAllUsers } from "../services/UserService";
import Sidebar from "./Sidebar"; 

const COLUMNS = [
    { key: "OPEN", label: "TO-DO", color: "#e74c3c" },
    { key: "IN_PROGRESS", label: "DEVELOPMENT", color: "#3498db" },
    { key: "RESOLVED", label: "TESTING", color: "#9b59b6" },
    { key: "CLOSED", label: "COMPLETED", color: "#27ae60" },
];

const PRIORITIES = ["HIGH", "MEDIUM", "LOW"];
const priorityColor = (p) => (p === "HIGH" ? "danger" : p === "MEDIUM" ? "warning" : "success");

const styles = {
    header: { background: "#f0b429" },
    col: { flex: 1, minWidth: 210, background: "#f7f7f7", borderRadius: 6 },
    colHead: { borderBottom: "3px solid", fontWeight: 700, fontSize: "0.8rem", padding: 8 },
    card: { background: "#fff", border: "1px solid #e6e6e6", borderRadius: 4, padding: 8, margin: 8, fontSize: "0.8rem" },
    gold: { backgroundColor: "#f0b429" },
    cardAvatar: { width: 20, height: 20, borderRadius: "50%", objectFit: "cover" },
    countBadge: { background: "#f0b429", color: "#000", borderRadius: 10, padding: "0 8px", fontSize: "0.75rem", marginLeft: 6 },
};

function ProjectOwnerDashboard() {
    const { user } = useContext(AuthContext);
    const navigate = useNavigate();
    const [projects, setProjects] = useState([]);
    const [selected, setSelected] = useState(null);
    const [issues, setIssues] = useState([]);
    const [totalIssues, setTotalIssues] = useState(0);
    const [search, setSearch] = useState("");
    const [assignee, setAssignee] = useState("");
    const [priority, setPriority] = useState("All");
    const [loading, setLoading] = useState(true);
    const [usersById, setUsersById] = useState({});

    // Pull projects for this owner + compute total issues across ALL of them
    const refresh = useCallback(() => {
        if (!user?.userId) return;
        getProjectsByOwner(user.userId)
            .then((list) => {
                const projectList = list || [];
                setProjects(projectList);
                setSelected((prev) => prev || (projectList.length ? projectList[0] : null));

                Promise.all(
                    projectList.map((p) =>
                        getIssuesByProject(p.projectId)
                            .then((data) => (data || []).length)
                            .catch(() => 0)
                    )
                ).then((counts) => setTotalIssues(counts.reduce((a, b) => a + b, 0)));
            })
            .catch(() => setProjects([]))
            .finally(() => setLoading(false));
    }, [user]);

    // Run on mount, and again whenever the tab regains focus (picks up DB changes)
    useEffect(() => {
        refresh();
        window.addEventListener("focus", refresh);
        return () => window.removeEventListener("focus", refresh);
    }, [refresh]);

    // Issues for the currently selected project (the Kanban board)
    useEffect(() => {
        if (!selected) return;
        getIssuesByProject(selected.projectId)
            .then((data) => setIssues(data || []))
            .catch(() => setIssues([]));
    }, [selected]);

    // Fetch all users once, build an id -> user lookup
    useEffect(() => {
        getAllUsers()
            .then((list) => {
                const map = {};
                (list || []).forEach((u) => {
                    map[u.userId] = u; // key by the same id stored in issue.assignee
                });
                setUsersById(map);
            })
            .catch(() => setUsersById({}));
    }, []);

    const assignees = useMemo(
        () => [...new Set(issues.map((i) => i.assignee).filter(Boolean))],
        [issues]
    );

    const filteredIssues = useMemo(() => {
        let result = issues;
        if (search.trim()) {
            let regex = null;
            try {
                regex = new RegExp(search.trim(), "i");
            } catch {
                regex = null;
            }
            result = result.filter((i) => {
                const text = `${i.summary || ""} ${i.description || ""}`;
                return regex ? regex.test(text) : text.toLowerCase().includes(search.toLowerCase());
            });
        }
        if (assignee) result = result.filter((i) => String(i.assignee) === assignee);
        if (priority !== "All") result = result.filter((i) => i.priority === priority);
        return result;
    }, [issues, search, assignee, priority]);

    return (
        <div className="d-flex">
            <Sidebar
                role="owner"
                activeKey="dashboard"
                projectCount={projects.length}
                issueCount={totalIssues}
                onDashboardClick={refresh}
            />

            {/* Main */}
            <div className="flex-grow-1">
                <div className="d-flex align-items-center justify-content-between px-3 py-2" style={styles.header}>
                    <input
                        type="text"
                        className="form-control form-control-sm w-50"
                        placeholder="Search issue by summary or description"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                    <span className="fw-bold text-white">Issue Tracking System</span>
                </div>

                <div className="p-4">
                    {loading ? (
                        <p>Loading...</p>
                    ) : projects.length === 0 ? (
                        <div className="text-center mt-5">
                            <p className="text-danger fw-bold">No Projects Available !</p>
                            <button
                                className="btn btn-sm text-white"
                                style={styles.gold}
                                onClick={() => navigate("/create-project")}
                            >
                                Create Project
                            </button>
                        </div>
                    ) : (
                        <>
                            <h6 className="fw-bold text-secondary">PROJECT DASHBOARD</h6>
                            <div className="row g-3 mt-1">
                                <div className="col-md-6">
                                    <label className="form-label small">Project Name</label>
                                    <select
                                        className="form-select form-select-sm"
                                        value={selected?.projectId || ""}
                                        onChange={(e) =>
                                            setSelected(projects.find((p) => p.projectId === Number(e.target.value)))
                                        }
                                    >
                                        {projects.map((p) => (
                                            <option key={p.projectId} value={p.projectId}>
                                                {p.projectName}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <div className="col-md-6">
                                    <label className="form-label small">Project Owner Name</label>
                                    <input className="form-control form-control-sm" value={user?.name || ""} readOnly />
                                </div>
                            </div>

                            <p className="small text-muted mt-2">
                                Start Date: {selected?.startDate} | End Date: {selected?.endDate}
                            </p>

                            <div className="row g-3">
                                <div className="col-md-6">
                                    <label className="form-label small">Filter by Assignee</label>
                                    <select
                                        className="form-select form-select-sm"
                                        value={assignee}
                                        onChange={(e) => setAssignee(e.target.value)}
                                    >
                                        <option value="">All</option>
                                        {assignees.map((a) => (
                                            <option key={a} value={a}>
                                                {usersById[a]?.name || `Assignee #${a}`}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <div className="col-md-6">
                                    <label className="form-label small">Filter by Priority</label>
                                    <select
                                        className="form-select form-select-sm"
                                        value={priority}
                                        onChange={(e) => setPriority(e.target.value)}
                                    >
                                        <option value="All">All</option>
                                        {PRIORITIES.map((p) => (
                                            <option key={p} value={p}>
                                                {p.charAt(0) + p.slice(1).toLowerCase()}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                            </div>

                            {/* Kanban */}
                            <div className="d-flex gap-2">
                                {COLUMNS.map((col) => {
                                    const colIssues = filteredIssues.filter((i) => i.status === col.key);
                                    return (
                                        <div key={col.key} style={styles.col}>
                                            <div style={{ ...styles.colHead, borderBottomColor: col.color }}>
                                                {col.label}
                                                <span style={styles.countBadge}>{colIssues.length}</span>
                                            </div>

                                            {colIssues.map((i) => {
                                                const cardAssignee = i.assignee ? usersById[i.assignee] : null;
                                                return (
                                                    <div
                                                        key={i.issueId}
                                                        style={{ ...styles.card, cursor: "pointer" }}
                                                        onClick={() => navigate(`/issue/${i.issueId}`)}
                                                    >
                                                        <div className="d-flex justify-content-between text-muted">
                                                            <span>Id: {i.issueId}</span>
                                                            <span>{i.lastUpdated || i.createdOn || "—"}</span>
                                                        </div>

                                                        <div className="fw-bold my-1">{i.summary}</div>
                                                        <div className="text-muted mb-2">{i.description}</div>

                                                        <div className="d-flex align-items-center justify-content-between">
                                                            <span className="d-flex align-items-center">
                                                                {cardAssignee ? (
                                                                    <>
                                                                        <img
                                                                            src={cardAssignee.profile}
                                                                            alt={cardAssignee.name}
                                                                            style={styles.cardAvatar}
                                                                            className="me-1"
                                                                        />
                                                                        {cardAssignee.name}
                                                                    </>
                                                                ) : (
                                                                    "Unassigned"
                                                                )}
                                                            </span>

                                                            {i.priority && (
                                                                <span className={`badge bg-${priorityColor(i.priority)}`}>
                                                                    {i.priority.charAt(0) + i.priority.slice(1).toLowerCase()}
                                                                </span>
                                                            )}
                                                        </div>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    );
                                })}
                            </div>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
}

export default ProjectOwnerDashboard;
