import { useCallback, useContext, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { getProjectsByOwner, getIssuesByProject } from "../services/ProjectService";

const COLUMNS = [
    { key: "OPEN", label: "OPEN", color: "#e74c3c" },
    { key: "IN_PROGRESS", label: "IN PROGRESS", color: "#3498db" },
    { key: "RESOLVED", label: "RESOLVED", color: "#9b59b6" },
    { key: "CLOSED", label: "CLOSED", color: "#27ae60" },
];

const PRIORITIES = ["HIGH", "MEDIUM", "LOW"];
const priorityColor = (p) => (p === "HIGH" ? "danger" : p === "MEDIUM" ? "warning" : "success");

const styles = {
    sidebar: { width: 220, minHeight: "100vh", background: "#1e1e1e", color: "#fff" },
    header: { background: "#f0b429" },
    navLink: { color: "#f0b429", cursor: "pointer", padding: "8px 4px", fontSize: "0.9rem" },
    logout: { background: "#f0b429", color: "#000", border: "none" },
    col: { flex: 1, minWidth: 210, background: "#f7f7f7", borderRadius: 6 },
    colHead: { borderBottom: "3px solid", fontWeight: 700, fontSize: "0.8rem", padding: 8 },
    card: { background: "#fff", border: "1px solid #e6e6e6", borderRadius: 4, padding: 8, margin: 8, fontSize: "0.8rem" },
    badge: { background: "#ddd", borderRadius: 10, padding: "0 6px", fontSize: "0.7rem", marginLeft: 4 },
    gold: { backgroundColor: "#f0b429" },
};

function ProjectOwnerDashboard() {
    const { user, ctxLogout } = useContext(AuthContext);
    const navigate = useNavigate();
    const [projects, setProjects] = useState([]);
    const [selected, setSelected] = useState(null);
    const [issues, setIssues] = useState([]);
    const [totalIssues, setTotalIssues] = useState(0);
    const [search, setSearch] = useState("");
    const [assignee, setAssignee] = useState("");
    const [priority, setPriority] = useState("All");
    const [loading, setLoading] = useState(true);

    // Pull projects for this owner + compute total issues across ALL of them
   const refresh = useCallback(() => {
    if (!user?.userId) return;
    getProjectsByOwner(user.userId)
        .then((list) => {                       // was (res) => res.data
            const projectList = list || [];
            setProjects(projectList);
            setSelected((prev) => prev || (projectList.length ? projectList[0] : null));

            Promise.all(
                projectList.map((p) =>
                    getIssuesByProject(p.projectId)
                        .then((data) => (data || []).length)   // was r.data
                        .catch(() => 0)
                )
            ).then((counts) => setTotalIssues(counts.reduce((a, b) => a + b, 0)));
        })
        .catch(() => setProjects([]))
        .finally(() => setLoading(false));
}, [user]);

    // Run on mount, and again whenever the tab regains focus (picks up DB changes)
    useEffect(() => {
        refresh();
        window.addEventListener("focus", refresh);
        return () => window.removeEventListener("focus", refresh);
    }, [refresh]);

    // Issues for the currently selected project (the Kanban board)
    useEffect(() => {
    if (!selected) return;
    getIssuesByProject(selected.projectId)
        .then((data) => setIssues(data || []))   // was res.data
        .catch(() => setIssues([]));
}, [selected]);



    const handleLogout = () => {
        ctxLogout();
        navigate("/");
    };

    const links = [
        { key: "dashboard", label: "Project Dashboard", action: refresh },
        { key: "createProject", label: "Create Project", action: () => navigate("/create-project") },
        { key: "createIssue", label: "Create Issue", action: () => navigate("/create-issue") },
    ];

    const assignees = useMemo(
        () => [...new Set(issues.map((i) => i.assignee).filter(Boolean))],
        [issues]
    );

    const filteredIssues = useMemo(() => {
        let result = issues;
        if (search.trim()) {
            let regex = null;
            try {
                regex = new RegExp(search.trim(), "i");
            } catch {
                regex = null;
            }
            result = result.filter((i) => {
                const text = `${i.summary || ""} ${i.description || ""}`;
                return regex ? regex.test(text) : text.toLowerCase().includes(search.toLowerCase());
            });
        }
        if (assignee) result = result.filter((i) => String(i.assignee) === assignee);
        if (priority !== "All") result = result.filter((i) => i.priority === priority);
        return result;
    }, [issues, search, assignee, priority]);

    return (
        <div className="d-flex">
            {/* Sidebar */}
            <div className="d-flex flex-column p-3" style={styles.sidebar}>
                <div className="text-center mb-3">
                    <img
                        src={user?.profile}
                        alt={user?.name}
                        width="70"
                        height="70"
                        className="rounded-circle border border-2 border-warning object-fit-cover"
                    />
                    <div className="fw-bold mt-2">{user?.name}</div>
                    <div className="small text-warning">{user?.email}</div>
                </div>

                <div className="d-flex justify-content-around text-center mb-4">
                    <div>
                        <div className="fs-5 fw-bold">{projects.length}</div>
                        <div className="small">Projects<br />Created</div>
                    </div>
                    <div>
                        <div className="fs-5 fw-bold">{totalIssues}</div>
                        <div className="small">Issues<br />Created</div>
                    </div>
                </div>

                <nav className="flex-grow-1">
                    {links.map((l) => (
                        <div key={l.key} style={styles.navLink} onClick={l.action}>
                            ◆ {l.label}
                        </div>
                    ))}
                </nav>

                <button className="btn btn-sm mt-3" style={styles.logout} onClick={handleLogout}>
                    ⎋ Logout
                </button>
            </div>

            {/* Main */}
            <div className="flex-grow-1">
                <div className="d-flex align-items-center justify-content-between px-3 py-2" style={styles.header}>
                    <input
                        type="text"
                        className="form-control form-control-sm w-50"
                        placeholder="Search issue by summary or description"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                    <span className="fw-bold text-white">Issue Tracking System</span>
                </div>

                <div className="p-4">
                    {loading ? (
                        <p>Loading...</p>
                    ) : projects.length === 0 ? (
                        <div className="text-center mt-5">
                            <p className="text-danger fw-bold">No Projects Available !</p>
                            <button
                                className="btn btn-sm text-white"
                                style={styles.gold}
                                onClick={() => navigate("/create-project")}
                            >
                                Create Project
                            </button>
                        </div>
                    ) : (
                        <>
                            <h6 className="fw-bold text-secondary">PROJECT DASHBOARD</h6>
                            <div className="row g-3 mt-1">
                                <div className="col-md-6">
                                    <label className="form-label small">Project Name</label>
                                    <select
                                        className="form-select form-select-sm"
                                        value={selected?.projectId || ""}
                                        onChange={(e) =>
                                            setSelected(projects.find((p) => p.projectId === Number(e.target.value)))
                                        }
                                    >
                                        {projects.map((p) => (
                                            <option key={p.projectId} value={p.projectId}>
                                                {p.projectName}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <div className="col-md-6">
                                    <label className="form-label small">Project Owner Name</label>
                                    <input className="form-control form-control-sm" value={user?.name || ""} readOnly />
                                </div>
                            </div>

                            <p className="small text-muted mt-2">
                                Start Date: {selected?.startDate} | End Date: {selected?.endDate}
                            </p>

                            <div className="row g-3">
                                <div className="col-md-6">
                                    <label className="form-label small">Filter by Assignee</label>
                                    <select
                                        className="form-select form-select-sm"
                                        value={assignee}
                                        onChange={(e) => setAssignee(e.target.value)}
                                    >
                                        <option value="">All</option>
                                        {assignees.map((a) => (
                                            <option key={a} value={a}>
                                                Assignee #{a}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <div className="col-md-6">
                                    <label className="form-label small">Filter by Priority</label>
                                    <select
                                        className="form-select form-select-sm"
                                        value={priority}
                                        onChange={(e) => setPriority(e.target.value)}
                                    >
                                        <option value="All">All</option>
                                        {PRIORITIES.map((p) => (
                                            <option key={p} value={p}>
                                                {p.charAt(0) + p.slice(1).toLowerCase()}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                            </div>

                            {/* Kanban */}
                            <div className="d-flex gap-3 mt-3">
                                {COLUMNS.map((col) => {
                                    const colIssues = filteredIssues.filter((i) => i.status === col.key);
                                    return (
                                        <div key={col.key} style={styles.col}>
                                            <div style={{ ...styles.colHead, borderColor: col.color, color: col.color }}>
                                                {col.label}
                                                <span style={styles.badge}>{colIssues.length}</span>
                                            </div>
                                            {colIssues.map((i) => (
                                                <div key={i.issueId} style={styles.card}>
                                                    <div className="d-flex justify-content-between">
                                                        <strong>Id: {i.issueId}</strong>
                                                        <span className="text-muted">{i.lastUpdated || i.createdOn}</span>
                                                    </div>
                                                    <div className="my-1">{i.summary}</div>
                                                    <div className="d-flex justify-content-between align-items-center">
                                                        <span className="text-muted small">
                                                            {i.assignee ? `Assignee #${i.assignee}` : "Unassigned"}
                                                        </span>
                                                        {i.priority && (
                                                            <span className={`badge bg-${priorityColor(i.priority)}`}>
                                                                {i.priority}
                                                            </span>
                                                        )}
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    );
                                })}
                            </div>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
}

export default ProjectOwnerDashboard;
