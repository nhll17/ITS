import { useContext, useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import {
    getIssueById, updateIssue
} from "../services/IssueService.js";
import { getProjectsByOwner } from "../services/ProjectService";
import { getAllUsers } from "../services/UserService";
import Sidebar from "./Sidebar";

const TYPES = ["TASK", "BUG", "FEATURE"];
const PRIORITIES = ["LOW", "MEDIUM", "HIGH"];
const STATUSES = [
    { value: "OPEN", label: "TO-DO" },
    { value: "IN_PROGRESS", label: "DEVELOPMENT" },
    { value: "RESOLVED", label: "TESTING" },
    { value: "CLOSED", label: "COMPLETED" },
];
const SUMMARY_RE = /^[A-Za-z0-9\s\-/|.]+$/;

const gold = { backgroundColor: "#f0b429", color: "#000", border: "none" };
const styles = {
    header: { background: "#f0b429" },
};

const toForm = (i) => ({
    summary: i.summary || "", type: i.type || "", projectId: i.projectId ?? "",
    priority: i.priority || "", description: i.description || "", assignee: i.assignee ?? "",
    tags: i.tags || "", sprint: i.sprint ?? "", storyPoint: i.storyPoint ?? "", status: i.status || "",
});

function EditIssue() {
    const { user } = useContext(AuthContext);
    const { id } = useParams();
    const navigate = useNavigate();
    const [original, setOriginal] = useState(null);
    const [initialForm, setInitialForm] = useState(null);
    const [form, setForm] = useState(null);
    const [projects, setProjects] = useState([]);
    const [users, setUsers] = useState([]);
    const [serverError, setServerError] = useState("");
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        getIssueById(id).then((i) => {
            setOriginal(i);
            const f = toForm(i);
            setInitialForm(f);
            setForm(f);
        }).catch(() => setServerError("Failed to load issue"));
    }, [id]);

    useEffect(() => {
        if (!user?.userId) return;
        getProjectsByOwner(user.userId).then((d) => setProjects(d || [])).catch(() => setProjects([]));
        getAllUsers().then((d) => setUsers(d || [])).catch(() => setUsers([]));
    }, [user]);

    const errors = useMemo(() => {
        const e = {};
        if (!form) return e;
        const summary = form.summary.trim();
        if (!summary) e.summary = "Summary is required";
        else if (summary.length < 5) e.summary = "Min length is 5 characters";
        else if (summary.length > 100) e.summary = "Max length is 100 characters";
        else if (!SUMMARY_RE.test(summary)) e.summary = "Only letters, numbers and - / | . are allowed";

        if (!form.type) e.type = "Type is required";
        if (!form.projectId) e.projectId = "Project is required";
        if (!form.priority) e.priority = "Priority is required";
        if (!form.status) e.status = "Status is required";
        if (!form.assignee) e.assignee = "Assignee is required";

        const desc = form.description.trim();
        if (!desc) e.description = "Description is required";
        else if (desc.length < 10) e.description = "Min length is 10 characters";
        else if (desc.length > 500) e.description = "Max length is 500 characters";

        if (form.tags && form.tags.length > 100) e.tags = "Max length is 100 characters";

        if (!form.sprint) e.sprint = "Sprint is required";
        else if (!/^[1-9]\d*$/.test(String(form.sprint))) e.sprint = "Sprint must be a positive integer";

        if (!form.storyPoint) e.storyPoint = "Story point is required";
        else if (!/^[1-9]\d*$/.test(String(form.storyPoint))) e.storyPoint = "Must be a positive integer";
        return e;
    }, [form]);

    const isValid = Object.keys(errors).length === 0;
    const onChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });
    const onReset = () => { setForm(initialForm); setServerError(""); };

    const onSubmit = (e) => {
        e.preventDefault();
        if (!isValid) return;
        setSaving(true);
        setServerError("");
        updateIssue(id, {
            issueId: Number(id),
            summary: form.summary.trim(),
            type: form.type,
            projectId: Number(form.projectId),
            priority: form.priority,
            status: form.status,
            description: form.description.trim(),
            assignee: Number(form.assignee),
            tags: form.tags.trim() || null,
            sprint: String(form.sprint),
            storyPoint: Number(form.storyPoint),
            createdBy: original?.createdBy,
            createdOn: original?.createdOn,
        })
            .then(() => navigate(`/issue/${id}`))
            .catch((err) => setServerError(err.response?.data?.message || "Failed to update issue"))
            .finally(() => setSaving(false));
    };

    const err = (k) => errors[k] && <div className="text-danger small mt-1">{errors[k]}</div>;

    if (!form) return <div className="p-4">Loading...</div>;

    return (
        <div className="d-flex">
            <Sidebar dashboardPath="/project-owner-dashboard" />

            <div className="flex-grow-1">
                <div className="d-flex align-items-center justify-content-end px-3 py-2" style={styles.header}>
                    <span className="fw-bold text-white">Deloitte Engineering</span>
                </div>

                <div className="p-4">
                    <h5 className="fw-bold mb-3">Edit Issue</h5>
                    {serverError && <div className="alert alert-danger py-2">{serverError}</div>}

                    <form onSubmit={onSubmit} noValidate>
                        <div className="row g-3">
                            <div className="col-md-6">
                                <label className="form-label small">Summary</label>
                                <input name="summary" className="form-control form-control-sm" maxLength={100}
                                    value={form.summary} onChange={onChange} />
                                {err("summary")}
                            </div>
                            <div className="col-md-6">
                                <label className="form-label small">Type</label>
                                <select name="type" className="form-select form-select-sm"
                                    value={form.type} onChange={onChange}>
                                    <option value="">Select type</option>
                                    {TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                                </select>
                                {err("type")}
                            </div>

                            <div className="col-md-6">
                                <label className="form-label small">Project</label>
                                <select name="projectId" className="form-select form-select-sm"
                                    value={form.projectId} onChange={onChange}>
                                    <option value="">Select project</option>
                                    {projects.map((p) => (
                                        <option key={p.projectId} value={p.projectId}>{p.projectName}</option>
                                    ))}
                                </select>
                                {err("projectId")}
                            </div>
                            <div className="col-md-6">
                                <label className="form-label small">Priority</label>
                                <select name="priority" className="form-select form-select-sm"
                                    value={form.priority} onChange={onChange}>
                                    <option value="">Select priority</option>
                                    {PRIORITIES.map((p) => <option key={p} value={p}>{p}</option>)}
                                </select>
                                {err("priority")}
                            </div>

                            <div className="col-12">
                                <label className="form-label small">Description</label>
                                <textarea name="description" className="form-control form-control-sm"
                                    maxLength={500} rows={2} value={form.description} onChange={onChange} />
                                {err("description")}
                            </div>

                            <div className="col-md-6">
                                <label className="form-label small">Assignee</label>
                                <select name="assignee" className="form-select form-select-sm"
                                    value={form.assignee} onChange={onChange}>
                                    <option value="">Select assignee</option>
                                    {users.map((u) => (
                                        <option key={u.userId} value={u.userId}>{u.name}</option>
                                    ))}
                                </select>
                                {err("assignee")}
                            </div>
                            <div className="col-md-6">
                                <label className="form-label small">Tags</label>
                                <input name="tags" className="form-control form-control-sm" maxLength={100}
                                    value={form.tags} onChange={onChange} />
                                {err("tags")}
                            </div>

                            <div className="col-md-6">
                                <label className="form-label small">Sprint</label>
                                <input name="sprint" className="form-control form-control-sm"
                                    value={form.sprint} onChange={onChange} />
                                {err("sprint")}
                            </div>
                            <div className="col-md-6">
                                <label className="form-label small">Story Point</label>
                                <input name="storyPoint" className="form-control form-control-sm"
                                    value={form.storyPoint} onChange={onChange} />
                                {err("storyPoint")}
                            </div>

                            <div className="col-md-6">
                                <label className="form-label small">Status</label>
                                <select name="status" className="form-select form-select-sm"
                                    value={form.status} onChange={onChange}>
                                    <option value="">Select status</option>
                                    {STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
                                </select>
                                {err("status")}
                            </div>
                        </div>

                        <div className="d-flex justify-content-center gap-2 mt-4">
                            <button type="submit" className="btn btn-sm" style={gold}
                                disabled={!isValid || saving}>
                                {saving ? "SAVING..." : "EDIT"}
                            </button>
                            <button type="button" className="btn btn-sm btn-outline-secondary" onClick={onReset}>
                                RESET
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default EditIssue;
