import {  useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getIssueById } from "../services/IssueService.js";
import { getAllUsers } from "../services/UserService";
import Sidebar from "./Sidebar"; 

const styles = {
    panel: { background: "#f7f7f7", border: "1px solid #e6e6e6", borderRadius: 6, padding: 16, minWidth: 240 },
    row: { marginBottom: 6, fontSize: "0.85rem" },
};

const priorityColor = (p) => (p === "HIGH" ? "danger" : p === "MEDIUM" ? "warning" : "success");



function IssueDetail() {
    const { id } = useParams();
    const navigate = useNavigate();
    const [issue, setIssue] = useState(null);
    const [users, setUsers] = useState([]);
    const [error, setError] = useState("");

    useEffect(() => {
        getIssueById(id).then(setIssue).catch(() => setError("Failed to load issue"));
        getAllUsers().then((d) => setUsers(d || [])).catch(() => setUsers([]));
    }, [id]);

    const nameOf = (uid) => users.find((u) => u.userId === Number(uid))?.name || (uid ? `#${uid}` : "Unassigned");

    return (
        <div className="d-flex">
            <Sidebar dashboardPath="/project-owner-dashboard" />

            <div className="flex-grow-1 p-4">
                {error && <div className="alert alert-danger py-2">{error}</div>}
                {!issue ? (
                    <p>Loading...</p>
                ) : (
                    <>
                        <div className="small mb-2">
                            <span style={{ color: "#f0b429", cursor: "pointer" }}
                                onClick={() => navigate("/project-owner-dashboard")}>Project Board</span>
                            <span className="text-muted"> / Issue Details</span>
                        </div>

                        <div className="d-flex justify-content-between align-items-start">
                            <h5 style={{ color: "#f0b429" }} className="fw-bold">{issue.summary}</h5>
                            <button className="btn btn-sm btn-dark" onClick={() => navigate(`/issue/${id}/edit`)}>
                                Edit Issue
                            </button>
                        </div>

                        <div className="mt-2 mb-3">
                            <div className="fw-semibold small">Description :</div>
                            <div className="small text-muted">{issue.description || "—"}</div>
                        </div>

                        <div className="d-flex gap-4 flex-wrap">
                            <div className="flex-grow-1" style={styles.panel}>
                                <h6 className="fw-bold">Details</h6>
                                <div style={styles.row}><strong>Type:</strong> {issue.type}</div>
                                <div style={styles.row}>
                                    <strong>Tags:</strong>{" "}
                                    {issue.tags ? <span className="badge bg-secondary">{issue.tags}</span> : "—"}
                                </div>
                                <div style={styles.row}><strong>Story Points:</strong> {issue.storyPoint ?? "—"}</div>
                                <div style={styles.row}><strong>Sprint:</strong> {issue.sprint ?? "—"}</div>
                                <div style={styles.row}>
                                    <strong>Priority:</strong>{" "}
                                    {issue.priority && (
                                        <span className={`badge bg-${priorityColor(issue.priority)}`}>
                                            {issue.priority}
                                        </span>
                                    )}
                                </div>
                            </div>

                            <div style={styles.panel}>
                                <div style={styles.row}><strong>Status:</strong> {issue.status}</div>
                                <div style={styles.row}><strong>Assignee:</strong> {nameOf(issue.assignee)}</div>
                                <div style={styles.row}><strong>Created By:</strong> {nameOf(issue.createdBy)}</div>
                                <div style={styles.row}><strong>Created On:</strong> {issue.createdOn || "—"}</div>
                                <div style={styles.row}><strong>Last Updated:</strong> {issue.lastUpdated || "—"}</div>
                            </div>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
}

export default IssueDetail;
