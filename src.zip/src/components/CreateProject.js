import { useContext, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { addProject } from "../services/ProjectService";

const NAME_RE = /^[A-Za-z0-9\s\-/|.]+$/; // letters, digits, space and - / | .
const gold = { backgroundColor: "#f0b429", color: "#000", border: "none" };
const styles = {
    sidebar: { width: 220, minHeight: "100vh", background: "#1e1e1e", color: "#fff" },
    header: { background: "#f0b429" },
    navLink: { color: "#f0b429", cursor: "pointer", padding: "8px 4px", fontSize: "0.9rem" },
};


const EMPTY = { projectName: "", startDate: "", endDate: "" };

function CreateProject() {
    const { user, ctxLogout } = useContext(AuthContext);
    const navigate = useNavigate();
    const [form, setForm] = useState(EMPTY);
    const [serverError, setServerError] = useState("");
    const [saving, setSaving] = useState(false);

    const errors = useMemo(() => {
        const e = {};
        const name = form.projectName.trim();
        if (!name) e.projectName = "Project name is required";
        else if (name.length > 150) e.projectName = "Max length is 150 characters";
        else if (!NAME_RE.test(name))
            e.projectName = "Only letters, numbers and - / | . are allowed";
        if (form.startDate && form.endDate && form.endDate < form.startDate)
            e.endDate = "End date cannot be before start date";
        return e;
    }, [form]);

    const isValid = Object.keys(errors).length === 0;
    const onChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });
    const onReset = () => {
        setForm(EMPTY);
        setServerError("");
    };

    const onSubmit = (e) => {
        e.preventDefault();
        if (!isValid) return;
        setSaving(true);
        setServerError("");
        addProject({
            projectName: form.projectName.trim(),
            projectOwner: user?.userId, // taken from the logged-in owner
            startDate: form.startDate || null,
            endDate: form.endDate || null,
        })
            .then(() => navigate("/project-owner-dashboard"))
            .catch((err) =>
                setServerError(err.response?.data?.message || "Failed to create project")
            )
            .finally(() => setSaving(false));
    };

    const handleLogout = () => {
        ctxLogout();
        navigate("/");
    };

    const links = [
        { label: "Project Dashboard", action: () => navigate("/project-owner-dashboard") },
        { label: "Create Project", action: () => navigate("/create-project") },
        { label: "Create Issue", action: () => navigate("/create-issue") },
    ];

    return (
        <div className="d-flex">
            {/* Sidebar */}
            <div className="d-flex flex-column p-3" style={styles.sidebar}>
                <div className="text-center mb-3">
                    <img
                        src={user?.profile}
                        alt={user?.name}
                        width="70"
                        height="70"
                        className="rounded-circle border border-2 border-warning object-fit-cover"
                    />
                    <div className="fw-bold mt-2">{user?.name}</div>
                    <div className="small text-warning">{user?.email}</div>
                </div>
                <nav className="flex-grow-1">
                    {links.map((l) => (
                        <div key={l.label} style={styles.navLink} onClick={l.action}>
                            ◆ {l.label}
                        </div>
                    ))}
                </nav>
                <button className="btn btn-sm mt-3" style={gold} onClick={handleLogout}>
                    ⎋ Logout
                </button>
            </div>

            {/* Main */}
            <div className="flex-grow-1">
                <div
                    className="d-flex align-items-center justify-content-end px-3 py-2"
                    style={styles.header}
                >
                    <span className="fw-bold text-white">Issue Tracking System</span>
                </div>

                <div className="p-4">
                    <h5 className="fw-bold mb-3">Create Project</h5>
                    {serverError && <div className="alert alert-danger py-2">{serverError}</div>}

                    <form onSubmit={onSubmit} noValidate>
                        <div className="row g-3">
                            <div className="col-md-6">
                                <label className="form-label small">Project Name</label>
                                <input
                                    name="projectName"
                                    className="form-control form-control-sm"
                                    placeholder="Enter project name"
                                    maxLength={150}
                                    value={form.projectName}
                                    onChange={onChange}
                                />
                                {errors.projectName && (
                                    <div className="text-danger small mt-1">{errors.projectName}</div>
                                )}
                            </div>

                            <div className="col-md-6">
                                <label className="form-label small">Project Owner</label>
                                <input
                                    className="form-control form-control-sm"
                                    value={user?.name || ""}
                                    readOnly
                                />
                            </div>

                            <div className="col-md-6">
                                <label className="form-label small">Project Start Date</label>
                                <input
                                    type="date"
                                    name="startDate"
                                    className="form-control form-control-sm"
                                    value={form.startDate}
                                    onChange={onChange}
                                />
                            </div>

                            <div className="col-md-6">
                                <label className="form-label small">Project End Date</label>
                                <input
                                    type="date"
                                    name="endDate"
                                    className="form-control form-control-sm"
                                    min={form.startDate || undefined}
                                    value={form.endDate}
                                    onChange={onChange}
                                />
                                {errors.endDate && (
                                    <div className="text-danger small mt-1">{errors.endDate}</div>
                                )}
                            </div>
                        </div>

                        <div className="d-flex justify-content-center gap-2 mt-4">
                            <button
                                type="submit"
                                className="btn btn-sm"
                                style={gold}
                                disabled={!isValid || saving}
                            >
                                {saving ? "SAVING..." : "CREATE"}
                            </button>
                            <button
                                type="button"
                                className="btn btn-sm btn-outline-secondary"
                                onClick={onReset}
                            >
                                RESET
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default CreateProject;
