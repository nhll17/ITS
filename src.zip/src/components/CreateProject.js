
import { useContext, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { addProject } from "../services/ProjectService";
import Sidebar from "./Sidebar"; // adjust path if Sidebar.js is in another folder

const NAME_RE = /^[A-Za-z0-9\s\-/|.]+$/; // letters, digits, space and - / | .
const gold = { backgroundColor: "#f0b429", color: "#000", border: "none" };
const styles = {
    header: { background: "#f0b429" },
};

function CreateProject() {
    const { user } = useContext(AuthContext);
    const navigate = useNavigate();

    // uncontrolled inputs — refs hold the DOM nodes, no per-keystroke state
    const nameRef = useRef();
    const startRef = useRef();
    const endRef = useRef();

    const [errors, setErrors] = useState({});
    const [serverError, setServerError] = useState("");
    const [saving, setSaving] = useState(false);

    // read the refs and validate only at submit time
    const validate = (name, startDate, endDate) => {
        const e = {};
        if (!name) e.projectName = "Project name is required";
        else if (name.length > 150) e.projectName = "Max length is 150 characters";
        else if (!NAME_RE.test(name))
            e.projectName = "Only letters, numbers and - / | . are allowed";
        if (startDate && endDate && endDate < startDate)
            e.endDate = "End date cannot be before start date";
        return e;
    };

    const onSubmit = (e) => {
        e.preventDefault();

        const name = nameRef.current.value.trim();
        const startDate = startRef.current.value;
        const endDate = endRef.current.value;

        const foundErrors = validate(name, startDate, endDate);
        setErrors(foundErrors);
        if (Object.keys(foundErrors).length > 0) return;

        setSaving(true);
        setServerError("");
        addProject({
            projectName: name,
            projectOwner: user?.userId, // taken from the logged-in owner
            startDate: startDate || null,
            endDate: endDate || null,
        })
            .then(() => navigate("/project-owner-dashboard"))
            .catch((err) =>
                setServerError(err.response?.data?.message || "Failed to create project")
            )
            .finally(() => setSaving(false));
    };

    // native form reset restores defaultValues; just clear our messages
    const onReset = () => {
        setErrors({});
        setServerError("");
    };

    return (
        <div className="d-flex">
            <Sidebar role="owner" activeKey="create-project" />

            {/* Main */}
            <div className="flex-grow-1">
                <div
                    className="d-flex align-items-center justify-content-end px-3 py-2"
                    style={styles.header}
                >
                    <span className="fw-bold text-white">Issue Tracking System</span>
                </div>

                <div className="p-4">
                    <h5 className="fw-bold mb-3">Create Project</h5>
                    {serverError && <div className="alert alert-danger py-2">{serverError}</div>}

                    <form onSubmit={onSubmit} onReset={onReset} noValidate>
                        <div className="row g-3">
                            <div className="col-md-6">
                                <label className="form-label small">Project Name</label>
                                <input
                                    name="projectName"
                                    ref={nameRef}
                                    className="form-control form-control-sm"
                                    placeholder="Enter project name"
                                    maxLength={150}
                                    defaultValue=""
                                />
                                {errors.projectName && (
                                    <div className="text-danger small mt-1">{errors.projectName}</div>
                                )}
                            </div>

                            <div className="col-md-6">
                                <label className="form-label small">Project Owner</label>
                                <input
                                    className="form-control form-control-sm"
                                    value={user?.name || ""}
                                    readOnly
                                />
                            </div>

                            <div className="col-md-6">
                                <label className="form-label small">Project Start Date</label>
                                <input
                                    type="date"
                                    name="startDate"
                                    ref={startRef}
                                    className="form-control form-control-sm"
                                    defaultValue=""
                                />
                            </div>

                            <div className="col-md-6">
                                <label className="form-label small">Project End Date</label>
                                <input
                                    type="date"
                                    name="endDate"
                                    ref={endRef}
                                    className="form-control form-control-sm"
                                    defaultValue=""
                                />
                                {errors.endDate && (
                                    <div className="text-danger small mt-1">{errors.endDate}</div>
                                )}
                            </div>
                        </div>

                        <div className="d-flex justify-content-center gap-2 mt-4">
                            <button type="submit" className="btn btn-sm" style={gold} disabled={saving}>
                                {saving ? "SAVING..." : "CREATE"}
                            </button>
                            <button type="reset" className="btn btn-sm btn-outline-secondary">
                                RESET
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default CreateProject;
