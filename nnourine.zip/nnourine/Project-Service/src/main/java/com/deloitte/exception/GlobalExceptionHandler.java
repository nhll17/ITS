package com.deloitte.exception;
 
import java.time.LocalDateTime;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;

import org.springframework.web.bind.annotation.RestControllerAdvice;
 
import io.swagger.v3.oas.annotations.Hidden;
 
@Hidden

@RestControllerAdvice

public class GlobalExceptionHandler {
 
    @ExceptionHandler(ProjectException.class)

    public ResponseEntity<ErrorResponse> handleProjectException(

    		ProjectException ex) {
 
        ErrorResponse errorResponse =

                new ErrorResponse(

                    LocalDateTime.now(),

                    HttpStatus.NOT_FOUND.value(),

                    "Project Error",

                    ex.getMessage()

                );
 
        return ResponseEntity

                .status(HttpStatus.NOT_FOUND)

                .body(errorResponse);

    }
 
    @ExceptionHandler(IllegalArgumentException.class)

    public ResponseEntity<ErrorResponse> handleIllegalArgumentException(

            IllegalArgumentException ex) {
 
        ErrorResponse errorResponse =

                new ErrorResponse(

                    LocalDateTime.now(),

                    HttpStatus.BAD_REQUEST.value(),

                    "Bad Request",

                    ex.getMessage()

                );
 
        return ResponseEntity

                .status(HttpStatus.BAD_REQUEST)

                .body(errorResponse);

    }
    @ExceptionHandler( MethodArgumentNotValidException.class)
   	public ResponseEntity<ErrorResponse> methodArgument (MethodArgumentNotValidException ex) {
    
   		ErrorResponse errorResponse = new ErrorResponse();
   		String message = ex.getBindingResult()
   				.getAllErrors()
   				.stream()
   				.map(error -> error.getDefaultMessage())
   				.collect((Collectors.joining(", ")));
   		errorResponse.setMessage(message);
   		errorResponse.setStatus(HttpStatus.BAD_REQUEST.value());
   		errorResponse.setTimestamp(LocalDateTime.now());
   		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
   		
   	}
    
    @ExceptionHandler(Exception.class)

    public ResponseEntity<ErrorResponse> handleException(

            Exception ex) {
 
        ErrorResponse errorResponse =

                new ErrorResponse(

                    LocalDateTime.now(),

                    HttpStatus.INTERNAL_SERVER_ERROR.value(),

                    "Internal Server Error",

                    ex.getMessage()

                );
 
        return ResponseEntity

                .status(HttpStatus.INTERNAL_SERVER_ERROR)

                .body(errorResponse);

    }

}

 