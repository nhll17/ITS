package com.deloitte.service;

import java.util.List;

import com.deloitte.dto.IssueDto;
import com.deloitte.entity.Project;

public interface ProjectService {
    Project addProject(Project project);
    List<Project> getAllProjects();
    Project getProjectById(Integer projectId);
    Project updateProject(Integer projectId, Project project);
    void deleteProject(Integer projectId);
    List<Project> getProjectsByOwner(Integer ownerId);
    List<IssueDto> getIssuesByProject(Integer projectId);
    List<IssueDto> getIssuesByProjectName(String projectName);
}

