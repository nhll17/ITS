package com.deloitte.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.client.IssueClient;
import com.deloitte.dto.IssueDto;
import com.deloitte.entity.Project;
import com.deloitte.exception.ProjectException;
import com.deloitte.repository.ProjectRepository;

@Service
public class ProjectServiceImpl implements ProjectService {
	@Autowired
	private ProjectRepository projectRepository;
	@Autowired
	private IssueClient issueClient;

	@Override
	public Project addProject(Project project) {
		if (project.getProjectName() == null || project.getProjectOwner() == null) {
			throw new ProjectException("Project name and project owner are required");
		}
		if (project.getStartDate() != null && project.getEndDate() != null
				&& project.getEndDate().isBefore(project.getStartDate())) {
			throw new ProjectException("End date cannot be before start date");
		}
		return projectRepository.save(project);
	}

	@Override
	public List<Project> getAllProjects() {
		return projectRepository.findAll();
	}

	@Override
	public Project getProjectById(Integer projectId) {
		return projectRepository.findById(projectId)
				.orElseThrow(() -> new ProjectException("Project not found with ID: " + projectId));
	}

	@Override
	public Project updateProject(Integer projectId, Project project) {
		Project existing = getProjectById(projectId);
		existing.setProjectName(project.getProjectName());
		existing.setProjectOwner(project.getProjectOwner());
		existing.setStartDate(project.getStartDate());
		existing.setEndDate(project.getEndDate());
		return projectRepository.save(existing);
	}

	@Override
	public void deleteProject(Integer projectId) {
		Project project = getProjectById(projectId);
		projectRepository.delete(project);
	}

	@Override
	public List<Project> getProjectsByOwner(Integer ownerId) {
		return projectRepository.findByProjectOwner(ownerId);
	}

	@Override
	public List<IssueDto> getIssuesByProject(Integer projectId) {
		// First verify project exists
		getProjectById(projectId);
		return issueClient.getIssuesByProject(projectId);
	}

	@Override
	public List<IssueDto> getIssuesByProjectName(String projectName) {
		Project project = projectRepository.findByProjectName(projectName)
				.orElseThrow(() -> new ProjectException("Project not found with name: " + projectName));
		return issueClient.getIssuesByProject(project.getProjectId());
	}

}
