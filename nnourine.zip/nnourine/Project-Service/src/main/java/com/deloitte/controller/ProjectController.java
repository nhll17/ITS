package com.deloitte.controller;
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
import com.deloitte.dto.IssueDto;
import com.deloitte.entity.Project;
import com.deloitte.service.ProjectService;
 
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
 
@RestController
@RequestMapping("/api/projects")
@Tag(
    name = "Project Management",
    description = "APIs for managing projects"
)
public class ProjectController {
    @Autowired
    private ProjectService projectService;
    @PostMapping
    @Operation(
        summary = "Create a project",
        description = "Creates a new project"
    )
    public ResponseEntity<Project> addProject(
            @RequestBody Project project) {
        Project savedProject =
                projectService.addProject(project);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(savedProject);
    }
    @GetMapping
    @Operation(
        summary = "Get all projects",
        description = "Retrieves all projects"
    )
    public ResponseEntity<List<Project>> getAllProjects() {
        return ResponseEntity.ok(
            projectService.getAllProjects()
        );
    }
    @GetMapping("/{projectId}")
    @Operation(
        summary = "Get project by ID",
        description = "Retrieves a project using project ID"
    )
    public ResponseEntity<Project> getProjectById(
            @PathVariable Integer projectId) {
        return ResponseEntity.ok(
            projectService.getProjectById(projectId)
        );
    }
    @PutMapping("/{projectId}")
    @Operation(
        summary = "Update project",
        description = "Updates an existing project"
    )
    public ResponseEntity<Project> updateProject(
            @PathVariable Integer projectId,
            @RequestBody Project project) {
        return ResponseEntity.ok(
            projectService.updateProject(
                projectId,
                project
            )
        );
    }
    @DeleteMapping("/{projectId}")
    @Operation(
        summary = "Delete project",
        description = "Deletes a project"
    )
    public ResponseEntity<String> deleteProject(
            @PathVariable Integer projectId) {
        projectService.deleteProject(projectId);
        return ResponseEntity.ok(
            "Project deleted successfully"
        );
    }
    @GetMapping("/owner/{ownerId}")
    @Operation(
        summary = "Get projects by owner",
        description = "Retrieves projects belonging to an owner"
    )
    public ResponseEntity<List<Project>>
        getProjectsByOwner(
            @PathVariable Integer ownerId) {
        return ResponseEntity.ok(
            projectService.getProjectsByOwner(ownerId)
        );
    }
    @GetMapping("/{projectId}/issues")
    @Operation(
        summary = "Get issues by project",
        description = "Retrieves issues belonging to a project"
    )
    public ResponseEntity<List<IssueDto>> getIssuesByProject(
            @PathVariable Integer projectId) {
 
        return ResponseEntity.ok(
            projectService.getIssuesByProject(projectId)
        );
    }
 
    @GetMapping("/projectName/{projectName}/issues")
    @Operation(
        summary = "Get issues by project name",
        description = "Retrieves issues belonging to a project using project name"
    )
    public ResponseEntity<List<IssueDto>>
        getIssuesByProjectName(
            @PathVariable String projectName) {
 
        return ResponseEntity.ok(
            projectService.getIssuesByProjectName(projectName)
        );
    }
}