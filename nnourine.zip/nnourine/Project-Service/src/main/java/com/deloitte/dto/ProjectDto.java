package com.deloitte.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
public class ProjectDto {
	@NotBlank(message = "Project name is required")
	@Size(max = 150, message = "Project name cannot exceed 150 characters")
	private String projectName;
	
    @NotNull(message = "Project owner is required")
    @Positive(message = "Project owner must be greater than zero")
	private Integer projectOwner;
 
	private LocalDate startDate;
	private LocalDate endDate;
 
	public ProjectDto() {
		super();
		// TODO Auto-generated constructor stub
	}
 
	public ProjectDto(String projectName, Integer projectOwner, LocalDate startDate, LocalDate endDate) {
		super();
		this.projectName = projectName;
		this.projectOwner = projectOwner;
		this.startDate = startDate;
		this.endDate = endDate;
	}
 
	public String getProjectName() {
		return projectName;
	}
 
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
 
	public Integer getProjectOwner() {
		return projectOwner;
	}
 
	public void setProjectOwner(Integer projectOwner) {
		this.projectOwner = projectOwner;
	}
 
	public LocalDate getStartDate() {
		return startDate;
	}
 
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
 
	public LocalDate getEndDate() {
		return endDate;
	}
 
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	
    @AssertTrue(message = "End date cannot be before start date")
    public boolean isDateRangeValid() {
 
        if (startDate == null || endDate == null) {
            return true;
        }
 
        return !endDate.isBefore(startDate);
    }
 
}