package com.deloitte.service;

import java.util.List;

import com.deloitte.dto.IssueDto;
import com.deloitte.dto.UserDto;
import com.deloitte.entity.User;

public interface UserService {
    User addUser(UserDto userDto);
    List<User> getAllUsers();
    User getUserById(Integer userId);
    User login(String email, String password);
    List<IssueDto> getIssuesByUserId(Integer userId);
    List<IssueDto> getIssuesByUsername(String username);
}

