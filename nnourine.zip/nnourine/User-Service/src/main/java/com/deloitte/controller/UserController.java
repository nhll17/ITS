package com.deloitte.controller;
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
 
import com.deloitte.dto.IssueDto;
import com.deloitte.dto.UserDto;
import com.deloitte.entity.User;
import com.deloitte.service.UserService;
 
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
 
@RestController
@RequestMapping("/api/users")
@Tag(
    name = "User Management",
    description = "APIs for managing users"
)
public class UserController {
    @Autowired
    private UserService userService;
 
    @PostMapping
    @Operation(
        summary = "Add user",
        description = "Creates a new user"
    )
    public ResponseEntity<User> addUser( @Valid @RequestBody UserDto userDTO) {
 
        User savedUser = userService.addUser(userDTO);
 
        return ResponseEntity.status(HttpStatus.CREATED).body(savedUser);
    }
 
    @GetMapping
    @Operation(
        summary = "Get all users",
        description = "Retrieves all users"
    )
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(
            userService.getAllUsers()
        );
    }
 
    @GetMapping("/{userId}")
    @Operation(
        summary = "Get user by ID",
        description = "Retrieves a user using user ID"
    )
    public ResponseEntity<User> getUserById(
            @PathVariable Integer userId) {
        return ResponseEntity.ok(
            userService.getUserById(userId)
        );
    }
 
    @PostMapping("/login")
    @Operation(
        summary = "User login",
        description = "Authenticates a user using email and password"
    )
    public ResponseEntity<User> login(
            @RequestParam String email,
            @RequestParam String password) {
        return ResponseEntity.ok(
            userService.login(email, password)
        );
    }
 
    @GetMapping("/{userId}/issues")
    @Operation(
        summary = "Get issues by user ID",
        description = "Retrieves issues assigned to a user using user ID"
    )
    public ResponseEntity<List<IssueDto>> getIssuesByUserId(
            @PathVariable Integer userId) {
 
        return ResponseEntity.ok(
            userService.getIssuesByUserId(userId)
        );
    }
 
    @GetMapping("/username/{username}/issues")
    @Operation(
        summary = "Get issues by username",
        description = "Retrieves issues assigned to a user using username"
    )
    public ResponseEntity<List<IssueDto>> getIssuesByUsername(
            @PathVariable String username) {
 
        return ResponseEntity.ok(
            userService.getIssuesByUsername(username)
        );
    }
 
}
 