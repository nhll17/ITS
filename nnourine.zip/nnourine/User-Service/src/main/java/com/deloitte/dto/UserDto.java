package com.deloitte.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class UserDto {
	    private Integer userId;
	    @NotBlank(message = "Name is required")
	    @Size(min = 2, max = 50, message = "Name must be between 2 and 50 characters")
	    private String name;
	    @NotBlank(message = "Email is required")
	    @Email(message = "Please provide a valid email address")
	    private String email;
	    @NotBlank(message = "Password is required")
	    @Size(min = 8, max = 100, message = "Password must be between 8 and 100 characters")
	    private String password;
	  
	    @NotNull(message = "Role is required")
	    private Integer role;
	    @Size(max = 255, message = "Profile cannot exceed 255 characters")
	    private String profile;
		public Integer getUserId() {
			return userId;
		}
		public void setUserId(Integer userId) {
			this.userId = userId;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public Integer getRole() {
			return role;
		}
		public void setRole(Integer role) {
			this.role = role;
		}
		public String getProfile() {
			return profile;
		}
		public void setProfile(String profile) {
			this.profile = profile;
		}


    
    
}