package com.deloitte.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.deloitte.client.IssueClient;
import com.deloitte.dto.IssueDto;
import com.deloitte.dto.UserDto;
import com.deloitte.entity.User;
import com.deloitte.exception.UserException;
import com.deloitte.repository.UserRepository;
@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
	private RestTemplate restTemplate;

@Autowired
private IssueClient issueClient;

    
@Override
public User addUser(UserDto userDto) {
	try {
		
		if (userDto.getName() == null || userDto.getEmail() == null || userDto.getPassword() == null) {

			throw new UserException("Name, email and password are required");
		}

		if (userRepository.findByEmail(userDto.getEmail()).isPresent()) {

			throw new UserException("User with this email already exists");
		}
		
	} catch (Exception e) {
		throw e; //rethrowing an exception
	}

	User user = new User();
	user.setName(userDto.getName());
    user.setEmail(userDto.getEmail());
    user.setPassword(userDto.getPassword());
    user.setProfile(userDto.getProfile());
    user.setRole(userDto.getRole());


	return userRepository.save(user);
}
    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
    @Override
    public User getUserById(Integer userId) {
        return userRepository.findById(userId)
                .orElseThrow(() ->
                    new UserException(
                        "User not found with ID: " + userId
                    )
                );
    }
    @Override
    public User login(String email, String password) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() ->
                    new UserException(
                        "Invalid email or password"
                    )
                );
        if (!user.getPassword().equals(password)) {
            throw new UserException(
                "Invalid email or password"
            );
        }
        return user;
    }

@Override
public List<IssueDto> getIssuesByUserId(Integer userId) {
    String url =
        "http://localhost:8081/api/issues/assignee/"
        + userId;
    IssueDto[] issues =
        restTemplate.getForObject(
            url,
            IssueDto[].class
        );
    return Arrays.asList(issues);
}
@Override
public List<IssueDto> getIssuesByUsername(String username) {
    User user = userRepository.findByName(username)
            .orElseThrow(() ->
                new UserException(
                    "User not found with name: " + username
                )
            );
    return issueClient.getIssuesByAssignee(
        user.getUserId()
    );
}


}
