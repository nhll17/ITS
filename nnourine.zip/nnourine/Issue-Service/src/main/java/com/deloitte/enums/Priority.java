package com.deloitte.enums;

	public enum Priority {
	    LOW,
	    MEDIUM,
	    HIGH,
	    CRITICAL
	}


