package com.deloitte.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.deloitte.dto.IssueDto;
import com.deloitte.entity.Issue;

public interface IssueService {
    Issue addIssue(IssueDto issueDto);
    List<Issue> getAllIssues();
    Issue getIssueById(Integer id);
    Issue updateIssue(Integer id, IssueDto issueDto);
    List<Issue> getIssuesByProject(Integer projectId);
    List<Issue> getIssuesByAssignee(Integer assignee);
}

