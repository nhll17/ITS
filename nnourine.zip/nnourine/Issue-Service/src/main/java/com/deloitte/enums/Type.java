package com.deloitte.enums;
public enum Type {
    BUG,
    FEATURE,
    TASK
}
