package com.deloitte.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.dto.IssueDto;
import com.deloitte.entity.Issue;
import com.deloitte.exception.IssueException;
import com.deloitte.repository.IssueRepository;

@Service
public class IssueServiceImpl implements IssueService {

    @Autowired
    private IssueRepository issueRepository;

    @Override
    public Issue addIssue(IssueDto issueDto) {
        Issue issue = new Issue();
        issue.setProjectId(issueDto.getProjectId());
        issue.setAssignee(issueDto.getAssignee());
        issue.setSummary(issueDto.getSummary());
        issue.setDescription(issueDto.getDescription());
        issue.setPriority(issueDto.getPriority());
        issue.setStatus(issueDto.getStatus());
        issue.setCreatedBy(issueDto.getCreatedBy());
        issue.setSprint(issueDto.getSprint());
        issue.setStoryPoint(issueDto.getStoryPoint());
        issue.setTags(issueDto.getTags());
        issue.setType(issueDto.getType());
        issue.setCreatedOn(LocalDate.now());
        issue.setLastUpdated(LocalDate.now());
        return issueRepository.save(issue);
    }

    @Override
    public List<Issue> getAllIssues() {
        return issueRepository.findAll();
    }

    @Override
    public Issue getIssueById(Integer id) {
        return issueRepository.findById(id)
                .orElseThrow(() ->
                    new IssueException("Issue not found with ID: " + id)
                );
    }

    @Override
    public Issue updateIssue(Integer id, IssueDto issueDto) {
        Issue existing = getIssueById(id);
        existing.setProjectId(issueDto.getProjectId());
        existing.setAssignee(issueDto.getAssignee());
        existing.setDescription(issueDto.getDescription());
        existing.setSummary(issueDto.getSummary());
        existing.setPriority(issueDto.getPriority());
        existing.setStatus(issueDto.getStatus());
        existing.setCreatedBy(issueDto.getCreatedBy());
        existing.setSprint(issueDto.getSprint());
        existing.setStoryPoint(issueDto.getStoryPoint());
        existing.setTags(issueDto.getTags());
        existing.setType(issueDto.getType());
        existing.setLastUpdated(LocalDate.now());
        return issueRepository.save(existing);
    }

    @Override
    public List<Issue> getIssuesByProject(Integer projectId) {
        return issueRepository.findByProjectId(projectId);
    }

    @Override
    public List<Issue> getIssuesByAssignee(Integer assignee) {
        return issueRepository.findByAssignee(assignee);
    }
}