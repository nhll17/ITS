package com.deloitte.enums;

public enum Status {
    OPEN,
    IN_PROGRESS,
    RESOLVED,
    CLOSED
}
