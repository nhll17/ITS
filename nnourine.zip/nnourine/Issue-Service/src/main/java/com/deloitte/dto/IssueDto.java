package com.deloitte.dto;

import java.time.LocalDate;

import com.deloitte.enums.Priority;
import com.deloitte.enums.Status;
import com.deloitte.enums.Type;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

public class IssueDto {

 private Integer issueId;

 @NotNull(message = "Project ID is required")
 @Positive(message = "Project ID must be greater than zero")
 private Integer projectId;

 @Positive(message = "Assignee must be greater than zero")
 private Integer assignee;

 private LocalDate createdOn;

 private LocalDate lastUpdated;

 @Size(max = 2000, message = "Description cannot exceed 2000 characters")
 private String description;

 @NotBlank(message = "Issue summary is required")
 @Size(max = 200, message = "Issue summary cannot exceed 200 characters")
 private String summary;

 @NotNull(message = "Priority is required")
 private Priority priority;

 @NotNull(message = "Status is required")
 private Status status;

 @Positive(message = "Created by must be greater than zero")
 private Integer createdBy;

 @Size(max = 100, message = "Sprint cannot exceed 100 characters")
 private String sprint;

 @Positive(message = "Story point must be greater than zero")
 private Integer storyPoint;

 @Size(max = 500, message = "Tags cannot exceed 500 characters")
 private String tags;

 @NotNull(message = "Issue type is required")
 private Type type;

 public IssueDto() {
 }

 public Integer getIssueId() {
     return issueId;
 }

 public void setIssueId(Integer issueId) {
     this.issueId = issueId;
 }

 public Integer getProjectId() {
     return projectId;
 }

 public void setProjectId(Integer projectId) {
     this.projectId = projectId;
 }

 public Integer getAssignee() {
     return assignee;
 }

 public void setAssignee(Integer assignee) {
     this.assignee = assignee;
 }

 public LocalDate getCreatedOn() {
     return createdOn;
 }

 public void setCreatedOn(LocalDate createdOn) {
     this.createdOn = createdOn;
 }

 public LocalDate getLastUpdated() {
     return lastUpdated;
 }

 public void setLastUpdated(LocalDate lastUpdated) {
     this.lastUpdated = lastUpdated;
 }

 public String getDescription() {
     return description;
 }

 public void setDescription(String description) {
     this.description = description;
 }

 public String getSummary() {
     return summary;
 }

 public void setSummary(String summary) {
     this.summary = summary;
 }

 public Priority getPriority() {
     return priority;
 }

 public void setPriority(Priority priority) {
     this.priority = priority;
 }

 public Status getStatus() {
     return status;
 }

 public void setStatus(Status status) {
     this.status = status;
 }

 public Integer getCreatedBy() {
     return createdBy;
 }

 public void setCreatedBy(Integer createdBy) {
     this.createdBy = createdBy;
 }

 public String getSprint() {
     return sprint;
 }

 public void setSprint(String sprint) {
     this.sprint = sprint;
 }

 public Integer getStoryPoint() {
     return storyPoint;
 }

 public void setStoryPoint(Integer storyPoint) {
     this.storyPoint = storyPoint;
 }

 public String getTags() {
     return tags;
 }

 public void setTags(String tags) {
     this.tags = tags;
 }

 public Type getType() {
     return type;
 }

 public void setType(Type type) {
     this.type = type;
 }
}

