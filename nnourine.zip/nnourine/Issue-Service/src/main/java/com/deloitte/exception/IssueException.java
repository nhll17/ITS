package com.deloitte.exception;
public class IssueException extends RuntimeException {
    public IssueException(String message) {
        super(message);
    }
}

