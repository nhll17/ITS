
package com.deloitte.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deloitte.dto.IssueDto;
import com.deloitte.entity.Issue;
import com.deloitte.service.IssueService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/issues")
@Tag(
    name = "Issue Management",
    description = "APIs for managing issues"
)
public class IssueController {

    @Autowired
    private IssueService issueService;

    @PostMapping
    @Operation(
        summary = "Create an issue",
        description = "Creates a new issue"
    )
    public ResponseEntity<Issue> addIssue(
            @Valid @RequestBody IssueDto issueDto) {
        Issue savedIssue = issueService.addIssue(issueDto);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(savedIssue);
    }

    @GetMapping
    @Operation(
        summary = "Get all issues",
        description = "Retrieves all issues"
    )
    public ResponseEntity<List<Issue>> getAllIssues() {
        return ResponseEntity.ok(issueService.getAllIssues());
    }

    @GetMapping("/{id}")
    @Operation(
        summary = "Get issue by ID",
        description = "Retrieves an issue using issue ID"
    )
    public ResponseEntity<Issue> getIssueById(
            @PathVariable Integer id) {
        return ResponseEntity.ok(issueService.getIssueById(id));
    }

    @PutMapping("/{id}")
    @Operation(
        summary = "Update issue",
        description = "Updates an existing issue"
    )
    public ResponseEntity<Issue> updateIssue(
            @PathVariable Integer id,
            @Valid @RequestBody IssueDto issueDto) {
        return ResponseEntity.ok(issueService.updateIssue(id, issueDto));
    }

    @GetMapping("/project/{projectId}")
    @Operation(
        summary = "Get issues by project",
        description = "Retrieves issues belonging to a project"
    )
    public ResponseEntity<List<Issue>> getIssuesByProject(
            @PathVariable Integer projectId) {
        return ResponseEntity.ok(issueService.getIssuesByProject(projectId));
    }

    @GetMapping("/assignee/{assignee}")
    @Operation(
        summary = "Get issues by assignee",
        description = "Retrieves issues assigned to a specific assignee"
    )
    public ResponseEntity<List<Issue>> getIssuesByAssignee(
            @PathVariable Integer assignee) {
        return ResponseEntity.ok(issueService.getIssuesByAssignee(assignee));
    }
}
