# Issue Tracking System — React + Bootstrap Frontend

Frontend implementation for the Stark Industries Issue Tracking System case study, integrated with the supplied Spring Boot microservices through the API Gateway.

## Stack

- React + TypeScript
- Vite
- React Bootstrap + Bootstrap Icons
- React Router
- Fetch API
- Vite development proxy to `http://localhost:8085`

## Backend mapping

The supplied backend exposes these gateway routes:

- User Service: `/api/users/**` → port `8083`
- Project Service: `/api/projects/**` → port `8082`
- Issue Service: `/api/issues/**` → port `8081`
- API Gateway: port `8085`

The frontend calls the gateway using relative `/api/...` paths.

## Role assumption

The backend stores `role` as an integer and does not expose a role enum. This frontend assumes:

- `1` = Project Owner
- `2` = Assignee

If your database uses different role IDs, change `ROLE_IDS` in `src/types/constants.ts`.

## Status / type mapping

The case study uses business labels while the supplied backend uses Java enum names:

- `OPEN` → To-Do
- `IN_PROGRESS` → Development
- `RESOLVED` → Testing
- `CLOSED` → Completed
- `FEATURE` → Story
- `BUG` → Bug
- `TASK` → Task

The API receives the backend enum values.

## Run

1. Start MySQL and the supplied backend services.
2. Start Eureka if your service-to-service configuration requires it.
3. Start the API Gateway on port `8085`.
4. From this folder:

```bash
npm install
npm run dev
```

5. Open `http://localhost:5173`.

## Important backend integration note

The supplied backend currently has no JWT/session token mechanism and stores passwords directly. The frontend therefore provides route protection and stores only the authenticated user profile in local storage; it does **not** claim to provide backend-level authentication security.

For production security, add password hashing and token-based authentication (for example, Spring Security + JWT) to the backend.

## Case-study coverage

- Login with email, password and role validation
- Signup with name, email, password, profile URL and role validation
- Project Owner dashboard with project tabs, issue search and Kanban status columns
- No-project state
- Create Project with reset and date-range validation
- Create Issue with required field validation, dropdowns, positive story points and sprint
- Project Owner issue detail/edit screen
- Assignee dashboard with Regex search
- Assignee issue detail with status-only update and disabled Save button until status changes
- Backend API integration through the gateway
