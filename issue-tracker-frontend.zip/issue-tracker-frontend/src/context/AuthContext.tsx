import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { userApi } from "../services/api";
import { ROLE_IDS } from "../types/constants";
import type { Role, User } from "../types/models";

interface AuthContextValue {
  user: User | null;
  role: Role | null;
  login: (email: string, password: string, role: Role) => Promise<void>;
  signup: (payload: Omit<User, "userId">) => Promise<User>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);
const STORAGE_KEY = "issue-tracker-user";

const roleFromBackend = (roleId: number): Role | null => {
  if (roleId === ROLE_IDS.OWNER) return "OWNER";
  if (roleId === ROLE_IDS.ASSIGNEE) return "ASSIGNEE";
  return null;
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? (JSON.parse(stored) as User) : null;
  });

  const role = user ? roleFromBackend(user.role) : null;

  useEffect(() => {
    if (user) {
      const safeUser = { ...user };
      delete safeUser.password;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(safeUser));
    } else {
      localStorage.removeItem(STORAGE_KEY);
    }
  }, [user]);

  const value = useMemo<AuthContextValue>(() => ({
    user,
    role,
    login: async (email, password, selectedRole) => {
      const loggedIn = await userApi.login(email, password);
      const actualRole = roleFromBackend(loggedIn.role);
      if (actualRole !== selectedRole) {
        throw new Error(`This account is registered as ${actualRole === "OWNER" ? "Project Owner" : "Assignee"}.`);
      }
      setUser(loggedIn);
    },
    signup: async (payload) => {
      const created = await userApi.signup(payload);
      return created;
    },
    logout: () => setUser(null)
  }), [role, user]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = (): AuthContextValue => {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside AuthProvider");
  return context;
};
