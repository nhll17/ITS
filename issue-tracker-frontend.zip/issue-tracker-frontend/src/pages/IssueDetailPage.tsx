import { useEffect, useMemo, useState } from "react";
import { Alert, Badge, Button, Card, Col, Form, Row } from "react-bootstrap";
import { Link, useParams } from "react-router-dom";
import { AppLayout } from "../layouts/AppLayout";
import { ErrorAlert } from "../components/ErrorAlert";
import { Loading } from "../components/Loading";
import { issueApi, projectApi, userApi } from "../services/api";
import { PRIORITY_OPTIONS, ROLE_IDS, STATUS_OPTIONS, TYPE_OPTIONS, priorityLabel, statusLabel, typeLabel } from "../types/constants";
import { useAuth } from "../context/AuthContext";
import type { Issue, IssueFormValues, Project, User } from "../types/models";

const toForm = (issue: Issue): IssueFormValues => ({
  projectId: issue.projectId,
  assignee: issue.assignee ?? "",
  summary: issue.summary,
  description: issue.description ?? "",
  priority: issue.priority,
  status: issue.status,
  createdBy: issue.createdBy ?? 0,
  sprint: issue.sprint ?? "",
  storyPoint: issue.storyPoint ?? "",
  tags: issue.tags ?? "",
  type: issue.type
});

export function IssueDetailPage() {
  const { id } = useParams();
  const issueId = Number(id);
  const { user, role } = useAuth();
  const [issue, setIssue] = useState<Issue | null>(null);
  const [form, setForm] = useState<IssueFormValues | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!user || !Number.isInteger(issueId) || issueId <= 0) {
      setError("Invalid issue ID.");
      setLoading(false);
      return;
    }

    const load = async () => {
      try {
        const loadedIssue = await issueApi.getById(issueId);
        const allUsers = await userApi.getAll();
        setIssue(loadedIssue);
        setForm(toForm(loadedIssue));
        setUsers(allUsers);

        if (role === "OWNER") {
          const ownerProjects = await projectApi.getByOwner(user.userId);
          setProjects(ownerProjects);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : "Unable to load issue.");
      } finally {
        setLoading(false);
      }
    };
    void load();
  }, [issueId, role, user]);

  const assignee = useMemo(
    () => users.find((candidate) => candidate.userId === issue?.assignee),
    [issue?.assignee, users]
  );
  const creator = useMemo(
    () => users.find((candidate) => candidate.userId === issue?.createdBy),
    [issue?.createdBy, users]
  );

  if (!user) return null;

  const update = <K extends keyof IssueFormValues>(key: K, value: IssueFormValues[K]) =>
    setForm((current) => current ? { ...current, [key]: value } : current);

  const ownerValid = form
    ? form.summary.trim().length >= 5 &&
      form.summary.length <= 100 &&
      form.projectId > 0 &&
      form.type !== "" &&
      form.priority !== "" &&
      typeof form.assignee === "number" &&
      form.assignee > 0 &&
      form.sprint.trim().length > 0 &&
      Number(form.sprint) > 0 &&
      form.status !== "" &&
      form.description.trim().length >= 10 &&
      form.description.length <= 500 &&
      typeof form.storyPoint === "number" &&
      form.storyPoint > 0
    : false;

  const assigneeChanged = role === "ASSIGNEE" && issue && form && form.status !== issue.status;
  const saveDisabled = role === "OWNER" ? !ownerValid : !assigneeChanged;

  const save = async () => {
    if (!form || saveDisabled) return;
    setSaving(true);
    setError("");
    try {
      const updated = await issueApi.update(issueId, form);
      setIssue(updated);
      setForm(toForm(updated));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to save changes.");
    } finally {
      setSaving(false);
    }
  };

  const layoutRole = role ?? "OWNER";

  return (
    <AppLayout role={layoutRole}>
      {loading ? <Loading text="Loading issue details..." /> : error && !issue ? (
        <ErrorAlert message={error} />
      ) : issue && form ? (
        <>
          {error && <Alert variant="danger">{error}</Alert>}
          <div className="mb-4">
            <Link to={role === "OWNER" ? "/owner" : "/assignee"} className="text-decoration-none small">
              <i className="bi bi-arrow-left me-2" />Back to dashboard
            </Link>
          </div>

          <Card className="card-panel border-0">
            <Card.Body className="p-4 p-lg-5">
              <div className="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4">
                <div>
                  <div className="eyebrow">ISSUE #{issue.issueId}</div>
                  <h1 className="issue-detail-title">{issue.summary}</h1>
                  <div className="d-flex gap-2 flex-wrap">
                    <Badge bg="light" text="dark">{typeLabel(issue.type)}</Badge>
                    <Badge bg="light" text="dark">{priorityLabel(issue.priority)}</Badge>
                    <Badge bg="light" text="dark">{statusLabel(issue.status)}</Badge>
                  </div>
                </div>
                <div className="text-md-end small text-secondary">
                  <div>Created: {issue.createdOn ?? "—"}</div>
                  <div>Updated: {issue.lastUpdated ?? "—"}</div>
                </div>
              </div>

              {role === "ASSIGNEE" ? (
                <AssigneeIssueView
                  issue={issue}
                  form={form}
                  assignee={assignee}
                  onStatusChange={(value) => update("status", value)}
                  onSave={save}
                  saving={saving}
                  saveDisabled={Boolean(saveDisabled)}
                />
              ) : (
                <OwnerIssueEdit
                  issue={issue}
                  form={form}
                  projects={projects}
                  users={users}
                  creator={creator}
                  onChange={update}
                  onSave={save}
                  onReset={() => setForm(toForm(issue))}
                  saving={saving}
                  saveDisabled={Boolean(saveDisabled)}
                />
              )}
            </Card.Body>
          </Card>
        </>
      ) : null}
    </AppLayout>
  );
}

interface AssigneeProps {
  issue: Issue;
  form: IssueFormValues;
  assignee?: User;
  onStatusChange: (value: IssueFormValues["status"]) => void;
  onSave: () => Promise<void>;
  saving: boolean;
  saveDisabled: boolean;
}

function AssigneeIssueView({ issue, form, assignee, onStatusChange, onSave, saving, saveDisabled }: AssigneeProps) {
  return (
    <Row className="g-4">
      <Col lg={8}>
        <div className="detail-section">
          <h5>Description</h5>
          <p>{issue.description || "No description provided."}</p>
        </div>
        <Row className="g-3 mt-1">
          <Detail label="Project ID" value={String(issue.projectId)} />
          <Detail label="Type" value={typeLabel(issue.type)} />
          <Detail label="Priority" value={priorityLabel(issue.priority)} />
          <Detail label="Sprint" value={issue.sprint || "—"} />
          <Detail label="Story Point" value={String(issue.storyPoint ?? "—")} />
          <Detail label="Tags" value={issue.tags || "—"} />
        </Row>
      </Col>
      <Col lg={4}>
        <div className="detail-panel">
          <div className="detail-avatar avatar avatar-lg mb-3">
            {assignee?.profile ? <img src={assignee.profile} alt={assignee.name} /> : assignee?.name.charAt(0).toUpperCase()}
          </div>
          <h5>{assignee?.name ?? "Assignee"}</h5>
          <div className="text-secondary small mb-4">{assignee?.email ?? "—"}</div>
          <Form.Group>
            <Form.Label>Status</Form.Label>
            <Form.Select value={form.status} onChange={(e) => onStatusChange(e.target.value as IssueFormValues["status"])}>
              {STATUS_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
            </Form.Select>
          </Form.Group>
          <Button className="btn-gold w-100 mt-3" disabled={saving || saveDisabled} onClick={() => void onSave()}>
            {saving ? "Saving..." : "Save Updates"}
          </Button>
        </div>
      </Col>
    </Row>
  );
}

interface OwnerProps {
  issue: Issue;
  form: IssueFormValues;
  projects: Project[];
  users: User[];
  creator?: User;
  onChange: <K extends keyof IssueFormValues>(key: K, value: IssueFormValues[K]) => void;
  onSave: () => Promise<void>;
  onReset: () => void;
  saving: boolean;
  saveDisabled: boolean;
}

function OwnerIssueEdit({ issue, form, projects, users, creator, onChange, onSave, onReset, saving, saveDisabled }: OwnerProps) {
  return (
    <Form noValidate>
      <Row className="g-4">
        <Col md={8}>
          <Form.Group>
            <Form.Label>Summary *</Form.Label>
            <Form.Control value={form.summary} maxLength={100} onChange={(e) => onChange("summary", e.target.value)} />
          </Form.Group>
        </Col>
        <Col md={4}>
          <Form.Group>
            <Form.Label>Project *</Form.Label>
            <Form.Select value={form.projectId} onChange={(e) => onChange("projectId", Number(e.target.value))}>
              {projects.map((project) => <option key={project.projectId} value={project.projectId}>{project.projectName}</option>)}
            </Form.Select>
          </Form.Group>
        </Col>
        <Col md={12}>
          <Form.Group>
            <Form.Label>Description *</Form.Label>
            <Form.Control as="textarea" rows={5} maxLength={500} value={form.description} onChange={(e) => onChange("description", e.target.value)} />
          </Form.Group>
        </Col>
        <Col md={4}>
          <Form.Group>
            <Form.Label>Type *</Form.Label>
            <Form.Select value={form.type} onChange={(e) => onChange("type", e.target.value as IssueFormValues["type"])}>
              {TYPE_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
            </Form.Select>
          </Form.Group>
        </Col>
        <Col md={4}>
          <Form.Group>
            <Form.Label>Priority *</Form.Label>
            <Form.Select value={form.priority} onChange={(e) => onChange("priority", e.target.value as IssueFormValues["priority"])}>
              {PRIORITY_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
            </Form.Select>
          </Form.Group>
        </Col>
        <Col md={4}>
          <Form.Group>
            <Form.Label>Status *</Form.Label>
            <Form.Select value={form.status} onChange={(e) => onChange("status", e.target.value as IssueFormValues["status"])}>
              {STATUS_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
            </Form.Select>
          </Form.Group>
        </Col>
        <Col md={6}>
          <Form.Group>
            <Form.Label>Assignee *</Form.Label>
            <Form.Select value={form.assignee} onChange={(e) => onChange("assignee", Number(e.target.value))}>
              <option value="">Select assignee</option>
              {users.filter((candidate) => candidate.role === ROLE_IDS.ASSIGNEE).map((candidate) => <option key={candidate.userId} value={candidate.userId}>{candidate.name}</option>)}
            </Form.Select>
          </Form.Group>
        </Col>
        <Col md={3}>
          <Form.Group>
            <Form.Label>Sprint *</Form.Label>
            <Form.Control value={form.sprint} inputMode="numeric" onChange={(e) => onChange("sprint", e.target.value.replace(/\D/g, ""))} />
          </Form.Group>
        </Col>
        <Col md={3}>
          <Form.Group>
            <Form.Label>Story Point *</Form.Label>
            <Form.Control type="number" min={1} value={form.storyPoint} onChange={(e) => onChange("storyPoint", e.target.value ? Number(e.target.value) : "")} />
          </Form.Group>
        </Col>
        <Col md={12}>
          <Form.Group>
            <Form.Label>Tags</Form.Label>
            <Form.Control maxLength={100} value={form.tags} onChange={(e) => onChange("tags", e.target.value)} />
          </Form.Group>
        </Col>
        <Col md={12}>
          <div className="detail-meta">
            <span><strong>Created by:</strong> {creator?.name ?? issue.createdBy ?? "—"}</span>
            <span><strong>Created on:</strong> {issue.createdOn ?? "—"}</span>
          </div>
        </Col>
      </Row>
      <div className="form-actions mt-5">
        <Button variant="outline-secondary" onClick={onReset}>Reset</Button>
        <Button className="btn-gold" disabled={saving || saveDisabled} onClick={() => void onSave()}>
          {saving ? "Saving..." : "Edit Issue"}
        </Button>
      </div>
    </Form>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <Col sm={6}>
      <div className="detail-field">
        <small>{label}</small>
        <div>{value}</div>
      </div>
    </Col>
  );
}
