import { useEffect, useMemo, useState } from "react";
import { Alert } from "react-bootstrap";
import { AppLayout } from "../layouts/AppLayout";
import { PageHeader } from "../components/PageHeader";
import { Loading } from "../components/Loading";
import { ErrorAlert } from "../components/ErrorAlert";
import { KanbanBoard } from "../components/KanbanBoard";
import { issueApi, userApi } from "../services/api";
import { useAuth } from "../context/AuthContext";
import type { Issue, User } from "../types/models";

export function AssigneeDashboardPage() {
  const { user } = useAuth();
  const [issues, setIssues] = useState<Issue[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!user) return;
    const load = async () => {
      setLoading(true);
      try {
        const [myIssues, allUsers] = await Promise.all([
          issueApi.getByAssignee(user.userId),
          userApi.getAll()
        ]);
        setIssues(myIssues);
        setUsers(allUsers);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Unable to load assigned issues.");
      } finally {
        setLoading(false);
      }
    };
    void load();
  }, [user]);

  const filteredIssues = useMemo(() => {
    if (!search.trim()) return issues;
    try {
      const regex = new RegExp(search, "i");
      return issues.filter((issue) => regex.test(issue.summary) || regex.test(issue.description ?? ""));
    } catch {
      return [];
    }
  }, [issues, search]);

  if (!user) return null;

  return (
    <AppLayout
      role="ASSIGNEE"
      issueCount={issues.length}
      headerTitle="Issue Tracking System"
      searchValue={search}
      onSearchChange={setSearch}
      searchPlaceholder="Search issues by summary or description (RegEx)"
    >
      <PageHeader title="My Dashboard" subtitle="Review and update the issues assigned to you." />

      {error && <ErrorAlert message={error} />}

      <div className="dashboard-toolbar card-panel mb-4 justify-content-end">
        <div className="small text-secondary">{issues.length} assigned issue{issues.length === 1 ? "" : "s"}</div>
      </div>

      {loading ? <Loading text="Loading your issues..." /> : (
        <>
          {search && filteredIssues.length === 0 && <Alert variant="warning">No issues matched the supplied regular expression.</Alert>}
          <KanbanBoard issues={filteredIssues} users={users} />
        </>
      )}
    </AppLayout>
  );
}
