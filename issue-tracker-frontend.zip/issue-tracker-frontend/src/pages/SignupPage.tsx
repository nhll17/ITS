import { useState } from "react";
import { Alert, Button, Card, Col, Form, Row } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { ROLE_LABELS, ROLE_IDS } from "../types/constants";
import type { Role } from "../types/models";

interface SignupState {
  name: string;
  email: string;
  password: string;
  profile: string;
  role: Role | "";
}

export function SignupPage() {
  const { signup } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState<SignupState>({ name: "", email: "", password: "", profile: "", role: "" });
  const [touched, setTouched] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const nameValid = form.name.trim().length >= 2 && form.name.trim().length <= 50;
  const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email);
  const passwordValid = form.password.length >= 8;
  const profileValid = /^https?:\/\/.+/i.test(form.profile);
  const roleValid = form.role !== "";
  const valid = nameValid && emailValid && passwordValid && profileValid && roleValid;

  const update = <K extends keyof SignupState>(key: K, value: SignupState[K]) =>
    setForm((current) => ({ ...current, [key]: value }));

  const submit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setTouched(true);
    if (!valid) return;

    setSubmitting(true);
    setError("");
    try {
      await signup({
        name: form.name.trim(),
        email: form.email.trim(),
        password: form.password,
        profile: form.profile.trim(),
        role: ROLE_IDS[form.role as Role]
      });
      navigate("/login", { state: { message: "Account created successfully. Please sign in." } });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to create account.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="auth-page">
      <Row className="g-0 min-vh-100">
        <Col lg={5} className="auth-visual d-none d-lg-flex">
          <div className="auth-visual-content">
            <div className="brand-mark large">S</div>
            <div className="eyebrow text-white-50 mt-4">JOIN THE WORKSPACE</div>
            <h1>Build.<br />Assign.<br />Ship.</h1>
            <p>Create a role-based account for project ownership or issue assignment.</p>
          </div>
        </Col>
        <Col lg={7} className="d-flex align-items-center justify-content-center p-4">
          <Card className="auth-card signup-card border-0">
            <Card.Body className="p-4 p-md-5">
              <div className="eyebrow">CREATE ACCOUNT</div>
              <h2 className="mb-1">Sign up</h2>
              <p className="text-secondary mb-4">All fields are validated before submission.</p>

              {error && <Alert variant="danger">{error}</Alert>}

              <Form onSubmit={submit} noValidate>
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Name</Form.Label>
                      <Form.Control value={form.name} onChange={(e) => update("name", e.target.value)} onBlur={() => setTouched(true)} isInvalid={touched && !nameValid} />
                      <Form.Control.Feedback type="invalid">Name must contain 2–50 characters.</Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Role</Form.Label>
                      <Form.Select value={form.role} onChange={(e) => update("role", e.target.value as Role)} onBlur={() => setTouched(true)} isInvalid={touched && !roleValid}>
                        <option value="">Select role</option>
                        <option value="OWNER">{ROLE_LABELS.OWNER}</option>
                        <option value="ASSIGNEE">{ROLE_LABELS.ASSIGNEE}</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">Select a role.</Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>

                <Form.Group className="mb-3">
                  <Form.Label>Email</Form.Label>
                  <Form.Control type="email" value={form.email} onChange={(e) => update("email", e.target.value)} onBlur={() => setTouched(true)} isInvalid={touched && !emailValid} placeholder="you@example.com" />
                  <Form.Control.Feedback type="invalid">Enter a valid email address.</Form.Control.Feedback>
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Password</Form.Label>
                  <Form.Control type="password" value={form.password} onChange={(e) => update("password", e.target.value)} onBlur={() => setTouched(true)} isInvalid={touched && !passwordValid} />
                  <Form.Control.Feedback type="invalid">Password must be at least 8 characters.</Form.Control.Feedback>
                </Form.Group>

                <Form.Group className="mb-4">
                  <Form.Label>Profile image URL</Form.Label>
                  <Form.Control type="url" value={form.profile} onChange={(e) => update("profile", e.target.value)} onBlur={() => setTouched(true)} isInvalid={touched && !profileValid} placeholder="https://..." />
                  <Form.Control.Feedback type="invalid">Provide a valid image URL.</Form.Control.Feedback>
                </Form.Group>

                <Button className="btn-gold w-100 py-2" type="submit" disabled={submitting || (touched && !valid)}>
                  {submitting ? "Creating account..." : "Create Account"}
                </Button>
              </Form>

              <div className="text-center mt-4 small text-secondary">
                Already registered? <Link to="/login">Back to login</Link>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </div>
  );
}
