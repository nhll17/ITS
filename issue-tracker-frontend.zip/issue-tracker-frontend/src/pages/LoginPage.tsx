import { useEffect, useState } from "react";
import { Alert, Button, Card, Col, Form, Row } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { ROLE_LABELS, ROLE_IDS } from "../types/constants";
import type { Role } from "../types/models";

interface FormState {
  email: string;
  password: string;
  role: Role | "";
}

export function LoginPage() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState<FormState>({ email: "", password: "", role: "" });
  const [touched, setTouched] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (user) navigate(user.role === ROLE_IDS.OWNER ? "/owner" : "/assignee", { replace: true });
  }, [navigate, user]);

  const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email);
  const passwordValid = form.password.length >= 8;
  const roleValid = form.role !== "";
  const valid = emailValid && passwordValid && roleValid;

  const submit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setTouched(true);
    if (!valid) return;

    setSubmitting(true);
    setError("");
    try {
      await login(form.email.trim(), form.password, form.role as Role);
      navigate(form.role === "OWNER" ? "/owner" : "/assignee");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to login.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="auth-page">
      <Row className="g-0 min-vh-100">
        <Col lg={6} className="auth-visual d-none d-lg-flex">
          <div className="auth-visual-content">
            <div className="brand-mark large">S</div>
            <div className="eyebrow text-white-50 mt-4">STARK INDUSTRIES</div>
            <h1>Track. Resolve.<br />Deliver.</h1>
            <p>One workspace for projects, issues and delivery progress.</p>
          </div>
        </Col>
        <Col lg={6} className="d-flex align-items-center justify-content-center p-4">
          <Card className="auth-card border-0">
            <Card.Body className="p-4 p-md-5">
              <div className="d-lg-none text-center mb-4">
                <div className="brand-mark mx-auto">S</div>
              </div>
              <div className="eyebrow">WELCOME BACK</div>
              <h2 className="mb-1">Sign in</h2>
              <p className="text-secondary mb-4">Access your issue tracking workspace.</p>

              {error && <Alert variant="danger">{error}</Alert>}

              <Form onSubmit={submit} noValidate>
                <Form.Group className="mb-3" controlId="loginEmail">
                  <Form.Label>Email</Form.Label>
                  <Form.Control
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    onBlur={() => setTouched(true)}
                    isInvalid={touched && !emailValid}
                    placeholder="you@example.com"
                  />
                  <Form.Control.Feedback type="invalid">Enter a valid email address.</Form.Control.Feedback>
                </Form.Group>

                <Form.Group className="mb-3" controlId="loginPassword">
                  <Form.Label>Password</Form.Label>
                  <Form.Control
                    type="password"
                    value={form.password}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                    onBlur={() => setTouched(true)}
                    isInvalid={touched && !passwordValid}
                    placeholder="Minimum 8 characters"
                  />
                  <Form.Control.Feedback type="invalid">Password must be at least 8 characters.</Form.Control.Feedback>
                </Form.Group>

                <Form.Group className="mb-4" controlId="loginRole">
                  <Form.Label>Role</Form.Label>
                  <Form.Select
                    value={form.role}
                    onChange={(e) => setForm({ ...form, role: e.target.value as Role })}
                    onBlur={() => setTouched(true)}
                    isInvalid={touched && !roleValid}
                  >
                    <option value="">Select role</option>
                    <option value="OWNER">{ROLE_LABELS.OWNER}</option>
                    <option value="ASSIGNEE">{ROLE_LABELS.ASSIGNEE}</option>
                  </Form.Select>
                  <Form.Control.Feedback type="invalid">Select a role.</Form.Control.Feedback>
                </Form.Group>

                <Button className="btn-gold w-100 py-2" type="submit" disabled={submitting || (touched && !valid)}>
                  {submitting ? "Signing in..." : "Sign In"}
                </Button>
              </Form>

              <div className="text-center mt-4 small text-secondary">
                New to the system? <Link to="/signup">Create an account</Link>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </div>
  );
}
