import { useState } from "react";
import { Alert, Button, Card, Col, Form, Row } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { AppLayout } from "../layouts/AppLayout";
import { PageHeader } from "../components/PageHeader";
import { projectApi } from "../services/api";
import { useAuth } from "../context/AuthContext";
import type { ProjectFormValues } from "../types/models";

const initialForm = (ownerId: number): ProjectFormValues => ({
  projectName: "",
  projectOwner: ownerId,
  startDate: "",
  endDate: ""
});

export function CreateProjectPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState<ProjectFormValues>(() => initialForm(user?.userId ?? 0));
  const [touched, setTouched] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  if (!user) return null;

  const nameValid = form.projectName.trim().length > 0 && form.projectName.trim().length <= 150;
  const datesValid = !form.startDate || !form.endDate || form.endDate >= form.startDate;
  const valid = nameValid && datesValid;

  const submit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setTouched(true);
    if (!valid) return;

    setSubmitting(true);
    setError("");
    try {
      await projectApi.create({
        ...form,
        projectName: form.projectName.trim(),
        startDate: form.startDate || "",
        endDate: form.endDate || ""
      });
      navigate("/owner");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to create project.");
    } finally {
      setSubmitting(false);
    }
  };

  const reset = () => {
    setForm(initialForm(user.userId));
    setTouched(false);
    setError("");
  };

  return (
    <AppLayout role="OWNER">
      <PageHeader title="Create Project" subtitle="Set up a project before creating issues." />
      <Card className="card-panel border-0">
        <Card.Body className="p-4 p-lg-5">
          {error && <Alert variant="danger">{error}</Alert>}
          <Form onSubmit={submit} noValidate>
            <Row className="g-4">
              <Col md={12}>
                <Form.Group>
                  <Form.Label>Project Name *</Form.Label>
                  <Form.Control
                    value={form.projectName}
                    maxLength={150}
                    onChange={(e) => setForm({ ...form, projectName: e.target.value })}
                    onBlur={() => setTouched(true)}
                    isInvalid={touched && !nameValid}
                    placeholder="e.g. Avengers Delivery Platform"
                  />
                  <Form.Control.Feedback type="invalid">Project name is required and must not exceed 150 characters.</Form.Control.Feedback>
                </Form.Group>
              </Col>
              <Col md={4}>
                <Form.Group>
                  <Form.Label>Project Owner</Form.Label>
                  <Form.Control value={user.name} disabled />
                  <Form.Text>Current authenticated owner.</Form.Text>
                </Form.Group>
              </Col>
              <Col md={4}>
                <Form.Group>
                  <Form.Label>Start Date</Form.Label>
                  <Form.Control type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} />
                </Form.Group>
              </Col>
              <Col md={4}>
                <Form.Group>
                  <Form.Label>End Date</Form.Label>
                  <Form.Control type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} isInvalid={touched && !datesValid} />
                  <Form.Control.Feedback type="invalid">End date cannot be before start date.</Form.Control.Feedback>
                </Form.Group>
              </Col>
            </Row>

            <div className="form-actions mt-5">
              <Button variant="outline-secondary" type="button" onClick={reset}>Reset</Button>
              <Button className="btn-gold" type="submit" disabled={submitting || (touched && !valid)}>
                {submitting ? "Creating..." : "Create Project"}
              </Button>
            </div>
          </Form>
        </Card.Body>
      </Card>
    </AppLayout>
  );
}
