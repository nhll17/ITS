import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import type { Role } from "../types/models";

interface Props {
  allowedRole?: Role;
}

export function ProtectedRoute({ allowedRole }: Props) {
  const { user, role } = useAuth();

  if (!user || !role) return <Navigate to="/login" replace />;
  if (allowedRole && role !== allowedRole) {
    return <Navigate to={role === "OWNER" ? "/owner" : "/assignee"} replace />;
  }

  return <Outlet />;
}
