import { Badge, Card } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { priorityLabel, typeLabel } from "../types/constants";
import type { Issue, User } from "../types/models";

interface Props {
  issue: Issue;
  users?: User[];
}

const priorityVariant = (priority: Issue["priority"]): string => {
  if (priority === "CRITICAL" || priority === "HIGH") return "danger";
  if (priority === "MEDIUM") return "warning";
  return "success";
};

export function IssueCard({ issue, users = [] }: Props) {
  const navigate = useNavigate();
  const assignee = users.find((user) => user.userId === issue.assignee);

  return (
    <Card className="issue-card shadow-sm h-100" onClick={() => navigate(`/issues/${issue.issueId}`)}>
      <Card.Body>
        <div className="d-flex justify-content-between gap-2 mb-2">
          <small className="text-secondary">#{issue.issueId}</small>
          <Badge bg={priorityVariant(issue.priority)}>{priorityLabel(issue.priority)}</Badge>
        </div>
        <Card.Title className="issue-title">{issue.summary}</Card.Title>
        <Card.Text className="issue-description">
          {issue.description || "No description provided."}
        </Card.Text>
        <div className="d-flex justify-content-between align-items-center mt-3">
          <div>
            <Badge bg="light" text="dark" className="me-1">{typeLabel(issue.type)}</Badge>
            {issue.sprint && <Badge bg="light" text="dark">Sprint {issue.sprint}</Badge>}
          </div>
          {assignee && (
            <div className="avatar avatar-sm" title={assignee.name}>
              {assignee.profile ? (
                <img src={assignee.profile} alt={assignee.name} />
              ) : (
                assignee.name.charAt(0).toUpperCase()
              )}
            </div>
          )}
        </div>
      </Card.Body>
    </Card>
  );
}
