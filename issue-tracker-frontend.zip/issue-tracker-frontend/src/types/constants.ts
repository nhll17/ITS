import type { IssuePriority, IssueStatus, IssueType, Role } from "./models";

export const ROLE_IDS: Record<Role, number> = {
  OWNER: 1,
  ASSIGNEE: 2
};

export const ROLE_LABELS: Record<Role, string> = {
  OWNER: "Project Owner",
  ASSIGNEE: "Assignee"
};

export const STATUS_OPTIONS: Array<{ value: IssueStatus; label: string }> = [
  { value: "OPEN", label: "To-Do" },
  { value: "IN_PROGRESS", label: "Development" },
  { value: "RESOLVED", label: "Testing" },
  { value: "CLOSED", label: "Completed" }
];

export const PRIORITY_OPTIONS: Array<{ value: IssuePriority; label: string }> = [
  { value: "LOW", label: "LOW" },
  { value: "MEDIUM", label: "MEDIUM" },
  { value: "HIGH", label: "HIGH" },
  { value: "CRITICAL", label: "CRITICAL" }
];

export const TYPE_OPTIONS: Array<{ value: IssueType; label: string }> = [
  { value: "BUG", label: "BUG" },
  { value: "TASK", label: "TASK" },
  { value: "FEATURE", label: "STORY" }
];

export const statusLabel = (status: IssueStatus): string =>
  STATUS_OPTIONS.find((item) => item.value === status)?.label ?? status;

export const priorityLabel = (priority: IssuePriority): string =>
  PRIORITY_OPTIONS.find((item) => item.value === priority)?.label ?? priority;

export const typeLabel = (type: IssueType): string =>
  TYPE_OPTIONS.find((item) => item.value === type)?.label ?? type;
