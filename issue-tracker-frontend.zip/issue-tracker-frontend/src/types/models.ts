export type Role = "OWNER" | "ASSIGNEE";

export type BackendRole = number;

export type IssueStatus = "OPEN" | "IN_PROGRESS" | "RESOLVED" | "CLOSED";
export type IssuePriority = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
export type IssueType = "BUG" | "FEATURE" | "TASK";

export interface User {
  userId: number;
  role: BackendRole;
  email: string;
  name: string;
  password?: string;
  profile: string;
}

export interface Project {
  projectId: number;
  projectName: string;
  projectOwner: number;
  startDate?: string | null;
  endDate?: string | null;
}

export interface Issue {
  issueId: number;
  projectId: number;
  assignee?: number | null;
  createdOn?: string | null;
  lastUpdated?: string | null;
  description?: string | null;
  summary: string;
  priority: IssuePriority;
  status: IssueStatus;
  createdBy?: number | null;
  sprint?: string | null;
  storyPoint?: number | null;
  tags?: string | null;
  type: IssueType;
}

export interface IssueFormValues {
  projectId: number;
  assignee: number | "";
  summary: string;
  description: string;
  priority: IssuePriority | "";
  status: IssueStatus | "";
  createdBy: number;
  sprint: string;
  storyPoint: number | "";
  tags: string;
  type: IssueType | "";
}

export interface ProjectFormValues {
  projectName: string;
  projectOwner: number;
  startDate: string;
  endDate: string;
}

export interface ApiError {
  timestamp?: string;
  status?: number;
  error?: string;
  message?: string;
}
