import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { userApi } from "../services/api";
import { ROLE_IDS } from "../types/constants";
const AuthContext = createContext(undefined);
const STORAGE_KEY = "issue-tracker-user";
const roleFromBackend = (roleId) => {
    if (roleId === ROLE_IDS.OWNER)
        return "OWNER";
    if (roleId === ROLE_IDS.ASSIGNEE)
        return "ASSIGNEE";
    return null;
};
export function AuthProvider({ children }) {
    const [user, setUser] = useState(() => {
        const stored = localStorage.getItem(STORAGE_KEY);
        return stored ? JSON.parse(stored) : null;
    });
    const role = user ? roleFromBackend(user.role) : null;
    useEffect(() => {
        if (user) {
            const safeUser = { ...user };
            delete safeUser.password;
            localStorage.setItem(STORAGE_KEY, JSON.stringify(safeUser));
        }
        else {
            localStorage.removeItem(STORAGE_KEY);
        }
    }, [user]);
    const value = useMemo(() => ({
        user,
        role,
        login: async (email, password, selectedRole) => {
            const loggedIn = await userApi.login(email, password);
            const actualRole = roleFromBackend(loggedIn.role);
            if (actualRole !== selectedRole) {
                throw new Error(`This account is registered as ${actualRole === "OWNER" ? "Project Owner" : "Assignee"}.`);
            }
            setUser(loggedIn);
        },
        signup: async (payload) => {
            const created = await userApi.signup(payload);
            return created;
        },
        logout: () => setUser(null)
    }), [role, user]);
    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
export const useAuth = () => {
    const context = useContext(AuthContext);
    if (!context)
        throw new Error("useAuth must be used inside AuthProvider");
    return context;
};
