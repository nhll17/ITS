import { Alert } from "react-bootstrap";
export function ErrorAlert({ message }) {
    return <Alert variant="danger" className="mb-3">{message}</Alert>;
}
