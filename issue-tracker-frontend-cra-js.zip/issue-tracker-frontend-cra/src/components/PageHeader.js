import { Button } from "react-bootstrap";
export function PageHeader({ title, subtitle, actionLabel, onAction }) {
    return (<div className="page-header d-flex flex-wrap justify-content-between align-items-end gap-3 mb-4">
      <div>
        <div className="eyebrow">ISSUE TRACKING SYSTEM</div>
        <h1>{title}</h1>
        {subtitle && <p className="text-secondary mb-0">{subtitle}</p>}
      </div>
      {actionLabel && onAction && (<Button className="btn-gold" onClick={onAction}>
          <i className="bi bi-plus-lg me-2"/>{actionLabel}
        </Button>)}
    </div>);
}
