import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
export function ProtectedRoute({ allowedRole }) {
    const { user, role } = useAuth();
    if (!user || !role)
        return <Navigate to="/login" replace/>;
    if (allowedRole && role !== allowedRole) {
        return <Navigate to={role === "OWNER" ? "/owner" : "/assignee"} replace/>;
    }
    return <Outlet />;
}
