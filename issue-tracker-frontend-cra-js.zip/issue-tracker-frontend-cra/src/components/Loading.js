import { Spinner } from "react-bootstrap";
export function Loading({ text = "Loading..." }) {
    return (<div className="d-flex flex-column align-items-center justify-content-center py-5">
      <Spinner animation="border" role="status"/>
      <span className="mt-2 text-secondary">{text}</span>
    </div>);
}
