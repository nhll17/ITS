import { Col, Row } from "react-bootstrap";
import { STATUS_OPTIONS } from "../types/constants";
import { IssueCard } from "./IssueCard";
export function KanbanBoard({ issues, users = [], onIssueClick }) {
    return (<Row className="g-3 kanban-row">
      {STATUS_OPTIONS.map((status) => {
            const columnIssues = issues.filter((issue) => issue.status === status.value);
            return (<Col key={status.value} xs={12} md={6} xl={3}>
            <div className="kanban-column h-100">
              <div className="kanban-column-header">
                <div>
                  <div className="fw-semibold">{status.label}</div>
                  <small className="text-secondary">{columnIssues.length} issue{columnIssues.length === 1 ? "" : "s"}</small>
                </div>
                <span className={`status-dot status-${status.value.toLowerCase()}`}/>
              </div>
              <div className="vstack gap-3 mt-3">
                {columnIssues.length === 0 ? (<div className="empty-column">No issues</div>) : (columnIssues.map((issue) => (<div key={issue.issueId} onClick={() => onIssueClick?.(issue)}>
                      <IssueCard issue={issue} users={users}/>
                    </div>)))}
              </div>
            </div>
          </Col>);
        })}
    </Row>);
}
