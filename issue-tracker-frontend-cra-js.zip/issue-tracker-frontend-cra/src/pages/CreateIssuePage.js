import { useEffect, useState } from "react";
import { Alert, Button, Card, Col, Form, Row } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { AppLayout } from "../layouts/AppLayout";
import { PageHeader } from "../components/PageHeader";
import { projectApi, issueApi, userApi } from "../services/api";
import { PRIORITY_OPTIONS, ROLE_IDS, STATUS_OPTIONS, TYPE_OPTIONS } from "../types/constants";
import { useAuth } from "../context/AuthContext";
const emptyForm = (ownerId) => ({
    projectId: 0,
    assignee: "",
    summary: "",
    description: "",
    priority: "",
    status: "OPEN",
    createdBy: ownerId,
    sprint: "",
    storyPoint: "",
    tags: "",
    type: ""
});
export function CreateIssuePage() {
    const { user } = useAuth();
    const navigate = useNavigate();
    const [projects, setProjects] = useState([]);
    const [users, setUsers] = useState([]);
    const [form, setForm] = useState(() => emptyForm(user?.userId ?? 0));
    const [touched, setTouched] = useState(false);
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [error, setError] = useState("");
    useEffect(() => {
        if (!user)
            return;
        const load = async () => {
            try {
                const [ownerProjects, allUsers] = await Promise.all([
                    projectApi.getByOwner(user.userId),
                    userApi.getAll()
                ]);
                setProjects(ownerProjects);
                setUsers(allUsers.filter((candidate) => candidate.role === ROLE_IDS.ASSIGNEE));
            }
            catch (err) {
                setError(err instanceof Error ? err.message : "Unable to load project and assignee data.");
            }
            finally {
                setLoading(false);
            }
        };
        void load();
    }, [user]);
    if (!user)
        return null;
    const summaryValid = /^[\w\s.,/|-]+$/.test(form.summary) && form.summary.trim().length > 0 && form.summary.length <= 150;
    const descriptionValid = form.description.length <= 500;
    const projectValid = form.projectId > 0;
    const typeValid = form.type !== "";
    const priorityValid = form.priority !== "";
    const assigneeValid = typeof form.assignee === "number" && form.assignee > 0;
    const sprintValid = /^\d+$/.test(form.sprint) && Number(form.sprint) > 0;
    const storyPointValid = typeof form.storyPoint === "number" && form.storyPoint > 0;
    const tagsValid = form.tags.length <= 100;
    const valid = summaryValid && descriptionValid && projectValid && typeValid && priorityValid && assigneeValid && sprintValid && storyPointValid && tagsValid;
    const update = (key, value) => setForm((current) => ({ ...current, [key]: value }));
    const submit = async (event) => {
        event.preventDefault();
        setTouched(true);
        if (!valid)
            return;
        setSubmitting(true);
        setError("");
        try {
            await issueApi.create({
                ...form,
                assignee: form.assignee,
                priority: form.priority,
                type: form.type,
                sprint: form.sprint,
                storyPoint: form.storyPoint
            });
            navigate("/owner");
        }
        catch (err) {
            setError(err instanceof Error ? err.message : "Unable to create issue.");
        }
        finally {
            setSubmitting(false);
        }
    };
    const reset = () => {
        setForm(emptyForm(user.userId));
        setTouched(false);
        setError("");
    };
    return (<AppLayout role="OWNER">
      <PageHeader title="Create Issue" subtitle="Create a tracked work item and assign it to a team member."/>
      {error && <Alert variant="danger">{error}</Alert>}
      <Card className="card-panel border-0">
        <Card.Body className="p-4 p-lg-5">
          {loading ? <div className="text-secondary">Loading configuration...</div> : (<Form onSubmit={submit} noValidate>
              <Row className="g-4">
                <Col md={8}>
                  <Form.Group>
                    <Form.Label>Summary *</Form.Label>
                    <Form.Control maxLength={150} value={form.summary} onChange={(e) => update("summary", e.target.value)} onBlur={() => setTouched(true)} isInvalid={touched && !summaryValid} placeholder="Short issue title"/>
                    <Form.Control.Feedback type="invalid">Required, max 150 characters. Use letters, numbers, spaces and basic punctuation.</Form.Control.Feedback>
                  </Form.Group>
                </Col>
                <Col md={4}>
                  <Form.Group>
                    <Form.Label>Project *</Form.Label>
                    <Form.Select value={form.projectId || ""} onChange={(e) => update("projectId", Number(e.target.value))} onBlur={() => setTouched(true)} isInvalid={touched && !projectValid}>
                      <option value="">Select project</option>
                      {projects.map((project) => <option key={project.projectId} value={project.projectId}>{project.projectName}</option>)}
                    </Form.Select>
                    <Form.Control.Feedback type="invalid">Select a project.</Form.Control.Feedback>
                  </Form.Group>
                </Col>

                <Col md={12}>
                  <Form.Group>
                    <Form.Label>Description</Form.Label>
                    <Form.Control as="textarea" rows={4} maxLength={500} value={form.description} onChange={(e) => update("description", e.target.value)} isInvalid={touched && !descriptionValid}/>
                    <Form.Control.Feedback type="invalid">Maximum 500 characters.</Form.Control.Feedback>
                  </Form.Group>
                </Col>

                <Col md={4}>
                  <Form.Group>
                    <Form.Label>Type *</Form.Label>
                    <Form.Select value={form.type} onChange={(e) => update("type", e.target.value)} onBlur={() => setTouched(true)} isInvalid={touched && !typeValid}>
                      <option value="">Select type</option>
                      {TYPE_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
                    </Form.Select>
                  </Form.Group>
                </Col>
                <Col md={4}>
                  <Form.Group>
                    <Form.Label>Priority *</Form.Label>
                    <Form.Select value={form.priority} onChange={(e) => update("priority", e.target.value)} onBlur={() => setTouched(true)} isInvalid={touched && !priorityValid}>
                      <option value="">Select priority</option>
                      {PRIORITY_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
                    </Form.Select>
                  </Form.Group>
                </Col>
                <Col md={4}>
                  <Form.Group>
                    <Form.Label>Status *</Form.Label>
                    <Form.Select value={form.status} onChange={(e) => update("status", e.target.value)}>
                      {STATUS_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
                    </Form.Select>
                  </Form.Group>
                </Col>

                <Col md={6}>
                  <Form.Group>
                    <Form.Label>Assignee *</Form.Label>
                    <Form.Select value={form.assignee} onChange={(e) => update("assignee", Number(e.target.value))} onBlur={() => setTouched(true)} isInvalid={touched && !assigneeValid}>
                      <option value="">Select assignee</option>
                      {users.map((candidate) => <option key={candidate.userId} value={candidate.userId}>{candidate.name} — {candidate.email}</option>)}
                    </Form.Select>
                  </Form.Group>
                </Col>
                <Col md={3}>
                  <Form.Group>
                    <Form.Label>Sprint *</Form.Label>
                    <Form.Control inputMode="numeric" value={form.sprint} onChange={(e) => update("sprint", e.target.value.replace(/\D/g, ""))} onBlur={() => setTouched(true)} isInvalid={touched && !sprintValid} placeholder="1"/>
                  </Form.Group>
                </Col>
                <Col md={3}>
                  <Form.Group>
                    <Form.Label>Story Point *</Form.Label>
                    <Form.Control type="number" min={1} step={1} value={form.storyPoint} onChange={(e) => update("storyPoint", e.target.value ? Number(e.target.value) : "")} onBlur={() => setTouched(true)} isInvalid={touched && !storyPointValid}/>
                  </Form.Group>
                </Col>

                <Col md={12}>
                  <Form.Group>
                    <Form.Label>Tags</Form.Label>
                    <Form.Control maxLength={100} value={form.tags} onChange={(e) => update("tags", e.target.value)} isInvalid={touched && !tagsValid} placeholder="e.g. backend, urgent, release"/>
                    <Form.Text>Optional. Multiple tags can be comma separated.</Form.Text>
                  </Form.Group>
                </Col>
              </Row>

              <div className="form-actions mt-5">
                <Button variant="outline-secondary" type="button" onClick={reset}>Reset</Button>
                <Button className="btn-gold" type="submit" disabled={submitting || (touched && !valid)}>
                  {submitting ? "Creating..." : "Create Issue"}
                </Button>
              </div>
            </Form>)}
        </Card.Body>
      </Card>
    </AppLayout>);
}
