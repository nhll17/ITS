import { useEffect, useMemo, useState } from "react";
import { Alert, Nav, Tab } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { AppLayout } from "../layouts/AppLayout";
import { PageHeader } from "../components/PageHeader";
import { Loading } from "../components/Loading";
import { ErrorAlert } from "../components/ErrorAlert";
import { KanbanBoard } from "../components/KanbanBoard";
import { issueApi, projectApi, userApi } from "../services/api";
import { useAuth } from "../context/AuthContext";
export function OwnerDashboardPage() {
    const { user } = useAuth();
    const navigate = useNavigate();
    const [projects, setProjects] = useState([]);
    const [selectedProject, setSelectedProject] = useState(null);
    const [issues, setIssues] = useState([]);
    const [createdIssueCount, setCreatedIssueCount] = useState(0);
    const [users, setUsers] = useState([]);
    const [search, setSearch] = useState("");
    const [loading, setLoading] = useState(true);
    const [issuesLoading, setIssuesLoading] = useState(false);
    const [error, setError] = useState("");
    useEffect(() => {
        if (!user)
            return;
        const load = async () => {
            setLoading(true);
            setError("");
            try {
                const [ownerProjects, allUsers, allIssues] = await Promise.all([
                    projectApi.getByOwner(user.userId),
                    userApi.getAll(),
                    issueApi.getAll()
                ]);
                setProjects(ownerProjects);
                setUsers(allUsers);
                setCreatedIssueCount(allIssues.filter((issue) => issue.createdBy === user.userId).length);
                if (ownerProjects.length > 0)
                    setSelectedProject(ownerProjects[0]);
            }
            catch (err) {
                setError(err instanceof Error ? err.message : "Unable to load dashboard.");
            }
            finally {
                setLoading(false);
            }
        };
        void load();
    }, [user]);
    useEffect(() => {
        if (!selectedProject) {
            setIssues([]);
            return;
        }
        const loadIssues = async () => {
            setIssuesLoading(true);
            try {
                setIssues(await projectApi.getIssues(selectedProject.projectId));
            }
            catch (err) {
                setError(err instanceof Error ? err.message : "Unable to load project issues.");
            }
            finally {
                setIssuesLoading(false);
            }
        };
        void loadIssues();
    }, [selectedProject]);
    const filteredIssues = useMemo(() => {
        if (!search.trim())
            return issues;
        try {
            const regex = new RegExp(search, "i");
            return issues.filter((issue) => regex.test(issue.summary) || regex.test(issue.description ?? ""));
        }
        catch {
            return [];
        }
    }, [issues, search]);
    if (!user)
        return null;
    return (<AppLayout role="OWNER" projectCount={projects.length} issueCount={createdIssueCount} headerTitle={selectedProject?.projectName ?? "Issue Tracking System"} searchValue={search} onSearchChange={setSearch} searchPlaceholder="Search issues by summary or description (RegEx)">
      <PageHeader title={selectedProject ? selectedProject.projectName : "Project Dashboard"} subtitle={selectedProject ? "Monitor issue progress across your selected project." : "Create a project to get started."} actionLabel="Create Project" onAction={() => navigate("/owner/create-project")}/>

      {error && <ErrorAlert message={error}/>}

      {loading ? (<Loading text="Loading projects..."/>) : projects.length === 0 ? (<div className="empty-state">
          <div className="empty-icon"><i className="bi bi-folder-x"/></div>
          <h3>No Projects Available</h3>
          <p className="text-secondary">Create your first project to start tracking issues.</p>
          <button className="btn btn-gold" onClick={() => navigate("/owner/create-project")}>Create Project</button>
        </div>) : (<Tab.Container activeKey={selectedProject?.projectId.toString()} onSelect={(key) => {
                const project = projects.find((item) => item.projectId.toString() === key);
                setSelectedProject(project ?? null);
            }}>
          <div className="dashboard-toolbar card-panel mb-4">
            <div className="project-tabs-wrap">
              <Nav variant="pills" className="project-tabs">
                {projects.map((project) => <Nav.Item key={project.projectId}><Nav.Link eventKey={project.projectId.toString()}>{project.projectName}</Nav.Link></Nav.Item>)}
              </Nav>
            </div>

          </div>

          <Tab.Content>
            <Tab.Pane eventKey={selectedProject?.projectId.toString()}>
              {issuesLoading ? <Loading text="Loading issues..."/> : (<>
                  {search && filteredIssues.length === 0 && (<Alert variant="warning">No issues matched the supplied regular expression.</Alert>)}
                  <KanbanBoard issues={filteredIssues} users={users}/>
                </>)}
            </Tab.Pane>
          </Tab.Content>
        </Tab.Container>)}
    </AppLayout>);
}
