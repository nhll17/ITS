import { Navigate, Route, Routes } from "react-router-dom";
import { ProtectedRoute } from "./components/ProtectedRoute";
import { LoginPage } from "./pages/LoginPage";
import { SignupPage } from "./pages/SignupPage";
import { OwnerDashboardPage } from "./pages/OwnerDashboardPage";
import { CreateProjectPage } from "./pages/CreateProjectPage";
import { CreateIssuePage } from "./pages/CreateIssuePage";
import { AssigneeDashboardPage } from "./pages/AssigneeDashboardPage";
import { IssueDetailPage } from "./pages/IssueDetailPage";
import { useAuth } from "./context/AuthContext";
function HomeRedirect() {
    const { user } = useAuth();
    if (!user)
        return <Navigate to="/login" replace/>;
    return <Navigate to={user.role === 1 ? "/owner" : "/assignee"} replace/>;
}
export function App() {
    return (<Routes>
      <Route path="/" element={<HomeRedirect />}/>
      <Route path="/login" element={<LoginPage />}/>
      <Route path="/signup" element={<SignupPage />}/>

      <Route element={<ProtectedRoute allowedRole="OWNER"/>}>
        <Route path="/owner" element={<OwnerDashboardPage />}/>
        <Route path="/owner/create-project" element={<CreateProjectPage />}/>
        <Route path="/owner/create-issue" element={<CreateIssuePage />}/>
      </Route>

      <Route element={<ProtectedRoute allowedRole="ASSIGNEE"/>}>
        <Route path="/assignee" element={<AssigneeDashboardPage />}/>
      </Route>

      <Route element={<ProtectedRoute />}>
        <Route path="/issues/:id" element={<IssueDetailPage />}/>
      </Route>

      <Route path="*" element={<Navigate to="/" replace/>}/>
    </Routes>);
}
