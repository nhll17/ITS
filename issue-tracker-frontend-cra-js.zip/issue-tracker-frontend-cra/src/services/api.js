const API_BASE = process.env.REACT_APP_API_BASE_URL ?? "";
const api = async (path, options = {}) => {
    const response = await fetch(`${API_BASE}${path}`, {
        headers: {
            "Content-Type": "application/json",
            ...(options.headers ?? {})
        },
        ...options
    });
    const text = await response.text();
    const data = text ? JSON.parse(text) : null;
    if (!response.ok) {
        const error = (data ?? {});
        throw new Error(error.message || error.error || `Request failed with status ${response.status}`);
    }
    return data;
};
export const userApi = {
    signup: (payload) => api("/api/users", { method: "POST", body: JSON.stringify(payload) }),
    login: (email, password) => api(`/api/users/login?email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`, {
        method: "POST"
    }),
    getById: (id) => api(`/api/users/${id}`),
    getAll: () => api("/api/users"),
    getIssuesByUser: (id) => api(`/api/users/${id}/issues`),
    getIssuesByUsername: (name) => api(`/api/users/username/${encodeURIComponent(name)}/issues`)
};
export const projectApi = {
    getAll: () => api("/api/projects"),
    getById: (id) => api(`/api/projects/${id}`),
    getByOwner: (ownerId) => api(`/api/projects/owner/${ownerId}`),
    create: (payload) => api("/api/projects", { method: "POST", body: JSON.stringify(payload) }),
    update: (id, payload) => api(`/api/projects/${id}`, { method: "PUT", body: JSON.stringify(payload) }),
    delete: (id) => api(`/api/projects/${id}`, { method: "DELETE" }),
    getIssues: (id) => api(`/api/projects/${id}/issues`)
};
export const issueApi = {
    getAll: () => api("/api/issues"),
    getById: (id) => api(`/api/issues/${id}`),
    create: (payload) => api("/api/issues", { method: "POST", body: JSON.stringify(payload) }),
    update: (id, payload) => api(`/api/issues/${id}`, { method: "PUT", body: JSON.stringify(payload) }),
    getByProject: (projectId) => api(`/api/issues/project/${projectId}`),
    getByAssignee: (assigneeId) => api(`/api/issues/assignee/${assigneeId}`)
};
