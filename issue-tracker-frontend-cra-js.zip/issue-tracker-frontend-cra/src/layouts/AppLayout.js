import { useState } from "react";
import { Button, Navbar } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
export function AppLayout({ children, role, projectCount = 0, issueCount = 0, headerTitle = "Issue Tracking System", searchValue = "", onSearchChange, searchPlaceholder = "Search..." }) {
    const { user, logout } = useAuth();
    const navigate = useNavigate();
    const [collapsed, setCollapsed] = useState(false);
    if (!user)
        return null;
    const ownerLinks = [
        { label: "Project Dashboard", icon: "bi-grid-1x2", path: "/owner" },
        { label: "Create Project", icon: "bi-folder-plus", path: "/owner/create-project" },
        { label: "Create Issue", icon: "bi-plus-square", path: "/owner/create-issue" }
    ];
    const assigneeLinks = [
        { label: "My Dashboard", icon: "bi-kanban", path: "/assignee" }
    ];
    const links = role === "OWNER" ? ownerLinks : assigneeLinks;
    return (<div className="app-shell">
      <aside className={`sidebar ${collapsed ? "sidebar-collapsed" : ""}`}>
        <div className="sidebar-brand">
          <div className="brand-mark">S</div>
          {!collapsed && <span>Issue Tracker</span>}
        </div>

        <div className="sidebar-profile">
          <div className="avatar avatar-lg">
            {user.profile ? <img src={user.profile} alt={user.name}/> : user.name.charAt(0).toUpperCase()}
          </div>
          {!collapsed && (<>
              <div className="fw-semibold mt-2">{user.name}</div>
              <small className="text-white-50">{user.email}</small>
              <div className="sidebar-stats mt-3">
                {role === "OWNER" ? (<>
                    <div><strong>{projectCount}</strong><span>Projects</span></div>
                    <div><strong>{issueCount}</strong><span>Issues</span></div>
                  </>) : (<div><strong>{issueCount}</strong><span>Issues Assigned</span></div>)}
              </div>
            </>)}
        </div>

        <nav className="sidebar-nav">
          {links.map((link) => (<Button key={link.path} variant="link" className="sidebar-link" title={link.label} onClick={() => navigate(link.path)}>
              <i className={`bi ${link.icon}`}/>
              {!collapsed && <span>{link.label}</span>}
            </Button>))}
        </nav>

        <div className="sidebar-footer">
          <Button variant="outline-light" className="w-100" onClick={() => {
            logout();
            navigate("/login", { replace: true });
        }}>
            <i className="bi bi-box-arrow-left me-2"/>
            {!collapsed && "Logout"}
          </Button>
        </div>

        <button className="sidebar-toggle" onClick={() => setCollapsed((value) => !value)} aria-label="Toggle sidebar">
          <i className={`bi bi-chevron-${collapsed ? "right" : "left"}`}/>
        </button>
      </aside>

      <main className="main-shell">
        <Navbar className="topbar px-3 px-lg-4 gap-3">
          <div className="header-search">
            <i className="bi bi-search"/>
            <input value={searchValue} onChange={(event) => onSearchChange?.(event.target.value)} placeholder={searchPlaceholder} aria-label="Search"/>
          </div>
          <div className="ms-auto d-flex align-items-center gap-3">
            <span className="fw-bold d-none d-sm-inline">{headerTitle}</span>
            <span className="topbar-avatar avatar avatar-sm">
              {user.profile ? <img src={user.profile} alt={user.name}/> : user.name.charAt(0).toUpperCase()}
            </span>
          </div>
        </Navbar>
        <section className="content-area">{children}</section>
      </main>
    </div>);
}
