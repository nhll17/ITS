export const ROLE_IDS = {
    OWNER: 1,
    ASSIGNEE: 2
};
export const ROLE_LABELS = {
    OWNER: "Project Owner",
    ASSIGNEE: "Assignee"
};
export const STATUS_OPTIONS = [
    { value: "OPEN", label: "To-Do" },
    { value: "IN_PROGRESS", label: "Development" },
    { value: "RESOLVED", label: "Testing" },
    { value: "CLOSED", label: "Completed" }
];
export const PRIORITY_OPTIONS = [
    { value: "LOW", label: "LOW" },
    { value: "MEDIUM", label: "MEDIUM" },
    { value: "HIGH", label: "HIGH" },
    { value: "CRITICAL", label: "CRITICAL" }
];
export const TYPE_OPTIONS = [
    { value: "BUG", label: "BUG" },
    { value: "TASK", label: "TASK" },
    { value: "FEATURE", label: "STORY" }
];
export const statusLabel = (status) => STATUS_OPTIONS.find((item) => item.value === status)?.label ?? status;
export const priorityLabel = (priority) => PRIORITY_OPTIONS.find((item) => item.value === priority)?.label ?? priority;
export const typeLabel = (type) => TYPE_OPTIONS.find((item) => item.value === type)?.label ?? type;
